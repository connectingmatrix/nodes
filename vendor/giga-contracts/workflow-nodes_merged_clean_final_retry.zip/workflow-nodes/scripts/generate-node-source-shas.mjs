import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { dirname, join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

const repoRoot = dirname(dirname(fileURLToPath(import.meta.url)));
const nodesRoot = join(repoRoot, 'src', 'nodes');
const outputFile = join(repoRoot, 'src', 'generated', 'node-source-shas.json');

const sourceFiles = (directory, prefix = '') => readdirSync(directory).flatMap((entry) => {
  const filePath = join(directory, entry);
  const fileName = prefix ? `${prefix}/${entry}` : entry;
  if (statSync(filePath).isDirectory()) return sourceFiles(filePath, fileName);
  return /\.(ts|json)$/.test(entry) ? [fileName] : [];
});

const nodeModelId = (directory) => {
  const schemaFile = readdirSync(directory).find((entry) => entry.endsWith('-schema.json'));
  if (!schemaFile) return '';
  return String(JSON.parse(readFileSync(join(directory, schemaFile), 'utf8')).id || '').trim();
};

const digestNode = (directory) => {
  const files = sourceFiles(directory).sort();
  const hash = createHash('sha256');
  for (const file of files) hash.update(`${file}\n${readFileSync(join(directory, file), 'utf8')}\n`);
  return { files, sha: hash.digest('hex') };
};

const nodes = Object.fromEntries(readdirSync(nodesRoot).flatMap((entry) => {
  const directory = join(nodesRoot, entry);
  if (!statSync(directory).isDirectory()) return [];
  const modelId = nodeModelId(directory);
  return modelId ? [[modelId, digestNode(directory)]] : [];
}));

mkdirSync(dirname(outputFile), { recursive: true });
writeFileSync(outputFile, `${JSON.stringify({ generatedAt: new Date().toISOString(), nodes, root: relative(repoRoot, nodesRoot), version: 1 }, null, 2)}\n`);
