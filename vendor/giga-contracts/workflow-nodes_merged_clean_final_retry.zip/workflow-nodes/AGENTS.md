Coding guidelines for creating the node:

if the guidelines are not met then redo a coding pass

0. RULE:: USER SHOULD KNOW WHAT NODE IS DOING THERE SHOULD NOT BE ANY HIDDEN PROCESSING or HIDDEN USAGE OF INPUT.
1. Never use json payload field unless without it you cannot do anything.
2. Use select or multi-select drop down fields for the usage where you need perform the operations on switch / case or if / else mode.
3. Do not code anything hard coded in the application and instead expose the propesties making the application configureable.
4. If the node wants to use LLM. expose the LLM port and then attach the LLM with it.
5. Make sure each node is generic and configureable.
6. if you are going to use JSON payload to manipulate think as an end user is not a programmer how can an end user what options are available to use the node unless those options are offer via clear select field.
7. if there are more than one parameters set then the form should offer a Add Button to add key, value pairs where again user dont know what keys the node is going to use so key can be offered in the form of slect dropdown.
8. Make sure that node designing is user friendly. if some node port can accept specific ports only then make sure that node will give an error in inspector that invalid node is connected to the port.
9. Node should not read the input directly from its input port it will always read the input through its inspector properties. if we are going to use the input that will be through the variables approach only. What that means is that the node will register the properties schema and from other node we will pass that as a variable value.
10. Nodes should be worker owned. Only thoses should can executeBackend which actually want to execute some backend function that involves supabase or Open AI. Nodes wont write their functionality to node-handlers.ts or any other place unless or until user clearly directs so.
11. Inspector fields should be programatic for example if there is an like Create Channel and if we select that action then only the fields related to Create Channel Needs to be shown and the not the fields that are not related to that action.
## Live Test Fixture Scope

- All test-created channels, chats, workflows, posts, attachments, and fixture data must live under the `giga-ai-test` parent scope.
- Matrix, live, and integration tests must reuse or recreate fixture data under `giga-ai-test`; do not create live test data at arbitrary user-tree roots.
