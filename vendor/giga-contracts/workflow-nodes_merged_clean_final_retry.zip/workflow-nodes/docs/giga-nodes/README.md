# Giga Workflow Nodes Guide

Workflow nodes define the execution units that workflows call. Giga supports standard nodes and AI Agent nodes.

## Node API expectations

- Build node into `.node` package output.
- Validate node schema and runtime inputs.
- Run node for direct testing.
- Preserve runtime scope and output preview markers.
- Emit process-monitor logs for build, validation, and run.

```mermaid
graph TD
  A[Node request] --> B{Operation}
  B -->|build| C[Build .node]
  B -->|validate| D[Validate manifest/schema]
  B -->|run| E[Execute test]
  C --> F[Emit process logs]
  D --> F
  E --> F
```


- [Node Designer AI Agent](./node-designer-agent.md) documents node files, build, validate, run, and debug-with-AI rules.
