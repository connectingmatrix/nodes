# Node Designer AI Agent

The Node Designer AI Agent helps users view, edit, validate, build, and run nodes.

```mermaid
graph TD
  A[Node request] --> B[Read node files and manifest]
  B --> C[Validate schema]
  C --> D{Issue type}
  D -->|manifest| E[Fix manifest]
  D -->|runtime| F[Patch runtime]
  D -->|test| G[Add or run test]
  E --> H[Build .node]
  F --> H
  G --> H
  H --> I[Run node]
  I --> J[Return logs and preview]
```

Rules:

- Build, validate, and run APIs are exposed through GraphQL.
- File edits stay inside the node/project scope.
- Node runs emit `NODE` or `WORKFLOW_NODE` process events.
- AI Agent nodes are real AI Agents and therefore emit AI Agent child logs as well.
