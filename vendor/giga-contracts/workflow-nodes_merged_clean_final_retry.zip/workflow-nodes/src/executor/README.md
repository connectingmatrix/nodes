# Workflow Node Executor README

The node executor runs connected node adapters and module workers. It is responsible for preserving scope and producing logs that the workflow executor can broadcast.

```mermaid
graph TD
  A[Node execution request] --> B[Load adapter/worker]
  B --> C[Validate input]
  C --> D[Execute]
  D --> E[Return output]
  D --> F[Emit runtime logs]
```
