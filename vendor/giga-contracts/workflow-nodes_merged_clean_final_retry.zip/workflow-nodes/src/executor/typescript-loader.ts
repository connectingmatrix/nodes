import * as staticTypeScriptModule from 'typescript/lib/typescript.js';

const isModuleContainer = (value: unknown): value is Record<string, unknown> | ((...args: unknown[]) => unknown) =>
    (typeof value === 'object' && value !== null) || typeof value === 'function';

const getContainerValues = (value: Record<string, unknown> | ((...args: unknown[]) => unknown)): unknown[] => {
    const keys = Reflect.ownKeys(value as object);
    const values: unknown[] = [];
    keys.forEach((key) => {
        try {
            values.push((value as Record<PropertyKey, unknown>)[key]);
        } catch {
            // Ignore unreadable properties from wrapped module namespace objects.
        }
    });
    return values;
};

const unwrapDefaultChain = (moduleRef: unknown): unknown => {
    let current: unknown = moduleRef;
    for (let index = 0; index < 6; index += 1) {
        if (!isModuleContainer(current)) return current;
        if (typeof (current as { transpileModule?: unknown }).transpileModule === 'function') return current;
        if (!Object.prototype.hasOwnProperty.call(current, 'default')) return current;
        current = (current as Record<string, unknown>).default;
    }
    return current;
};

const resolveTypeScriptApi = (moduleRef: unknown): Record<string, unknown> | null => {
    const queue: unknown[] = [unwrapDefaultChain(moduleRef)];
    const visited = new Set<unknown>();

    while (queue.length > 0) {
        const current = queue.shift();
        if (!isModuleContainer(current) || visited.has(current)) continue;
        visited.add(current);
        if (typeof (current as { transpileModule?: unknown }).transpileModule === 'function') return current as Record<string, unknown>;

        const nextValues = getContainerValues(current);
        nextValues.forEach((value) => {
            if (isModuleContainer(value) && !visited.has(value)) {
                queue.push(value);
            }
        });
    }

    return null;
};

const importCandidates: Array<{ label: string; load: () => Promise<unknown> }> = [
    {
        label: 'import("typescript/lib/typescript.js")',
        load: () => import('typescript/lib/typescript.js')
    },
    {
        label: 'import("typescript")',
        load: () => import('typescript')
    }
];

export const loadTypeScriptModule = async (): Promise<unknown> => {
    const staticApi = resolveTypeScriptApi(staticTypeScriptModule);
    if (staticApi) {
        return staticApi;
    }

    const globalTs = resolveTypeScriptApi((globalThis as { ts?: unknown }).ts);
    if (globalTs) {
        return globalTs;
    }

    const globalTypeScript = resolveTypeScriptApi((globalThis as { TypeScript?: unknown }).TypeScript);
    if (globalTypeScript) {
        return globalTypeScript;
    }

    const errors: string[] = [];
    for (const candidate of importCandidates) {
        try {
            const moduleRef = await candidate.load();
            const resolved = resolveTypeScriptApi(moduleRef);
            if (resolved) {
                return resolved;
            }
            errors.push(`[${candidate.label}] transpileModule missing`);
        } catch (error) {
            errors.push(`[${candidate.label}] ${error instanceof Error ? error.message : String(error)}`);
        }
    }

    throw new Error(`TypeScript module bootstrap failed: ${errors.join(' | ') || 'No TypeScript candidates resolved.'}`);
};
