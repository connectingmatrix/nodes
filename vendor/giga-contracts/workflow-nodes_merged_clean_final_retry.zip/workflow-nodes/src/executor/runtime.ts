import { createBrowserWorkerNodeHandler, createWorkflowExecutor, WorkflowExecutorModeEnum } from '@workflow/executor/browser';
import { createWorkflowExecutorHostContext } from './mcp-runtime.manager';
import { executeNodeWorkerBackend } from './backend-adapter';
import { loadTypeScriptModule } from './typescript-loader';
import { withNodeExecutors } from '../utils/workflow-node-executors.utils';

const toRecord = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});

const resolvePreviewSourceFilesFromHostContext = (hostContext: unknown): { 'worker.ts'?: string; 'validate.ts'?: string } | null => {
    const root = toRecord(hostContext);
    const preview = toRecord(root.__workflowPreview);
    const sourceFiles = toRecord(preview.sourceFiles);
    const workerTs = typeof sourceFiles['worker.ts'] === 'string' ? sourceFiles['worker.ts'] : '';
    const validateTs = typeof sourceFiles['validate.ts'] === 'string' ? sourceFiles['validate.ts'] : '';
    if (!workerTs && !validateTs) {
        return null;
    }
    return {
        ...(workerTs ? { 'worker.ts': workerTs } : {}),
        ...(validateTs ? { 'validate.ts': validateTs } : {})
    };
};

const baseWorkflowExecutor = createWorkflowExecutor({
    mode: WorkflowExecutorModeEnum.Local,
    adapters: {
        getNodeHandler: (modelId) =>
            createBrowserWorkerNodeHandler({
                modelId: modelId ?? 'unknown-node',
                typescriptModuleLoader: loadTypeScriptModule,
                executeHelpers: {
                    executeBackend: executeNodeWorkerBackend,
                    resolveNodeSourceFiles: async ({ context }) => resolvePreviewSourceFilesFromHostContext(context.hostContext),
                    updateNode: () => undefined
                }
            })
    }
});

type ExecutorWorkflow = Parameters<typeof baseWorkflowExecutor.executeWorkflow>[0];
type ExecutorNode = ExecutorWorkflow['nodes'][number];

const buildSynchronizedRuntime = (node: ExecutorNode): Record<string, unknown> => {
    const runtime = {
        ...(node.runtime ?? {})
    };
    const inspector = (node as { inspector?: { code?: string; markdown?: string } }).inspector;

    if (typeof runtime.code !== 'string' && typeof inspector?.code === 'string') {
        runtime.code = inspector.code;
    }
    if (typeof runtime.markdown !== 'string' && typeof inspector?.markdown === 'string') {
        runtime.markdown = inspector.markdown;
    }

    return runtime;
};

const normalizeStepOverrides = (overrides: Parameters<typeof baseWorkflowExecutor.executeNodeStep>[0]['overrides']): Parameters<typeof baseWorkflowExecutor.executeNodeStep>[0]['overrides'] => {
    if (!overrides) return overrides;

    return {
        ...overrides,
        properties: {
            ...(overrides.properties ?? {}),
            ...(typeof overrides.code === 'string' ? { code: overrides.code } : {}),
            ...(typeof overrides.markdown === 'string' ? { markdown: overrides.markdown } : {})
        }
    };
};

const withExecutableNodeRuntime = (workflow: ExecutorWorkflow, targetNodeId?: string, overrides?: Parameters<typeof baseWorkflowExecutor.executeNodeStep>[0]['overrides']): ExecutorWorkflow => ({
    ...workflow,
    nodes: workflow.nodes.map((node): ExecutorNode => {
        const runtime = buildSynchronizedRuntime(node);

        if (node.id !== targetNodeId || !overrides) {
            return {
                ...node,
                runtime
            };
        }

        return {
            ...node,
            runtime: {
                ...runtime,
                ...(overrides.properties ?? {}),
                ...(typeof overrides.code === 'string' ? { code: overrides.code } : {}),
                ...(typeof overrides.markdown === 'string' ? { markdown: overrides.markdown } : {})
            }
        };
    })
});

export const workflowExecutor = {
    ...baseWorkflowExecutor,
    executeWorkflow: (workflow: Parameters<typeof baseWorkflowExecutor.executeWorkflow>[0], options: Parameters<typeof baseWorkflowExecutor.executeWorkflow>[1]) =>
        baseWorkflowExecutor.executeWorkflow(withNodeExecutors(withExecutableNodeRuntime(workflow)) as Parameters<typeof baseWorkflowExecutor.executeWorkflow>[0], options),
    executeNodeStep: (options: Parameters<typeof baseWorkflowExecutor.executeNodeStep>[0]) => {
        const normalizedOverrides = normalizeStepOverrides(options.overrides);
        return baseWorkflowExecutor.executeNodeStep({
            ...options,
            overrides: normalizedOverrides,
            workflow: withNodeExecutors(withExecutableNodeRuntime(options.workflow, options.nodeId, normalizedOverrides)) as Parameters<typeof baseWorkflowExecutor.executeNodeStep>[0]['workflow']
        });
    }
};

export const workflowExecutorHostContext = createWorkflowExecutorHostContext();
