import { WorkflowNodeSchema } from '@workflow/nodes/types';

export interface WorkflowBackendDescriptor {
    key?: string;
    modelId: string;
    service?: string;
    function?: string;
    description: string;
}

const RAW_SCHEMA_MODULES = import.meta.glob('../nodes/**/*-schema.json', {
    eager: true,
    import: 'default'
}) as Record<string, WorkflowNodeSchema>;

const toStringValue = (value: unknown, fallback = ''): string => {
    const parsed = String(value ?? '').trim();
    return parsed.length > 0 ? parsed : fallback;
};

const buildDescriptorByModelId = (): Record<string, WorkflowBackendDescriptor> => {
    return Object.values(RAW_SCHEMA_MODULES).reduce<Record<string, WorkflowBackendDescriptor>>((acc, schema) => {
        const modelId = toStringValue(schema.id);
        const backend = schema.documentation?.backend;
        const key = toStringValue(backend?.key ?? backend?.handler ?? backend?.action);
        const service = toStringValue(backend?.service);
        const fn = toStringValue(backend?.handler ?? backend?.action);
        if (!modelId || !key) return acc;
        acc[modelId] = {
            modelId,
            key,
            service,
            function: fn,
            description: toStringValue(schema.documentation?.summary, `${modelId} backend execution.`)
        };
        return acc;
    }, {});
};

export const WORKFLOW_BACKEND_DESCRIPTOR_BY_MODEL_ID = buildDescriptorByModelId();
