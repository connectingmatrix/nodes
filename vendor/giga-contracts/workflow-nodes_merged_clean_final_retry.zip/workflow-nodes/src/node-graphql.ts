export type WorkflowNodeGraphqlAction = "build" | "validate" | "run";

export interface WorkflowNodeGraphqlFileInput {
  fileName: string;
  content: string;
}

export interface WorkflowNodeGraphqlInput {
  id?: string | null;
  name?: string | null;
  slug?: string | null;
  description?: string | null;
  nodeSchema?: Record<string, unknown> | null;
  sourceFiles?: Record<string, string> | WorkflowNodeGraphqlFileInput[] | null;
  input?: Record<string, unknown> | null;
  metadata?: Record<string, unknown> | null;
  timeoutSeconds?: number | null;
}

export const WORKFLOW_NODE_GRAPHQL_MUTATIONS: Record<
  WorkflowNodeGraphqlAction,
  string
> = {
  build: `mutation GigaBuildWorkflowNodePackage($input: WorkflowUserNodeInput!) { workflowBuildNodePackage(input: $input) { action contentBase64 fileName files manifest report size } }`,
  validate: `mutation GigaValidateWorkflowNode($input: WorkflowUserNodeInput!) { workflowValidateUserNode(input: $input) { ok errors warnings files } }`,
  run: `mutation GigaRunWorkflowNode($input: WorkflowUserNodeRunInput!) { workflowRunUserNode(input: $input) { ok output errors logs processId } }`,
};

const sourceFileRecord = (
  sourceFiles: WorkflowNodeGraphqlInput["sourceFiles"],
): Record<string, string> => {
  if (!sourceFiles) return {};
  if (Array.isArray(sourceFiles)) {
    return Object.fromEntries(
      sourceFiles.map((file) => [file.fileName, file.content]),
    );
  }
  return sourceFiles;
};

const draftInput = (input: WorkflowNodeGraphqlInput) => ({
  name: input.name || input.slug || "User Node",
  slug: input.slug || input.name || "user-node",
  description: input.description || null,
  nodeSchema: input.nodeSchema || {},
  sourceFiles: sourceFileRecord(input.sourceFiles),
  isActive: true,
});

export const workflowNodeGraphqlMutation = (
  action: WorkflowNodeGraphqlAction,
): string => WORKFLOW_NODE_GRAPHQL_MUTATIONS[action];

export const workflowNodeGraphqlVariables = (
  action: WorkflowNodeGraphqlAction,
  input: WorkflowNodeGraphqlInput,
) => {
  if (action === "run") {
    return {
      input: {
        id: input.id || null,
        draft: input.id ? null : draftInput(input),
        input: input.input || {},
        timeoutSeconds: input.timeoutSeconds || null,
      },
    };
  }
  return { input: draftInput(input) };
};
