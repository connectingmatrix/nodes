import { WORKFLOW_BACKEND_DESCRIPTOR_BY_MODEL_ID } from '../executor/backend-registry';
import { getAllNodeSchemas, getNodeLibraryItems, getNodeModuleById, NODE_MODULES, resolveNodeSchema } from '../node-utils';
import type { WorkflowBackendDescriptor } from '../executor/backend-registry';
import type { WorkflowNodeModule } from '../node-utils/node-module.types';
import type { WorkflowNodeSchema } from '../types';

export interface WorkerPayloadDescriptor {
    descriptor: WorkflowBackendDescriptor | null;
    modelId: string;
    payload: Record<string, unknown>;
}

export interface GigaNodeCatalog {
    modules: WorkflowNodeModule[];
    getAllNodeSchemas: () => Record<string, WorkflowNodeSchema>;
    getNodeLibraryItems: () => ReturnType<typeof getNodeLibraryItems>;
    getNodeModuleById: typeof getNodeModuleById;
    resolveNodeSchema: typeof resolveNodeSchema;
    isLocalCapableNodeModel: (modelId: string | undefined) => boolean;
    isServerOnlyNodeModel: (modelId: string | undefined) => boolean;
    getBackendDescriptor: (modelId: string | undefined) => WorkflowBackendDescriptor | null;
    getBackendDescriptorByModelId: () => Record<string, WorkflowBackendDescriptor>;
    buildWorkerPayloadDescriptor: (params: { modelId: string; payload?: Record<string, unknown> }) => WorkerPayloadDescriptor;
}

const isLocalCapableNodeModel = (modelId: string | undefined): boolean => {
    if (!modelId) return false;
    return Boolean(getNodeModuleById(modelId)?.ui?.localCapable);
};

const isServerOnlyNodeModel = (modelId: string | undefined): boolean => {
    if (!modelId) return false;
    return Boolean(getNodeModuleById(modelId)?.ui?.serverOnly);
};

const getBackendDescriptor = (modelId: string | undefined): WorkflowBackendDescriptor | null => {
    if (!modelId) return null;
    return WORKFLOW_BACKEND_DESCRIPTOR_BY_MODEL_ID[modelId] ?? null;
};

export const createGigaNodeCatalog = (): GigaNodeCatalog => {
    return {
        modules: [...NODE_MODULES],
        getAllNodeSchemas,
        getNodeLibraryItems,
        getNodeModuleById,
        resolveNodeSchema,
        isLocalCapableNodeModel,
        isServerOnlyNodeModel,
        getBackendDescriptor,
        getBackendDescriptorByModelId: () => ({ ...WORKFLOW_BACKEND_DESCRIPTOR_BY_MODEL_ID }),
        buildWorkerPayloadDescriptor: ({ modelId, payload = {} }) => ({
            modelId,
            payload,
            descriptor: getBackendDescriptor(modelId)
        })
    };
};
