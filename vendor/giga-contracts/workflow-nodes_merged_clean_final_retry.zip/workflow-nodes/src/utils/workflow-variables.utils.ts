import { WorkflowNodeFieldDefinition } from '@workflow/nodes/types';

export const WORKFLOW_VARIABLE_TOKEN_REGEX = /\{\{\s*([^}]+?)\s*\}\}/g;
const WORKFLOW_VARIABLE_FULL_TOKEN_REGEX = /^\s*\{\{\s*([^}]+?)\s*\}\}\s*$/;
const WORKFLOW_VARIABLE_CONTAINS_REGEX = /\{\{\s*[^}]+?\s*\}\}/;

const isObjectRecord = (value: unknown): value is Record<string, unknown> => typeof value === 'object' && value !== null && !Array.isArray(value);

const normalizePath = (rawPath: string): string => rawPath.replace(/\[(\d+)\]/g, '.$1').trim();

export interface WorkflowVariableTokenMatch {
    token: string;
    path: string;
    start: number;
    end: number;
}

export interface WorkflowVariableSuggestion {
    path: string;
    token: string;
    label: string;
    preview?: string;
}

export type WorkflowVariableTokenStatus = 'resolved' | 'unresolved';

export interface WorkflowVariableTokenState extends WorkflowVariableTokenMatch {
    status: WorkflowVariableTokenStatus;
    value: unknown;
}

export interface WorkflowVariableResolutionResult {
    value: unknown;
    unresolved: string[];
}

export const formatWorkflowVariablePreviewValue = (value: unknown): string => {
    if (typeof value === 'string') return value;
    if (typeof value === 'number' || typeof value === 'boolean') return String(value);
    if (value === null) return 'null';
    if (typeof value === 'undefined') return '';
    try {
        return JSON.stringify(value);
    } catch {
        return String(value);
    }
};

const stringifyPreviewValue = (value: unknown): string => formatWorkflowVariablePreviewValue(value);

const stringifyReplacementValue = (value: unknown): string => {
    if (typeof value === 'string') return value;
    if (typeof value === 'number' || typeof value === 'boolean') return String(value);
    if (value === null) return 'null';
    if (typeof value === 'undefined') return '';
    try {
        return JSON.stringify(value);
    } catch {
        return String(value);
    }
};

export const buildVariableToken = (path: string): string => `{{${path}}}`;

export const containsVariableToken = (value: unknown): value is string => typeof value === 'string' && WORKFLOW_VARIABLE_CONTAINS_REGEX.test(value);

export const extractVariableTokens = (value: string): WorkflowVariableTokenMatch[] => {
    const matches = value.matchAll(WORKFLOW_VARIABLE_TOKEN_REGEX);
    const result: WorkflowVariableTokenMatch[] = [];
    for (const match of matches) {
        const rawPath = typeof match[1] === 'string' ? match[1].trim() : '';
        if (!rawPath) continue;
        const token = match[0];
        const start = match.index ?? 0;
        result.push({
            token,
            path: rawPath,
            start,
            end: start + token.length
        });
    }
    return result;
};

export const resolveWorkflowVariablePath = (path: string, context: Record<string, unknown>): unknown => {
    const normalized = normalizePath(path);
    if (!normalized) return undefined;
    const segments = normalized.split('.').filter(Boolean);
    let current: unknown = context;
    for (const segment of segments) {
        if (!current || typeof current !== 'object') return undefined;
        current = (current as Record<string, unknown>)[segment];
    }
    return current;
};

const replaceTokensInString = (source: string, context: Record<string, unknown>): WorkflowVariableResolutionResult => {
    const fullTokenMatch = source.match(WORKFLOW_VARIABLE_FULL_TOKEN_REGEX);
    const unresolved: string[] = [];
    if (fullTokenMatch) {
        const fullTokenPath = fullTokenMatch[1]?.trim();
        if (!fullTokenPath) {
            return { value: source, unresolved };
        }
        const resolvedFullValue = resolveWorkflowVariablePath(fullTokenPath, context);
        if (typeof resolvedFullValue === 'undefined') {
            unresolved.push(fullTokenPath);
            return { value: source, unresolved };
        }
        if (typeof resolvedFullValue === 'number' || typeof resolvedFullValue === 'boolean' || resolvedFullValue === null) {
            return { value: String(resolvedFullValue), unresolved };
        }
        return { value: resolvedFullValue, unresolved };
    }

    const value = source.replace(WORKFLOW_VARIABLE_TOKEN_REGEX, (token, pathRaw) => {
        const path = String(pathRaw ?? '').trim();
        if (!path) return token;
        const resolved = resolveWorkflowVariablePath(path, context);
        if (typeof resolved === 'undefined') {
            unresolved.push(path);
            return token;
        }
        return stringifyReplacementValue(resolved);
    });

    return { value, unresolved };
};

export const resolveWorkflowVariables = (value: unknown, context: Record<string, unknown>): WorkflowVariableResolutionResult => {
    if (typeof value === 'string') {
        return replaceTokensInString(value, context);
    }

    if (Array.isArray(value)) {
        const unresolved: string[] = [];
        const resolved = value.map((entry) => {
            const next = resolveWorkflowVariables(entry, context);
            unresolved.push(...next.unresolved);
            return next.value;
        });
        return { value: resolved, unresolved };
    }

    if (isObjectRecord(value)) {
        const unresolved: string[] = [];
        const resolved = Object.entries(value).reduce<Record<string, unknown>>((acc, [key, entry]) => {
            const next = resolveWorkflowVariables(entry, context);
            unresolved.push(...next.unresolved);
            acc[key] = next.value;
            return acc;
        }, {});
        return { value: resolved, unresolved };
    }

    return { value, unresolved: [] };
};

export const getVariableTokenStates = (value: string, context: Record<string, unknown>): WorkflowVariableTokenState[] => {
    return extractVariableTokens(value).map((token) => {
        const resolvedValue = resolveWorkflowVariablePath(token.path, context);
        return {
            ...token,
            status: typeof resolvedValue === 'undefined' ? 'unresolved' : 'resolved',
            value: resolvedValue
        };
    });
};

const addSuggestionIfMissing = (acc: Map<string, WorkflowVariableSuggestion>, path: string, value: unknown): void => {
    const normalized = path.trim();
    if (!normalized || acc.has(normalized)) return;
    acc.set(normalized, {
        path: normalized,
        token: buildVariableToken(normalized),
        label: normalized,
        preview: stringifyPreviewValue(value)
    });
};

const flattenContextPaths = (value: unknown, basePath: string, collector: Map<string, WorkflowVariableSuggestion>, depth = 0): void => {
    if (depth > 6) return;
    if (Array.isArray(value)) {
        addSuggestionIfMissing(collector, basePath, value);
        value.forEach((item, index) => flattenContextPaths(item, `${basePath}[${index}]`, collector, depth + 1));
        return;
    }
    if (isObjectRecord(value)) {
        addSuggestionIfMissing(collector, basePath, value);
        Object.entries(value).forEach(([key, nested]) => flattenContextPaths(nested, `${basePath}.${key}`, collector, depth + 1));
        return;
    }
    addSuggestionIfMissing(collector, basePath, value);
};

export const buildVariableSuggestionsFromContext = (context: Record<string, unknown>, roots: string[] = ['input']): WorkflowVariableSuggestion[] => {
    const collector = new Map<string, WorkflowVariableSuggestion>();
    roots.forEach((root) => {
        const rootValue = context[root];
        if (typeof rootValue === 'undefined') return;
        flattenContextPaths(rootValue, root, collector);
    });
    return Array.from(collector.values()).sort((left, right) => left.path.localeCompare(right.path));
};

export const resolveFieldAllowVariables = (fieldKey: string, definition: WorkflowNodeFieldDefinition | undefined): boolean => {
    if (!definition) return true;
    if (typeof definition.allowVariables === 'boolean') return definition.allowVariables;
    const normalizedKey = fieldKey.trim().toLowerCase();
    if (definition.hidden || definition.auto) return false;
    if (normalizedKey === 'status' || normalizedKey === 'source' || normalizedKey === 'timestamp' || normalizedKey === 'nodelibraryid') return false;
    if (definition.type === 'boolean' || definition.type === 'number' || definition.type === 'timestamp' || definition.type === 'file' || definition.type === 'file-list') return false;
    return definition.editable !== false;
};

export const filterVariableSuggestions = (suggestions: WorkflowVariableSuggestion[], query: string): WorkflowVariableSuggestion[] => {
    const normalizedQuery = query.trim().toLowerCase();
    if (!normalizedQuery) return suggestions;
    return suggestions.filter((item) => item.path.toLowerCase().includes(normalizedQuery));
};
