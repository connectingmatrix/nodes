type WorkflowNodeLike = {
    id?: string;
    modelId?: string;
};

type WorkflowWithNodes = {
    nodes?: WorkflowNodeLike[];
    NODE_EXECUTORS?: Record<string, string>;
    NODE_EXECUTOR_SIGNATURES?: Record<string, string>;
    NODE_SOURCE_FILES?: Record<string, string>;
};

const RAW_WORKER_SOURCES = import.meta.glob('../nodes/**/worker.ts', {
    eager: true,
    import: 'default',
    query: '?raw'
}) as Record<string, string>;
const RAW_NODE_TS_SOURCES = import.meta.glob('../nodes/**/*.ts', {
    eager: true,
    import: 'default',
    query: '?raw'
}) as Record<string, string>;

const RAW_SCHEMA_SOURCES = import.meta.glob('../nodes/**/*-schema.json', {
    eager: true,
    import: 'default',
    query: '?raw'
}) as Record<string, string>;

const textEncoder = new TextEncoder();

const toBase64 = (source: string): string => {
    const bytes = textEncoder.encode(source);
    const bufferCtor = (globalThis as { Buffer?: { from: (value: Uint8Array) => { toString: (encoding: string) => string } } }).Buffer;
    if (bufferCtor) {
        return bufferCtor.from(bytes).toString('base64');
    }

    let binary = '';
    bytes.forEach((byte) => {
        binary += String.fromCharCode(byte);
    });
    return btoa(binary);
};

const computeSignature = (modelId: string, source: string): string => {
    let hash = 5381;
    const input = `${modelId}:${source}`;
    for (let index = 0; index < input.length; index += 1) {
        hash = ((hash << 5) + hash) ^ input.charCodeAt(index);
    }
    return `wf-sign-v1-${(hash >>> 0).toString(16)}`;
};

const resolveWorkerSourceByModelId = (): Record<string, string> => {
    const modelIdByDirectory = Object.entries(RAW_SCHEMA_SOURCES).reduce<Record<string, string>>((acc, [schemaPath, rawSchema]) => {
        const directory = schemaPath.slice(0, schemaPath.lastIndexOf('/'));
        try {
            const parsed = JSON.parse(rawSchema) as { id?: unknown };
            if (typeof parsed.id !== 'string' || parsed.id.trim().length === 0) return acc;
            acc[directory] = parsed.id.trim();
        } catch {
            // Ignore malformed schema payload.
        }
        return acc;
    }, {});

    return Object.entries(RAW_WORKER_SOURCES).reduce<Record<string, string>>((acc, [workerPath, source]) => {
        const directory = workerPath.slice(0, workerPath.lastIndexOf('/'));
        const modelId = modelIdByDirectory[directory];
        if (!modelId) return acc;
        acc[modelId] = source;
        return acc;
    }, {});
};

const WORKER_SOURCE_BY_MODEL_ID = resolveWorkerSourceByModelId();
const SOURCE_FILES_BY_MODEL_ID = Object.entries(RAW_NODE_TS_SOURCES).reduce<Record<string, Record<string, string>>>((acc, [sourcePath, source]) => {
    const directory = sourcePath.slice(0, sourcePath.lastIndexOf('/'));
    const schemaPath = `${directory}/${directory.slice(directory.lastIndexOf('/') + 1)}-schema.json`;
    const schema = RAW_SCHEMA_SOURCES[schemaPath];
    if (!schema) return acc;
    let modelId = '';
    try {
        modelId = String((JSON.parse(schema) as { id?: string }).id || '').trim();
    } catch {
        modelId = '';
    }
    if (!modelId) return acc;
    const fileName = sourcePath.slice(sourcePath.lastIndexOf('/') + 1);
    if (!acc[modelId]) acc[modelId] = {};
    acc[modelId][fileName] = source;
    return acc;
}, {});

export const buildNodeExecutorPayload = (workflow: Pick<WorkflowWithNodes, 'nodes'>): { NODE_EXECUTORS: Record<string, string>; NODE_EXECUTOR_SIGNATURES: Record<string, string> } => {
    const modelIds = new Set((Array.isArray(workflow.nodes) ? workflow.nodes : []).map((node) => node.modelId).filter((modelId): modelId is string => typeof modelId === 'string' && modelId.trim().length > 0));

    const NODE_EXECUTORS: Record<string, string> = {};
    const NODE_EXECUTOR_SIGNATURES: Record<string, string> = {};

    modelIds.forEach((modelId) => {
        const workerSource = WORKER_SOURCE_BY_MODEL_ID[modelId];
        if (typeof workerSource !== 'string' || workerSource.trim().length === 0) return;
        NODE_EXECUTORS[modelId] = toBase64(workerSource);
        NODE_EXECUTOR_SIGNATURES[modelId] = computeSignature(modelId, workerSource);
    });

    return {
        NODE_EXECUTORS,
        NODE_EXECUTOR_SIGNATURES
    };
};

export const withNodeExecutors = <T extends WorkflowWithNodes>(workflow: T): T => {
    const nextExecutors = buildNodeExecutorPayload(workflow);
    const NODE_SOURCE_FILES = Object.keys(nextExecutors.NODE_EXECUTORS).reduce<Record<string, string>>((acc, modelId) => {
        const files = SOURCE_FILES_BY_MODEL_ID[modelId];
        if (!files || !Object.keys(files).length) return acc;
        acc[modelId] = toBase64(JSON.stringify(files));
        return acc;
    }, {});
    return {
        ...workflow,
        NODE_EXECUTORS: nextExecutors.NODE_EXECUTORS,
        NODE_EXECUTOR_SIGNATURES: nextExecutors.NODE_EXECUTOR_SIGNATURES,
        NODE_SOURCE_FILES
    };
};

export const createNodeExecutorSignature = computeSignature;

export const runNodeWorkerInit = async (args: { workflow: WorkflowWithNodes; modelId: string; nodeId: string }): Promise<boolean> => {
    const source = WORKER_SOURCE_BY_MODEL_ID[args.modelId];
    if (typeof source !== 'string' || source.trim().length === 0) return false;
    const hasNode = Array.isArray(args.workflow.nodes) && args.workflow.nodes.some((item) => item.id === args.nodeId);
    return hasNode;
};
