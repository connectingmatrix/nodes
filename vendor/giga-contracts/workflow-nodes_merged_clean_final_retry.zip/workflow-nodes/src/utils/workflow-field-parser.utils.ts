import { WorkflowNodeFieldDefinition, WorkflowNodeFieldMap, WorkflowNodeFieldTypeEnum, WorkflowNodeFileValue } from '@workflow/nodes/types';
import { buildObjectArrayEditorRows, serializeObjectArrayEditorRows } from '@workflow/nodes/utils/workflow-object-array.utils';
import { containsVariableToken, resolveFieldAllowVariables } from '@workflow/nodes/utils/workflow-variables.utils';

const TEXT_LIKE_EXTENSIONS = ['.txt', '.md', '.markdown', '.json', '.csv', '.xml', '.html', '.htm', '.js', '.ts', '.tsx', '.jsx'];
const TEXT_LIKE_MIME = ['application/json', 'application/xml', 'application/javascript', 'application/x-javascript', 'application/csv', 'text/csv'];

const isObjectRecord = (value: unknown): value is Record<string, unknown> => typeof value === 'object' && value !== null && !Array.isArray(value);
const isString = (value: unknown): value is string => typeof value === 'string';

const cloneDeepValue = (value: unknown): unknown => {
    if (value === undefined) return undefined;
    try {
        return JSON.parse(JSON.stringify(value));
    } catch {
        return value;
    }
};

const stringifyJson = (value: unknown): string => {
    try {
        return JSON.stringify(value, null, 2);
    } catch {
        return String(value);
    }
};

const isTextLikeFile = (file: File): boolean => {
    const lowerMimeType = (file.type ?? '').toLowerCase();
    if (lowerMimeType.startsWith('text/')) return true;
    if (TEXT_LIKE_MIME.includes(lowerMimeType)) return true;
    const lowerName = (file.name ?? '').toLowerCase();
    return TEXT_LIKE_EXTENSIONS.some((suffix) => lowerName.endsWith(suffix));
};

const parseDefaultFieldValue = (definition: WorkflowNodeFieldDefinition): unknown => {
    if (definition.defaultValue !== undefined) return cloneDeepValue(definition.defaultValue);
    switch (definition.type) {
        case WorkflowNodeFieldTypeEnum.Boolean:
            return false;
        case WorkflowNodeFieldTypeEnum.Number:
            return 0;
        case WorkflowNodeFieldTypeEnum.Json:
            return '{}';
        case WorkflowNodeFieldTypeEnum.ObjectArray:
            return [];
        case WorkflowNodeFieldTypeEnum.Select:
            return definition.multi ? [] : '';
        case WorkflowNodeFieldTypeEnum.Timestamp:
            return new Date().toISOString();
        default:
            return '';
    }
};

const encodeFileToBase64 = async (file: File): Promise<string> => {
    const bytes = new Uint8Array(await file.arrayBuffer());
    let binary = '';
    const chunkSize = 0x8000;
    for (let index = 0; index < bytes.length; index += chunkSize) {
        binary += String.fromCharCode(...bytes.subarray(index, index + chunkSize));
    }
    return btoa(binary);
};

const parseNumericValue = (value: unknown): number => {
    if (typeof value === 'number' && Number.isFinite(value)) return value;
    const parsed = Number(String(value ?? '').trim());
    return Number.isNaN(parsed) ? 0 : parsed;
};

const parseBooleanValue = (value: unknown): boolean => {
    if (typeof value === 'boolean') return value;
    const normalized = String(value ?? '')
        .trim()
        .toLowerCase();
    return normalized === 'true' || normalized === '1' || normalized === 'yes';
};

const parseJsonValue = (value: unknown): unknown => {
    if (!isString(value)) return value;
    const normalized = value.trim();
    if (!normalized) return {};
    try {
        return JSON.parse(normalized);
    } catch {
        return {};
    }
};

const parseFileEnvelope = (value: unknown): WorkflowNodeFileValue | undefined => {
    if (isObjectRecord(value) && isString(value.name) && isString(value.mimeType) && typeof value.size === 'number' && value.encoding === 'base64' && isString(value.contentBase64)) {
        return {
            name: value.name,
            mimeType: value.mimeType,
            size: value.size,
            encoding: 'base64',
            contentBase64: value.contentBase64,
            extractedText: isString(value.extractedText) ? value.extractedText : undefined
        };
    }

    if (!isString(value)) return undefined;
    try {
        return parseFileEnvelope(JSON.parse(value));
    } catch {
        return undefined;
    }
};

const parseFileEnvelopeList = (value: unknown): WorkflowNodeFileValue[] => {
    if (!Array.isArray(value)) return [];
    return value.map((item) => parseFileEnvelope(item)).filter((item): item is WorkflowNodeFileValue => Boolean(item));
};

const parseSelectMultiValues = (value: unknown): string[] => {
    if (!Array.isArray(value)) return [];
    const values: string[] = [];
    value.forEach((item) => {
        const parsed = isString(item) ? item.trim() : String(item ?? '').trim();
        if (!parsed) return;
        values.push(parsed);
    });
    return values;
};

export const parseNodeProperties = (fields: WorkflowNodeFieldMap, properties: Record<string, unknown> = {}): Record<string, unknown> => {
    const parsed: Record<string, unknown> = { ...properties };
    Object.entries(fields).forEach(([fieldName, definition]) => {
        const current = parsed[fieldName];
        const isMissing = current === undefined || current === null || current === '';
        if (!isMissing) return;
        if (definition.auto || definition.defaultValue !== undefined || !Object.prototype.hasOwnProperty.call(parsed, fieldName)) {
            parsed[fieldName] = parseDefaultFieldValue(definition);
        }
    });
    return parsed;
};

export const buildEditorPropertiesState = (fields: WorkflowNodeFieldMap, properties: Record<string, unknown> = {}): Record<string, unknown> => {
    const parsed = parseNodeProperties(fields, properties);
    return Object.entries(parsed).reduce<Record<string, unknown>>((acc, [fieldName, value]) => {
        const definition = fields[fieldName];
        if (definition?.type === WorkflowNodeFieldTypeEnum.Json && !isString(value)) {
            acc[fieldName] = stringifyJson(value);
            return acc;
        }
        if (definition?.type === WorkflowNodeFieldTypeEnum.ObjectArray) {
            acc[fieldName] = buildObjectArrayEditorRows(definition, value);
            return acc;
        }
        acc[fieldName] = value;
        return acc;
    }, {});
};

export const parseEditorPropertyValues = (fields: WorkflowNodeFieldMap, properties: Record<string, unknown>): Record<string, unknown> => {
    const parsed = parseNodeProperties(fields, properties);
    return Object.entries(parsed).reduce<Record<string, unknown>>((acc, [fieldName, value]) => {
        const definition = fields[fieldName];
        if (!definition) {
            acc[fieldName] = value;
            return acc;
        }
        const allowVariables = resolveFieldAllowVariables(fieldName, definition);
        if (allowVariables && containsVariableToken(value)) {
            acc[fieldName] = String(value);
            return acc;
        }
        switch (definition.type) {
            case WorkflowNodeFieldTypeEnum.Number:
                acc[fieldName] = parseNumericValue(value);
                break;
            case WorkflowNodeFieldTypeEnum.Boolean:
                acc[fieldName] = parseBooleanValue(value);
                break;
            case WorkflowNodeFieldTypeEnum.Json:
            case WorkflowNodeFieldTypeEnum.Headers:
                acc[fieldName] = parseJsonValue(value);
                break;
            case WorkflowNodeFieldTypeEnum.ObjectArray:
                acc[fieldName] = serializeObjectArrayEditorRows(definition, value);
                break;
            case WorkflowNodeFieldTypeEnum.File:
                acc[fieldName] = parseFileEnvelope(value);
                break;
            case WorkflowNodeFieldTypeEnum.FileList:
                acc[fieldName] = parseFileEnvelopeList(value);
                break;
            case WorkflowNodeFieldTypeEnum.Method:
            case WorkflowNodeFieldTypeEnum.Select:
                acc[fieldName] = definition.multi ? parseSelectMultiValues(Array.isArray(value) ? value : definition.defaultValue) : String(value ?? definition.defaultValue ?? '');
                break;
            case WorkflowNodeFieldTypeEnum.Timestamp:
                acc[fieldName] = String(value ?? parseDefaultFieldValue(definition));
                break;
            case WorkflowNodeFieldTypeEnum.Markdown:
            default:
                acc[fieldName] = isString(value) ? value : String(value ?? '');
        }
        return acc;
    }, {});
};

export const parseWorkflowFileValue = async (file: File): Promise<WorkflowNodeFileValue> => {
    const parsedFile: WorkflowNodeFileValue = {
        name: file.name,
        mimeType: file.type || 'application/octet-stream',
        size: file.size,
        encoding: 'base64',
        contentBase64: await encodeFileToBase64(file)
    };

    if (isTextLikeFile(file)) {
        try {
            parsedFile.extractedText = await file.text();
        } catch {
            // Keep base64 envelope if text extraction fails.
        }
    }

    return parsedFile;
};
