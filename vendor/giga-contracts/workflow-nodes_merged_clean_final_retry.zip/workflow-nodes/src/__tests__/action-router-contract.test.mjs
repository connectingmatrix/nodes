import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import test from 'node:test';

const root = new URL('..', import.meta.url).pathname;
const workerSource = readFileSync(join(root, 'nodes', 'action-router', 'worker.ts'), 'utf8');

test('action router keeps parameters inspector-driven and explicit', () => {
    assert.equal(workerSource.includes('runtime.input'), false);
    assert.equal(workerSource.includes('runtime.actionInput'), false);
    assert.equal(workerSource.includes('enrichScopeDefaults'), false);
    assert.match(workerSource, /parameterValue\(runtime\.parameters\)/);
    assert.match(workerSource, /ROUTER_PASS_THROUGH_KEYS = \['chatId', 'message', 'topK', 'subjectIds', 'postIds', 'tagSlugs'\]/);
});
