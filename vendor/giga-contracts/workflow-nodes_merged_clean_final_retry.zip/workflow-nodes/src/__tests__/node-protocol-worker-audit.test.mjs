import assert from 'node:assert/strict';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';
import test from 'node:test';

const root = new URL('..', import.meta.url).pathname;
const worker = (id) => readFileSync(join(root, 'nodes', id, 'worker.ts'), 'utf8');
const walk = (dir) => readdirSync(dir).flatMap((entry) => {
    const path = join(dir, entry);
    return statSync(path).isDirectory() ? walk(path) : [path];
});
const allowedBackendNodes = new Set([
    'analyze-text-with-model',
    'claude',
    'current-chat',
    'deepseek',
    'execute-workflow',
    'gemini',
    'groq',
    'mcp-capabilities',
    'mcp-runtime',
    'mistral',
    'openai',
    'perplexity',
    'rcm-csv-stream-profiler',
    'rcm-decision-tree-trainer',
    'rcm-feature-builder',
    'rcm-knowledge-publisher',
    'rcm-model-scorer',
    'rcm-neural-net-trainer',
    'run-category-action',
    'run-channel-action',
    'run-chat-action',
    'run-post-action',
    'run-subject-action',
    'run-user-tree-action',
    'serp-search',
    'shared-space',
    'workflow',
    'workflow-artifact-publish',
    'workflow-file-download',
    'workflow-file-inspect'
]);

test('AI Agent flow-control workers do not scrape raw input ports', () => {
    for (const id of ['if-else', 'merge', 'respond-end']) {
        assert.equal(worker(id).includes('PORTS'), false, `${id} must read declared runtime fields only`);
    }
});

test('executeBackend usage stays limited to backend-dependent workers', () => {
    const callers = walk(join(root, 'nodes'))
        .filter((path) => path.endsWith('/worker.ts'))
        .filter((path) => readFileSync(path, 'utf8').includes('executeBackend('))
        .map((path) => path.split('/nodes/')[1].split('/')[0])
        .filter((id) => !allowedBackendNodes.has(id));
    assert.deepEqual(callers, []);
});

test('package source does not embed Giga GraphQL tables or backend service paths', () => {
    const forbidden = ['ai_workflows' + 'Collection', 'insertInto' + 'ai_', 'ai_chat_messages' + 'Collection', 'services/workflow/nodes/' + 'node-handlers.ts'];
    const offenders = walk(root).filter((path) => /\.(ts|tsx|json|md|txt)$/.test(path)).filter((path) => forbidden.some((token) => readFileSync(path, 'utf8').includes(token)));
    assert.deepEqual(offenders, []);
});

test('chart node is worker owned without backend descriptors', () => {
    const source = worker('chart');
    assert.equal(source.includes('executeBackend('), false);
    assert.equal(source.includes('@workflow/charts'), true);
    assert.match(source, /server-worker only/);
});

test('AI Agent accepts command-capable user nodes as tools', () => {
    const source = worker('ai-agent');
    assert.match(source, /modelId\.startsWith\('user-node:'\)/);
    assert.match(source, /commandToolSpec\(\):/);
    assert.match(source, /Action Router, Chart, or user nodes/);
    assert.match(source, /Connected command peers must expose commandToolSpec/);
    assert.match(source, /workflow: new Set\(\['workflow', 'execute-workflow'\]\)/);
    assert.match(source, /hasRcmTools/);
    assert.match(source, /rcmToolIntent/);
    assert.match(source, /rcmDecisionTreeIntent/);
    assert.match(source, /rcmNeuralNetIntent/);
    assert.match(source, /rcmIntentPlan/);
    assert.match(source, /rcmKind/);
    assert.match(source, /rcmDatasetLocatorIntent/);
    assert.match(source, /peer\.snapshot\.runtime\)\.parameters/);
});
