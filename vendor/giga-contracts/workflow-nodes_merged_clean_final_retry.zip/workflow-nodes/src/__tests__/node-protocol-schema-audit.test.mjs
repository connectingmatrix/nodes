import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import test from 'node:test';

const root = new URL('..', import.meta.url).pathname;
const schema = (id) => JSON.parse(readFileSync(join(root, 'nodes', id, `${id}-schema.json`), 'utf8'));
const aiPathNodes = [
    'ai-agent',
    'action-router',
    'chart',
    'current-chat',
    'execute-workflow',
    'if-else',
    'merge',
    'respond-end',
    'run-category-action',
    'run-channel-action',
    'run-chat-action',
    'run-post-action',
    'run-subject-action',
    'run-user-tree-action',
    'text-analysis',
    'workflow'
];
const allowedJson = new Set([
    'action-router.dependencyResults',
    'current-chat.operationMetadata',
    'current-chat.operationRequestedResolvedScope',
    'current-chat.operationRequestedScope',
    'current-chat.operationRetrievedChunks',
    'current-chat.operationScope',
    'current-chat.operationScopeSnapshot',
    'current-chat.operationSession',
    'current-chat.operationSourceRefs',
    'run-category-action.resultsById',
    'run-channel-action.resultsById',
    'run-chat-action.resultsById',
    'run-post-action.resultsById',
    'run-subject-action.resultsById',
    'run-user-tree-action.resultsById'
]);

test('AI Agent path has no user-authored JSON inspector fields', () => {
    const violations = [];
    for (const id of aiPathNodes) {
        const fields = schema(id).fields || {};
        for (const [key, field] of Object.entries(fields)) {
            if (field.type !== 'json') continue;
            const allowed = allowedJson.has(`${id}.${key}`) && field.hidden === true && field.editable === false;
            if (!allowed) violations.push(`${id}.${key}`);
        }
    }
    assert.deepEqual(violations, []);
});

test('grouped actions expose parameter rows with selectable keys', () => {
    for (const id of aiPathNodes.filter((entry) => entry.startsWith('run-'))) {
        const parameters = schema(id).fields.parameters;
        assert.equal(parameters.type, 'object-array');
        assert.equal(parameters.addButtonLabel, 'Add Parameter');
        assert.equal(parameters.subFields.key.type, 'select');
    }
});
