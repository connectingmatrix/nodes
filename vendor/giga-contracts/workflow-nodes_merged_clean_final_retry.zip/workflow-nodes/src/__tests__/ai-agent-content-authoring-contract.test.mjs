import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import test from 'node:test';

const root = join(process.cwd(), 'src');
const source = readFileSync(join(root, 'nodes', 'ai-agent', 'content-authoring.ts'), 'utf8');

test('AI Agent content authoring plans post moves as post actions', () => {
    assert.match(source, /const postMoveMatch/);
    assert.match(source, /Plan post move operations/);
    assert.match(source, /add\('create_post'/);
    assert.match(source, /add\('update_post'/);
    assert.match(source, /subject_action_id: targetSubject/);
    assert.doesNotMatch(source, /Plan post move operations[\s\S]{0,900}update_subject/);
});

test('AI Agent content authoring plans full content branches before subject-channel shortcuts', () => {
    const fullContentIndex = source.indexOf('const fullContent = fullContentMatch(message)');
    const subjectChannelIndex = source.indexOf('if (has(message, words.subject) && has(message, words.channel)');

    assert.ok(fullContentIndex > -1, 'full content branch planner must exist');
    assert.ok(subjectChannelIndex > -1, 'subject-channel shortcut must exist');
    assert.ok(fullContentIndex < subjectChannelIndex, 'full channel/category/subject/post cases must not use the subject-channel shortcut');
    assert.match(source, /parent_channel_action_id: channel/);
    assert.match(source, /subject_action_id: subject/);
    assert.match(source, /add\('read_post'/);
});

test('AI Agent content authoring plans debug prefix cleanup without LLM routing', () => {
    assert.match(source, /const deletePrefixMatch/);
    assert.match(source, /Plan channel prefix cleanup operations/);
    assert.match(source, /add\('delete_channel', `Delete channel branches starting with/);
    assert.match(source, /name_prefix: deletePrefix/);
    assert.match(source, /!has\(message, words\.create\) && deletePrefix/);
    assert.doesNotMatch(source, /debug-/);
});

test('AI Agent content authoring keeps generic structure requests under a channel root', () => {
    const schema = JSON.parse(readFileSync(join(root, 'nodes', 'ai-agent', 'ai-agent-schema.json'), 'utf8'));

    assert.match(source, /const structureRequest/);
    assert.match(source, /defaultContentStructureRequestPattern/);
    assert.equal(schema.fields.contentAuthoringMode.defaultValue, 'generic-fast-paths');
    assert.equal(schema.fields.contentCleanupPrefixPattern.editable, true);
    assert.equal(schema.fields.contentStructureRequestPattern.editable, true);
    assert.match(source, /parent_channel_action_id: channel/);
    assert.match(source, /parent_category_action_id: parentCategory/);
    assert.match(source, /category_action_id: category/);
    assert.match(source, /structure\.topic/);
    assert.match(source, /structure\.dimensions/);
    assert.doesNotMatch(source, /World Politics/);
    assert.doesNotMatch(source, /worldPoliticsStructure/);
});

test('AI Agent mutation regex covers cleanup phrasing used by matrix cases', () => {
    const worker = readFileSync(join(root, 'nodes', 'ai-agent', 'worker.ts'), 'utf8');
    assert.match(worker, /delete\|deletion\|remove\|removal\|cleanup/);
    assert.match(worker, /data node\|data nodes/);
});

test('AI Agent treats WF-prefixed workflow edits as workflow requests before LLM planning', () => {
    const worker = readFileSync(join(root, 'nodes', 'ai-agent', 'worker.ts'), 'utf8');
    assert.match(worker, /const workflowRequestIntent = input\.workflowRequestIntent === true \|\| isWorkflowAuthoringMessage\(message\)/);
});

test('AI Agent workflow authoring emits executor-compatible literal output bindings', () => {
    const schema = JSON.parse(readFileSync(join(root, 'nodes', 'ai-agent', 'ai-agent-schema.json'), 'utf8'));
    const workflowAuthoring = readFileSync(join(root, 'nodes', 'ai-agent', 'workflow-authoring.ts'), 'utf8');

    assert.doesNotMatch(schema.fields.selectionPromptMd.defaultValue, /\{\{code\.output\}\}/);
    assert.doesNotMatch(schema.fields.selectionPromptMd.defaultValue, /\{\{workflow\.input\./);
    assert.match(workflowAuthoring, /const escapedRuntimeCode = \(text: string\): string => `return \$\{JSON\.stringify\(text\)\};`/);
    assert.match(workflowAuthoring, /response: '\{\{code\.output\}\}'/);
    assert.doesNotMatch(workflowAuthoring, /code\.output\.text/);
    assert.doesNotMatch(workflowAuthoring, /return \{ text:/);
});
