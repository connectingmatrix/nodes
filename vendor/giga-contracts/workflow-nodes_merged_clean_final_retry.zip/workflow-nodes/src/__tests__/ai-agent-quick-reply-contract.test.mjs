import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import test from 'node:test';

const root = join(process.cwd(), 'src');
const schema = JSON.parse(readFileSync(join(root, 'nodes', 'ai-agent', 'ai-agent-schema.json'), 'utf8'));
const workerSource = readFileSync(join(root, 'nodes', 'ai-agent', 'worker.ts'), 'utf8');

test('AI Agent quick replies can answer unsupported post linking before planning', () => {
    const rules = schema.fields.quickReplyRules.defaultValue;
    const unsupportedPostRule = rules.find((rule) => rule.intent === 'Explain unsupported post linking.');

    assert.ok(unsupportedPostRule, 'AI Agent schema must include the node-owned unsupported post linking rule.');
    assert.equal(schema.fields.quickReplyMaxWords.defaultValue, 14);
    assert.match('link post', new RegExp(unsupportedPostRule.pattern, 'i'));
    assert.match(unsupportedPostRule.response, /unsupported/i);
    assert.match(workerSource, /quickReplyMatch\(message, quickReplyRules, quickReplyMaxWords\)/);
    assert.match(workerSource, /if \(quickReply\) return withWarnings/);
});

test('AI Agent quick replies include the Giga Chat product help prompt', () => {
    const rules = schema.fields.quickReplyRules.defaultValue;
    const capabilityRule = rules.find((rule) => rule.intent === 'Reply to a short capability question.');
    const chartOptionsRule = rules.find((rule) => rule.intent === 'Explain chart options.');
    const linkingRule = rules.find((rule) => rule.intent === 'Explain Giga linking.');

    assert.ok(capabilityRule, 'AI Agent schema must include the capability quick reply rule.');
    assert.ok(chartOptionsRule, 'AI Agent schema must include the chart options quick reply rule.');
    assert.ok(linkingRule, 'AI Agent schema must include the linking quick reply rule.');
    assert.match('What can you help me with inside Giga Chat?', new RegExp(capabilityRule.pattern, 'i'));
    assert.match(capabilityRule.response, /Giga chat/i);
    assert.match('What chart options are available?', new RegExp(chartOptionsRule.pattern, 'i'));
    assert.match(chartOptionsRule.response, /Library|Template Inputs/);
    assert.match('Explain how this setup avoids duplicate nodes by linking.', new RegExp(linkingRule.pattern, 'i'));
    assert.match(linkingRule.response, /linking|linked|links/i);
});

test('AI Agent quick replies cover easy Giga product guidance cases', () => {
    const rules = schema.fields.quickReplyRules.defaultValue;
    const patterns = rules.map((rule) => new RegExp(rule.pattern, 'i'));

    for (const message of [
        'Explain the difference between a subject and a post in Giga.',
        'How does Giga organize channels, categories, subjects, and posts?',
        'How do workflow attachments work in Giga chat?',
        'What is the safest way to clean debug nodes in Giga?',
        'How can I structure my knowledge base for world politics?',
        'When should I use workflow mode vs normal chat mode?',
        'What are best practices for naming channels and categories?',
        'How do I keep my user tree clean over time?',
        'Summarize what Giga AI can automate for content ops.',
        'What chart options are available?',
        'Explain how this setup avoids duplicate nodes by linking.',
    ]) {
        assert.equal(patterns.some((pattern) => pattern.test(message)), true, message);
    }
});

test('AI Agent confirmation executes the pending plan before any LLM planning path', () => {
    const confirmationSetup = workerSource.indexOf('const confirmationRequested = confirmationValue(input)');
    const confirmationBranch = workerSource.indexOf('if (confirmationRequested)');
    const planningBranch = workerSource.indexOf('const planned = await selectPlanningPlan');
    const directReplyBranch = workerSource.indexOf('runLlm(payload, directReplyPrompt(input))');

    assert.ok(confirmationSetup > -1, 'confirmation request must be read before planning');
    assert.ok(confirmationBranch > -1, 'confirmation branch must exist');
    assert.ok(confirmationBranch < planningBranch, 'confirmation should bypass planner LLM calls');
    assert.ok(confirmationBranch < directReplyBranch, 'confirmation should bypass direct reply LLM calls');
});
