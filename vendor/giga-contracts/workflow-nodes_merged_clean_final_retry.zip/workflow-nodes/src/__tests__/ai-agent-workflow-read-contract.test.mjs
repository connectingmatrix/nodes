import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import test from 'node:test';

const root = join(process.cwd(), 'src');
const source = readFileSync(join(root, 'nodes', 'ai-agent', 'workflow-read.ts'), 'utf8');
const workerSource = readFileSync(join(root, 'nodes', 'ai-agent', 'worker.ts'), 'utf8');

test('AI Agent has a node-owned workflow read planner before LLM planning', () => {
    assert.match(workerSource, /createWorkflowReadNodePlan/);
    assert.match(workerSource, /const workflowReadPlan = executionMode !== 'execute-plan'/);
    assert.match(workerSource, /workflowReadPlan \? normalizePlan\(workflowReadPlan, peers, indexedPeers\)/);
    assert.ok(workerSource.indexOf('const workflowReadPlan =') < workerSource.indexOf('const planned = await selectPlanningPlan'));
});

test('workflow read planner maps specific reads to get and generic reads to capped list', () => {
    assert.match(source, /operation: 'get'/);
    assert.match(source, /workflowName: name/);
    assert.match(source, /operation: 'list', limit: 10/);
    assert.match(source, /isWorkflowReadMessage/);
});
