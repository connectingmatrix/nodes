import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import test from 'node:test';

const root = new URL('..', import.meta.url).pathname;
const file = (...parts) => readFileSync(join(root, ...parts), 'utf8');
const json = (...parts) => JSON.parse(file(...parts));

test('AI Agent command ports expose strict source compatibility', () => {
    const commands = json('nodes', 'ai-agent', 'ai-agent-schema.json').commands;
    assert.deepEqual(commands.tools.acceptedSourceModelIds, ['action-router', 'chart']);
    assert.deepEqual(commands.workflow.acceptedSourceModelIds, ['workflow', 'execute-workflow']);
});

test('action inspectors use programmatic action-aware field resolvers', () => {
    assert.match(file('nodes', 'action-router', 'action-router-node.ts'), /resolveActionRouterInspectorFields/);
    for (const id of ['run-category-action', 'run-channel-action', 'run-chat-action', 'run-post-action', 'run-subject-action', 'run-user-tree-action']) {
        assert.match(file('nodes', id, `${id}-node.ts`), /resolveGroupedActionInspectorFields/);
    }
});

test('chart node exposes LLM port and programmatic template input options', () => {
    const chart = json('nodes', 'chart', 'chart-schema.json');
    assert.deepEqual(chart.commands.llm.acceptedSourceModelIds, ['openai', 'claude', 'gemini', 'groq', 'deepseek', 'perplexity', 'mistral']);
    assert.equal(chart.fields.selectedInputs.type, 'object-array');
    assert.equal(chart.fields.selectedInputs.subFields.key.type, 'select');
    assert.match(file('nodes', 'chart', 'chart-node.ts'), /withChartOptions/);
});
