import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import test from 'node:test';

const root = join(process.cwd(), 'src');
const source = readFileSync(join(root, 'nodes', 'ai-agent', 'giga-plan-dependencies.ts'), 'utf8');

test('AI Agent dependency inference treats existing ids and names as concrete references', () => {
    assert.match(readFileSync(join(root, 'nodes', 'ai-agent', 'planning.ts'), 'utf8'), /giga-plan-dependencies/);
    assert.match(source, /hasConcreteReference/);
    assert.match(source, /channel_id/);
    assert.match(source, /channel_name/);
    assert.match(source, /category_id/);
    assert.match(source, /category_name/);
    assert.match(source, /subject_id/);
    assert.match(source, /subject_name/);
    assert.match(source, /post_id/);
    assert.match(source, /workflow_id/);
    assert.match(source, /hasReferenceField\(action\.input \|\| \{\}, rule\.referenceKeys\) && !hasConcreteReference\(action\.input \|\| \{\}, rule\.referenceKeys\)/);
});

test('AI Agent dependency inference can keep multiple missing resource dependencies', () => {
    assert.match(source, /const dependencyRuleNames/);
    assert.match(source, /const implicit = dependencyRuleNames\(action\)\.map/);
    assert.match(source, /\.\.\.implicit/);
    assert.equal(source.includes('treeDependencyRules'), false);
    assert.equal(source.includes('workflowDependencyRules'), false);
});
