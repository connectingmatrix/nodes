export type ExecuteBackendDescriptor = {
  key?: string;
  service?: string;
  function?: string;
  description?: string;
};

type BackendExecutor = (descriptor: ExecuteBackendDescriptor, payload?: unknown) => Promise<unknown>;

const readExecutor = (): BackendExecutor => {
  const globalValue = globalThis as typeof globalThis & { __GIGA_EXECUTE_BACKEND__?: BackendExecutor };
  if (typeof globalValue.__GIGA_EXECUTE_BACKEND__ === 'function') return globalValue.__GIGA_EXECUTE_BACKEND__;
  return async (_descriptor, payload) => ({ status: 'warning', output: { message: 'executeBackend bridge is not installed in this runtime.', payload } });
};

export const executeBackend: BackendExecutor = (descriptor, payload) => readExecutor()(descriptor, payload);
export const executeGigaService = executeBackend;
export const invokeConnectedNode = executeBackend;
