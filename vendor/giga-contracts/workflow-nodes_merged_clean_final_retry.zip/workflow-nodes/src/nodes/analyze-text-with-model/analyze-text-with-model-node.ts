import rawSchema from '@workflow/nodes/nodes/analyze-text-with-model/analyze-text-with-model-schema.json';
import { createServerOnlyNodeModule } from '@workflow/nodes/nodes/server-only/server-node.module.factory';

const renderIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <rect x="9" y="8" width="30" height="20" rx="4" stroke="currentColor" stroke-width="2.4"/>
  <path d="M15 32h18M20 38h8" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>
</svg>`;

const nodeModule = createServerOnlyNodeModule({
    id: 'analyze-text-with-model',
    rawSchema,
    library: {
        id: 'analyze-text-with-model-node',
        label: 'Analyze Text',
        description: 'Analyze text with server LLM model.',
        gigaId: 'AnalyzeTextWithModelNode',
        modelId: 'analyze-text-with-model',
        group: 'Server Actions',
        order: 114,
        iconColor: '#0f766e',
        iconBackground: '#dcfce7'
    },
    iconSvg: renderIcon
});

export default nodeModule;
