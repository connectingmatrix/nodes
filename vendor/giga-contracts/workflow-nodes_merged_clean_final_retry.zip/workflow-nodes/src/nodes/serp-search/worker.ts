import type { WorkflowCommandToolSpec, WorkerExecuteResult, WorkerPayload, WorkerScope, WorkerUpdateResult, WorkerValidateResult } from '@workflow/executor';
import { normalizeResult, toErrorResult, toNode, toRecord } from '@workflow/executor';
import { executeBackend } from '@workflow/execute';

const NODE_SCOPE: WorkerScope = {};

type ValidationResult = {
    ok: boolean;
    errors: string[];
    warnings?: string[];
    normalizedRuntime?: Record<string, unknown>;
};

const toRecordValue = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});

const validateLegacy = (context: { node?: unknown; workflow?: unknown; input?: unknown; settings?: unknown }): ValidationResult => {
    const node = toRecordValue(context?.node);
    const runtime = toRecordValue(node.runtime);
    const errors: string[] = [];
    const warnings: string[] = [];

    const failureMitigation = String(runtime.failureMitigation ?? 'stop-workflow').trim();
    if (failureMitigation !== 'retry-node' && failureMitigation !== 'stop-workflow') {
        errors.push('Failure Mitigation must be either "retry-node" or "stop-workflow".');
    }
    if (failureMitigation === 'retry-node') {
        const retryCount = Number(runtime.retryCount);
        if (!Number.isFinite(retryCount) || retryCount < 1 || retryCount > 6) {
            errors.push('Retry Count must be between 1 and 6 when Failure Mitigation is "retry-node".');
        }
    }

    const query = String(runtime.query ?? '').trim();
    if (!query) {
        errors.push('query is required.');
    }
    const maxResults = Number(runtime.max_results ?? 6);
    if (!Number.isFinite(maxResults) || maxResults < 1 || maxResults > 12) {
        errors.push('max_results must be a number between 1 and 12.');
    }

    return {
        ok: errors.length === 0,
        errors,
        warnings,
        normalizedRuntime: runtime
    };
};

const normalizeValidateResult = (result: unknown): WorkerValidateResult => {
    if (result === true || typeof result === 'undefined') {
        return { ok: true, errors: [], warnings: [] };
    }

    if (result === false) {
        return { ok: false, errors: ['Worker validation failed.'], warnings: [] };
    }

    const record = toRecord(result);
    return {
        ok: typeof record.ok === 'boolean' ? record.ok : true,
        errors: Array.isArray(record.errors) ? record.errors.map((entry) => String(entry)).filter((entry) => entry.trim().length > 0) : [],
        warnings: Array.isArray(record.warnings) ? record.warnings.map((entry) => String(entry)).filter((entry) => entry.trim().length > 0) : [],
        normalizedRuntime: toRecord(record.normalizedRuntime)
    };
};

export const validate = async (payload: WorkerPayload): Promise<WorkerValidateResult> => {
    const metadata = toRecord(payload.workflow?.metadata);
    const workflowRuntime = toRecord(metadata.runtime);
    const result = await validateLegacy({
        node: toNode(payload),
        workflow: payload.workflow,
        input: {},
        settings: toRecord(workflowRuntime.settings)
    });
    return normalizeValidateResult(result);
};

export const init = async (payload: WorkerPayload): Promise<boolean> => {
    const metadata = toRecord(payload.workflow?.metadata);
    NODE_SCOPE.workflowId = String(metadata.id ?? '');
    NODE_SCOPE.initialized = true;
    return true;
};

export const onUpdate = async (payload: WorkerPayload): Promise<WorkerUpdateResult> => {
    NODE_SCOPE.lastStatus = payload.self?.status ?? NODE_SCOPE.lastStatus;
    NODE_SCOPE.lastOutput = payload.self?.OUTPUT ?? NODE_SCOPE.lastOutput;
    return { ok: true, error: null };
};

export const commandToolSpec = async (payload: WorkerPayload): Promise<WorkflowCommandToolSpec> => {
    const node = toNode(payload);
    const runtime = toRecordValue(node.runtime);
    return {
        toolName: String(node.name || 'SERP Search').trim() || 'SERP Search',
        toolDescription: String(runtime.description || 'Search the web and return normalized SERP results.').trim(),
        inputContract: {
            required: [{ key: 'query', label: 'Query', description: 'Search query string.' }],
            optional: [{ key: 'max_results', label: 'Max Results', description: 'Desired result count between 1 and 12.' }, { key: 'location', label: 'Location', description: 'Location hint for search.' }, { key: 'language', label: 'Language', description: 'Language code for results.' }]
        },
        outputContract: [{ key: 'items', label: 'Items', description: 'Normalized SERP results.' }],
        metadata: { modelId: node.modelId },
        executionKind: 'tool'
    };
};

export const execute = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => {
    const node = toNode(payload);

    try {
        const result = await executeBackend(
            {
                key: 'executeSerpSearchNode',
                description: 'Runs server-side SERP lookup and returns normalized web results.'
            },
            {
                NODE: node,
                payload,
                NODE_SCOPE
            }
        );
        return normalizeResult(result);
    } catch (error) {
        return toErrorResult(error instanceof Error ? error.message : 'Worker execution failed.');
    }
};
