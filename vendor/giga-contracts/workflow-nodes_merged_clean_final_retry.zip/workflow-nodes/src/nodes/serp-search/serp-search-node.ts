import rawSchema from '@workflow/nodes/nodes/serp-search/serp-search-schema.json';
import { createServerOnlyNodeModule } from '@workflow/nodes/nodes/server-only/server-node.module.factory';

const renderIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <rect x="9" y="8" width="30" height="20" rx="4" stroke="currentColor" stroke-width="2.4"/>
  <path d="M15 32h18M20 38h8" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>
</svg>`;

const nodeModule = createServerOnlyNodeModule({
    id: 'serp-search',
    rawSchema,
    library: {
        id: 'serp-search-node',
        label: 'SERP Search',
        description: 'Search web references using server-side SERP.',
        gigaId: 'SerpSearchNode',
        modelId: 'serp-search',
        group: 'Server Actions',
        order: 113,
        iconColor: '#1d4ed8',
        iconBackground: '#dbeafe'
    },
    iconSvg: renderIcon
});

export default nodeModule;
