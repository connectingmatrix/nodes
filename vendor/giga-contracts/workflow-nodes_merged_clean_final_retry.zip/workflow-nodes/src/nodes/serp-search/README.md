# Serp Search Node

## Runtime Ownership
Worker-first node. The UI/runtime enters through `worker.ts`, and backend execution is delegated through `[backend handler key]#executeSerpSearchNode`.

## Usage
Set query and optional max_results/location/language to collect external references.

## Inputs
- `Control Port: Command`: Bi-directional control-state input from connected command peers.
- `Input Port: Input`: Optional upstream payload.
- `Query`: Search query string sent to SERP provider.
- `Max Results`: Desired result count (backend clamps to 1-12).
- `Location`: Geographic location hint for search.
- `Language`: Language hint for search (hl).

## Outputs
- `Control Port: Command`: Publishes this node control state for connected command peers.
- `Output Port: Output`: Emits SERP response payload.
- `items`: Array of normalized search results.
- `query/engine`: Resolved query and engine metadata.

## Backend Mapping
- Source: `/Users/abeer/dev/giga/giga-ai-backend/src/[backend handler key]`
- Handler: `executeSerpSearchNode`

## Failure Cases
- Fails when query is missing.
- Fails when SERP provider call returns an error.
