import { WorkflowNodeModule, WorkflowNodeUiConfig } from '@workflow/nodes/node-utils/node-module.types';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { WorkflowNodeKindEnum } from '@workflow/nodes/types';

interface CreateServerOnlyNodeModuleArgs {
    id: string;
    rawSchema: unknown;
    library: {
        id: string;
        label: string;
        description: string;
        gigaId: string;
        modelId: string;
        order: number;
        group?: string;
        iconColor: string;
        iconBackground: string;
        defaultKind?: WorkflowNodeKindEnum;
    };
    iconSvg: (size: number) => string;
    ui?: WorkflowNodeUiConfig;
    resolveInspectorFields?: WorkflowNodeModule['resolveInspectorFields'];
}

const buildServerOnlyIcon = (size: number, label: string): string => {
    const words = label
        .split(/\s+/)
        .map((word) => word.trim())
        .filter(Boolean);
    const initials = (words[0]?.charAt(0) ?? '') + (words[1]?.charAt(0) ?? words[0]?.charAt(1) ?? '');
    const token = initials.toUpperCase() || 'SN';
    return `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <rect x="6" y="6" width="36" height="36" rx="8" stroke="currentColor" stroke-width="2.6"/>
  <path d="M14 18h20M14 24h20" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>
  <text x="24" y="36" text-anchor="middle" font-size="11" font-weight="700" fill="currentColor">${token}</text>
</svg>`;
};

export const createServerOnlyNodeModule = (args: CreateServerOnlyNodeModuleArgs): WorkflowNodeModule => {
    // Keep iconSvg in args for backward compatibility with existing node modules.
    void args.iconSvg;
    const schema = parseNodeSchema(args.rawSchema, args.id);

    return {
        id: args.id,
        schema,
        library: {
            ...args.library,
            nodeType: 'workflowStep',
            defaultKind: args.library.defaultKind ?? WorkflowNodeKindEnum.Process
        },
        renderIcon: (size: number) => buildServerOnlyIcon(size, args.library.label),
        buildInitialNode: (context) => buildInitialNodeFromSchema(context),
        ui: {
            localCapable: false,
            serverOnly: true,
            ...(args.ui ?? {})
        },
        resolveInspectorFields: args.resolveInspectorFields,
        execute: createNodeModuleWorkerExecute(args.id)
    };
};
