import type { WorkflowCommandToolSpec, WorkerExecuteResult, WorkerPayload, WorkerScope, WorkerUpdateResult, WorkerValidateResult } from '@workflow/executor';
import { normalizeResult, toErrorResult, toNode, toRecord } from '@workflow/executor';
import { executeBackend } from '@workflow/execute';

const text = (value: unknown): string => String(value || '').trim();

export const createBackendToolWorker = (args: {
    functionName: string;
    description: string;
    required?: string[];
    toolName?: string;
}): {
    validate: (payload: WorkerPayload) => Promise<WorkerValidateResult>;
    init: (payload: WorkerPayload) => Promise<boolean>;
    onUpdate: (payload: WorkerPayload) => Promise<WorkerUpdateResult>;
    commandToolSpec: (payload: WorkerPayload) => Promise<WorkflowCommandToolSpec>;
    execute: (payload: WorkerPayload) => Promise<WorkerExecuteResult>;
} => {
    const scope: WorkerScope = {};
    return {
        validate: async (payload) => {
            const runtime = toRecord(toNode(payload).runtime);
            const errors = [];
            for (const key of args.required || []) if (!text(runtime[key])) errors.push(`${key} is required.`);
            return { ok: errors.length === 0, errors, warnings: [], normalizedRuntime: runtime };
        },
        init: async (payload) => {
            scope.workflowId = text(toRecord(payload.workflow?.metadata).id);
            scope.initialized = true;
            return true;
        },
        onUpdate: async (payload) => {
            scope.lastStatus = payload.self?.status ?? scope.lastStatus;
            scope.lastOutput = payload.self?.OUTPUT ?? scope.lastOutput;
            return { ok: true, error: null };
        },
        commandToolSpec: async (payload) => ({
            toolName: args.toolName || text(toNode(payload).name) || args.functionName,
            toolDescription: args.description,
            inputContract: { required: [], optional: [] },
            outputContract: [{ key: 'output', label: 'Output', description: 'Bounded JSON result.' }],
            metadata: { modelId: toNode(payload).modelId },
            executionKind: 'tool'
        }),
        execute: async (payload) => {
            try {
                const result = await executeBackend(
                    { key: args.functionName, description: args.description },
                    { NODE: toNode(payload), payload, NODE_SCOPE: scope }
                );
                return normalizeResult(result);
            } catch (error) {
                return toErrorResult(error instanceof Error ? error.message : `${args.toolName || args.functionName} failed.`);
            }
        }
    };
};
