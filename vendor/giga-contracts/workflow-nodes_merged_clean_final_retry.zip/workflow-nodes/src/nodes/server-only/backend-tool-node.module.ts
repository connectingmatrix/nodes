import { createServerOnlyNodeModule } from '@workflow/nodes/nodes/server-only/server-node.module.factory';
import type { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';

type Field = Record<string, unknown>;

const schema = (args: { id: string; label: string; description: string; fields: Record<string, Field> }) => ({
    id: args.id,
    group: 'Workflow Backend',
    iconClass: 'pi pi-server',
    executorKey: args.id,
    render: { iconKey: args.id, iconClass: 'pi pi-server', iconSize: 64, nodeSize: 180, iconColor: '#0f766e', iconBackground: '#ecfeff' },
    outputViewers: [{ id: 'json', label: 'JSON', type: 'json' }],
    name: { type: 'string', editable: true, autoGenerate: true },
    instruction: { code: false, markdown: false },
    fields: {
        description: { type: 'textarea', editable: true, defaultValue: args.description, label: 'Description', styles: { layoutPreset: 'full' }, allowVariables: true },
        ...args.fields,
        status: { type: 'string', hidden: true, auto: true, defaultValue: 'stopped', allowVariables: false }
    },
    inputs: { input: { allowMultipleArrows: true }, command: { label: 'Command', portType: 'bi-directional', side: 'top', order: 0, allowMultipleArrows: true } },
    outputs: { output: { allowMultipleArrows: true }, command: { label: 'Command', portType: 'bi-directional', side: 'top', order: 0, allowMultipleArrows: true } },
    documentation: { nodeTypeLabel: args.label, summary: args.description, usage: args.description }
});

export const createBackendToolNodeModule = (args: {
    id: string;
    label: string;
    description: string;
    group: string;
    order: number;
    fields?: Record<string, Field>;
}): WorkflowNodeModule =>
    createServerOnlyNodeModule({
        id: args.id,
        rawSchema: schema({ ...args, fields: args.fields || {} }),
        library: {
            id: `${args.id}-node`,
            label: args.label,
            description: args.description,
            gigaId: `${args.id}-node`,
            modelId: args.id,
            group: args.group,
            order: args.order,
            iconColor: '#0f766e',
            iconBackground: '#ecfeff'
        },
        iconSvg: () => ''
    });
