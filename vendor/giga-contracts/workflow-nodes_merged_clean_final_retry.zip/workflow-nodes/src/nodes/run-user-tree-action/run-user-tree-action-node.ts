import rawSchema from '@workflow/nodes/nodes/run-user-tree-action/run-user-tree-action-schema.json';
import { resolveGroupedActionInspectorFields, withGroupedActionSchemaOptions } from '@workflow/nodes/nodes/giga-ai/grouped-action-schema';
import { createServerOnlyNodeModule } from '@workflow/nodes/nodes/server-only/server-node.module.factory';

const renderIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <rect x="8" y="9" width="32" height="30" rx="6" stroke="currentColor" stroke-width="2.4"/>
  <path d="M15 18h18M15 25h12M15 32h15" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>
</svg>`;

const nodeModule = createServerOnlyNodeModule({
    id: 'run-user-tree-action',
    rawSchema: withGroupedActionSchemaOptions(rawSchema, 'run-user-tree-action'),
    library: {
        id: 'giga-action-user-tree',
        label: 'User Tree',
        description: 'Run a user tree backend action.',
        gigaId: 'GigaActionUserTreeNode',
        modelId: 'run-user-tree-action',
        group: 'Giga Action Nodes',
        order: 224,
        iconColor: '#155e75',
        iconBackground: '#ecfeff'
    },
    iconSvg: renderIcon,
    resolveInspectorFields: ({ fields, node }) => resolveGroupedActionInspectorFields('run-user-tree-action', fields, node)
});

export default nodeModule;
