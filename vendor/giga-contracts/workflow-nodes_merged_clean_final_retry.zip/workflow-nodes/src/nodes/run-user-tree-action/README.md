# User Tree

## Runtime Ownership
Server-only workflow node.

## Usage
Fetch the current user tree through the backend action system.

## Inputs
- `action`: `fetch_user_tree`.
- `chatId`: Runtime chat scope, with workflow metadata fallback.
- `parameters`: Optional key/value rows for the selected backend action.

## Outputs
- `action`: Backend `AgentActionResult` wrapper.

## Backend Mapping
- `[backend handler key]`
- `executeGroupedActionNode`
