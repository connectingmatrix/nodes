export const MCP_LEGACY_FIELD_KEYS = [
    'serverKey',
    'serverUrl',
    'bearerTokenEnvVar',
    'transport',
    'httpEndpointPath',
    'headers',
    'headersFromEnv',
    'capabilities',
    'stdioCommand',
    'stdioArgs',
    'stdioWorkingDirectory',
    'stdioEnv',
    'envPassthrough',
    'includeServerMetadata',
    'inputContract',
    'task'
];
