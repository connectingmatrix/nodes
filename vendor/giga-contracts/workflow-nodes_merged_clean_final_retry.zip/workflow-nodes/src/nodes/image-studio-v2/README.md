# Image Studio V2

Routes to `image.operation.v2` through `executeBackend`. The node never opens Supabase, Neo4j, local files, or network resources directly.
