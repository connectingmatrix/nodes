import { executeBackend } from '@workflow/nodes/workflow-execute';

const record = (value: unknown): Record<string, unknown> => value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {};

export async function worker(payload: unknown) {
  const input = record(payload);
  return executeBackend({
    tool: 'image.operation.v2',
    input: { ...record(input.input), message: input.message, confirmed: input.confirmed === true, context: record(input.context) },
    context: record(input.context),
  });
}

export default worker;
