export const image_studio_V2Node = {
  id: 'image-studio-v2',
  type: 'image-studio-v2',
  name: 'Image Studio V2',
  version: '20.0.0',
  tool: 'image.operation.v2',
};
export default image_studio_V2Node;
