# Artifact Publish

Publish files, workflows, charts, and nodes to user/org artifact channels.

This node is command-capable and routes backend operations through `executeBackend`. It does not access Supabase or Neo4j directly.
