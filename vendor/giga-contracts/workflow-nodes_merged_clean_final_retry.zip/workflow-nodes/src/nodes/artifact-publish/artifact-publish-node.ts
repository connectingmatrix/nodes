import rawSchema from './artifact-publish-schema.json';
import { createAgentBackendNodeModule } from '@workflow/nodes/nodes/_agent-backend-node-module';

export default createAgentBackendNodeModule({ id: 'artifact-publish', rawSchema, label: 'Artifact Publish', description: 'Publish files, workflows, charts, and nodes to user/org artifact channels.', kind: 'file', order: 517 });
