import rawSchema from './database-driver-schema.json';
import { createAgentBackendNodeModule } from '@workflow/nodes/nodes/_agent-backend-node-module';

export default createAgentBackendNodeModule({ id: 'database-driver', rawSchema, label: 'Database Driver', description: 'Create/query sandboxed database driver nodes with allowlisted packages.', kind: 'database', order: 500 });
