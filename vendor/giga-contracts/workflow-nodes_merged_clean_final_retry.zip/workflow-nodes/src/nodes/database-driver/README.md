# Database Driver

Create/query sandboxed database driver nodes with allowlisted packages.

This node is command-capable and routes backend operations through `executeBackend`. It does not access Supabase or Neo4j directly.
