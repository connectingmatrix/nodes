import rawSchema from './evaluator-schema.json';
import { createAgentBackendNodeModule } from '@workflow/nodes/nodes/_agent-backend-node-module';

export default createAgentBackendNodeModule({ id: 'evaluator', rawSchema, label: 'Evaluator', description: 'Evaluate model, workflow, dataset, and node outputs.', kind: 'database', order: 522 });
