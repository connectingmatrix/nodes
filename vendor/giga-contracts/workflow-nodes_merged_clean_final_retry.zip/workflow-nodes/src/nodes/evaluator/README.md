# Evaluator

Evaluate model, workflow, dataset, and node outputs.

This node is command-capable and routes backend operations through `executeBackend`. It does not access Supabase or Neo4j directly.
