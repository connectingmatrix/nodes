import rawSchema from '@workflow/nodes/nodes/merge/merge-schema.json';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { WorkflowNodeKindEnum } from '@workflow/nodes/types';

const schema = parseNodeSchema(rawSchema, 'merge');

const renderMergeIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <circle cx="14" cy="14" r="6" stroke="currentColor" stroke-width="2.2"/>
  <circle cx="34" cy="14" r="6" stroke="currentColor" stroke-width="2.2"/>
  <circle cx="24" cy="34" r="7" stroke="currentColor" stroke-width="2.2"/>
  <path d="M18 18l4 8M30 18l-4 8" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>
</svg>`;

const mergeNodeModule: WorkflowNodeModule = {
    id: 'merge',
    schema,
    library: {
        id: 'merge-node',
        label: 'Merge',
        description: 'Combine outputs from multiple nodes.',
        gigaId: 'MergeNode',
        modelId: 'merge',
        group: 'Flow Nodes',
        nodeType: 'workflowStep',
        defaultKind: WorkflowNodeKindEnum.Process,
        iconColor: '#1d4ed8',
        iconBackground: '#dbeafe',
        order: 33
    },
    renderIcon: renderMergeIcon,
    buildInitialNode: (context) => buildInitialNodeFromSchema(context),
    ui: {
        localCapable: true,
        serverOnly: false
    },
    execute: createNodeModuleWorkerExecute('merge')
};

export default mergeNodeModule;
