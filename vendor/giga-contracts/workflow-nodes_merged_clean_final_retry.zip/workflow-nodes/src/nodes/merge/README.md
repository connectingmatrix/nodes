# Merge Node

## Runtime Ownership
Worker-first local node. No backend service is used.

## Usage
Connect up to five inputs. Plain-object inputs are shallow-merged in `input1` through `input5` order, and non-object values are preserved under their originating port key.

## Inputs
- `input1` ... `input5`: Optional inbound ports that feed the combined output.

## Outputs
- `output`: A single merged payload.

## Backend Mapping
- No backend service is used.

## Failure Cases
- Runtime failures are surfaced as node errors, though normal merge execution is deterministic.
