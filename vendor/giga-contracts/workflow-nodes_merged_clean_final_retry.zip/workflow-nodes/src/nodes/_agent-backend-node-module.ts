import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';
import type { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { WorkflowNodeKindEnum } from '@workflow/nodes/types';

export type AgentBackendNodeModuleInput = {
  id: string;
  rawSchema: unknown;
  label: string;
  description: string;
  kind?: 'agent' | 'chart' | 'chat' | 'code' | 'control' | 'database' | 'entity' | 'excel' | 'file' | 'knowledge' | 'llm' | 'node' | 'tree' | 'workflow';
  order?: number;
  iconColor?: string;
  iconBackground?: string;
};

const renderIcon = (label: string, color = 'currentColor') => (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <rect x="7" y="7" width="34" height="34" rx="8" stroke="${color}" stroke-width="2.4"/>
  <path d="M15 25h18M15 18h18M15 32h12" stroke="${color}" stroke-width="2.4" stroke-linecap="round"/>
  <title>${label}</title>
</svg>`;

export const createAgentBackendNodeModule = (input: AgentBackendNodeModuleInput): WorkflowNodeModule => {
  const schema = parseNodeSchema(input.rawSchema, input.id);
  return {
    id: input.id,
    schema,
    library: {
      id: `${input.id}-node`,
      label: input.label,
      description: input.description,
      gigaId: `${input.id.replace(/(^|-)([a-z])/g, (_all, _dash, letter) => letter.toUpperCase())}Node`,
      modelId: input.id,
      group: input.kind === 'database' ? 'Data and Integrations' : input.kind === 'file' ? 'Files and Artifacts' : 'Giga AI Nodes',
      nodeType: 'workflowStep',
      defaultKind: WorkflowNodeKindEnum.Process,
      iconColor: input.iconColor || '#2563eb',
      iconBackground: input.iconBackground || '#dbeafe',
      order: input.order ?? 500,
    },
    renderIcon: renderIcon(input.label),
    buildInitialNode: (context) => buildInitialNodeFromSchema(context),
    ui: { localCapable: false, serverOnly: true },
    execute: createNodeModuleWorkerExecute(input.id),
  };
};
