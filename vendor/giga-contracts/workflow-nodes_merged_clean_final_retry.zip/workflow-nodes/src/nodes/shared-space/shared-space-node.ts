import { createBackendToolNodeModule } from '@workflow/nodes/nodes/server-only/backend-tool-node.module';

export default createBackendToolNodeModule({
    id: 'shared-space',
    label: 'Shared Space',
    description: 'Use the organization /drive space for persistent workflow artifacts.',
    group: 'Workflow Files',
    order: 116,
    fields: {
        organizationId: { type: 'string', editable: true, label: 'Organization ID', allowVariables: true },
        operation: { type: 'select', editable: true, defaultValue: 'list', label: 'Operation', options: ['summary', 'list', 'stat', 'mkdir', 'download_url', 'ensure_cached', 'write_json', 'copy', 'move', 'checksum', 'delete'] },
        path: { type: 'string', editable: true, defaultValue: '/drive', label: 'Path', allowVariables: true },
        url: { type: 'string', editable: true, label: 'URL', allowVariables: true },
        checksum: { type: 'string', editable: true, label: 'Checksum', allowVariables: true },
        fromPath: { type: 'string', editable: true, label: 'From Path', allowVariables: true },
        toPath: { type: 'string', editable: true, label: 'To Path', allowVariables: true },
        json: { type: 'json', editable: true, label: 'JSON' }
    }
});
