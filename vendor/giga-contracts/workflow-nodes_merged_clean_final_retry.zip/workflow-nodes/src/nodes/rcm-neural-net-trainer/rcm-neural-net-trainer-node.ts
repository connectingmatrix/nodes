import { createBackendToolNodeModule } from '@workflow/nodes/nodes/server-only/backend-tool-node.module';

export default createBackendToolNodeModule({
    id: 'rcm-neural-net-trainer',
    label: 'RCM Neural Net Trainer',
    description: 'Trains a lightweight online hashed model with bounded weights.',
    group: 'RCM Pipeline',
    order: 213,
    fields: {
        sourceFile: { type: 'string', editable: true, label: 'Source File', allowVariables: true },
        target: { type: 'string', editable: true, defaultValue: 'z_zero_pay', label: 'Target', allowVariables: true },
        hashSize: { type: 'number', editable: true, defaultValue: 2048, label: 'Hash Size' },
        learningRate: { type: 'number', editable: true, defaultValue: 0.08, label: 'Learning Rate' }
    }
});
