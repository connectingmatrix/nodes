# RCM Neural Net Trainer

Worker-owned backend tool node that trains a compact online neural scoring model.

- Uses `executeBackend` function `executeRcmNeuralNetTrainerNode`.
- Configure `sourceFile`, `target`, `hashSize`, and `learningRate` through inspector fields.
- Prefer workflow variables for file references from upstream artifact nodes.
- Emits JSON model artifact metadata for scoring and publishing.

