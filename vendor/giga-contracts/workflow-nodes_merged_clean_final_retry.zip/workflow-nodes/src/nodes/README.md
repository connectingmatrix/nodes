# Workflow Nodes README

This folder contains concrete workflow node modules. AI Agent nodes are agent runtime invocations inside the workflow graph.

## AI Agent node observable chain

```mermaid
graph TD
  A[Workflow node input] --> B[Resolve agent ID]
  B --> C[Validate workflow/user/org scope]
  C --> D[Run AI Agent]
  D --> E[Preserve chart/excel/file/mermaid markers]
  E --> F[Return node output]
  D --> G[Emit agent logs with workflow parent]
```

## Rules

- Nodes must not drop runtime scope.
- Nodes should expose validation/build/run APIs through GraphQL.
- AI Agent nodes use the same agent policy and output contract as Chat Agent mode.
