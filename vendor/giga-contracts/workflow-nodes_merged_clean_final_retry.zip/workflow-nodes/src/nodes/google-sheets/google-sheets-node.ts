import rawSchema from './google-sheets-schema.json';
import { createAgentBackendNodeModule } from '@workflow/nodes/nodes/_agent-backend-node-module';

export default createAgentBackendNodeModule({ id: 'google-sheets', rawSchema, label: 'Google Sheets', description: 'Read/write Google Sheets through centralized backend capabilities.', kind: 'excel', order: 513 });
