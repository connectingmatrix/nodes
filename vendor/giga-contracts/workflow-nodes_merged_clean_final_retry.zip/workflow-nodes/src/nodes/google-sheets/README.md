# Google Sheets

Read/write Google Sheets through centralized backend capabilities.

This node is command-capable and routes backend operations through `executeBackend`. It does not access Supabase or Neo4j directly.
