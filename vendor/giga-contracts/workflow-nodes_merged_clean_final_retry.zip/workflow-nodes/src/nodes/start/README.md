# Start Node

## Runtime Ownership
Worker-first local node. No backend service is used.

## Usage
Use `Start` once at the beginning of a workflow to seed bootstrap context for downstream nodes.

## Inputs
- `variables`: JSON editor for workflow bootstrap variables.
- `prompt`: Markdown editor for workflow guidance or operator notes.
- `forwardSessionLogs`: Optional boolean that includes workflow logs in the final summary output.

## Outputs
- `output`: Emits `{ started, startedAt, workflowId, metadata, input, variables, prompt, forwardSessionLogs }`.

## Backend Mapping
- No backend service is used.

## Failure Cases
- Validation fails when retry configuration is outside the supported range.
