import rawSchema from '@workflow/nodes/nodes/start/start-schema.json';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';
import { WorkflowNodeKindEnum } from '@workflow/nodes/types';

const schema = parseNodeSchema(rawSchema, 'start');

const renderStartIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <circle cx="24" cy="24" r="17" stroke="currentColor" stroke-width="2.4"/>
  <path d="M20 16l12 8l-12 8z" fill="currentColor"/>
</svg>`;

const startNodeModule: WorkflowNodeModule = {
    id: 'start',
    schema,
    library: {
        id: 'start-node',
        label: 'Start',
        description: 'Workflow entry point for Play execution.',
        gigaId: 'StartNode',
        modelId: 'start',
        group: 'Flow Nodes',
        nodeType: 'workflowStep',
        defaultKind: WorkflowNodeKindEnum.Process,
        iconColor: '#0f766e',
        iconBackground: '#ecfdf5',
        order: 1
    },
    renderIcon: renderStartIcon,
    buildInitialNode: (context) => buildInitialNodeFromSchema(context),
    ui: {
        localCapable: true,
        serverOnly: false
    },
    execute: createNodeModuleWorkerExecute('start')
};

export default startNodeModule;
