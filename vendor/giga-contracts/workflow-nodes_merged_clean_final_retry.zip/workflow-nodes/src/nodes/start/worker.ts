import type { WorkflowCommandToolSpec } from '@workflow/executor';
import type { WorkerExecuteResult, WorkerPayload, WorkerScope, WorkerUpdateResult, WorkerValidateResult } from '@workflow/executor';
import { toErrorResult, toNode, toRecord } from '@workflow/executor';

const NODE_SCOPE: WorkerScope = {};

const toRecordValue = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});
const readWorkflowInput = (workflow: unknown): Record<string, unknown> => toRecordValue(toRecordValue(workflow).input);

const validateFailureMitigation = (runtime: Record<string, unknown>): WorkerValidateResult => {
    const errors: string[] = [];
    const failureMitigation = String(runtime.failureMitigation ?? 'stop-workflow').trim();
    if (failureMitigation !== 'retry-node' && failureMitigation !== 'stop-workflow') {
        errors.push('Failure Mitigation must be either "retry-node" or "stop-workflow".');
    }
    if (failureMitigation === 'retry-node') {
        const retryCount = Number(runtime.retryCount);
        if (!Number.isFinite(retryCount) || retryCount < 1 || retryCount > 6) {
            errors.push('Retry Count must be between 1 and 6 when Failure Mitigation is "retry-node".');
        }
    }
    return {
        ok: errors.length === 0,
        errors,
        warnings: [],
        normalizedRuntime: runtime
    };
};

export const validate = async (payload: WorkerPayload): Promise<WorkerValidateResult> => {
    const node = toNode(payload);
    return validateFailureMitigation(toRecordValue(node.runtime));
};

export const init = async (payload: WorkerPayload): Promise<boolean> => {
    const metadata = toRecord(payload.workflow?.metadata);
    NODE_SCOPE.workflowId = String(metadata.id ?? '');
    NODE_SCOPE.initialized = true;
    return true;
};

export const onUpdate = async (payload: WorkerPayload): Promise<WorkerUpdateResult> => {
    NODE_SCOPE.lastStatus = payload.self?.status ?? NODE_SCOPE.lastStatus;
    NODE_SCOPE.lastOutput = payload.self?.OUTPUT ?? NODE_SCOPE.lastOutput;
    return { ok: true, error: null };
};

export const execute = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => {
    try {
        const node = toNode(payload);
        const runtime = toRecordValue(node.runtime);
        const workflowInput = readWorkflowInput(payload.workflow);
        const webhookRequest = toRecordValue(workflowInput);
        const variables = toRecordValue(runtime.variables);
        const prompt = String(runtime.prompt ?? '');
        const forwardSessionLogs =
            runtime.forwardSessionLogs === true ||
            String(runtime.forwardSessionLogs ?? '')
                .trim()
                .toLowerCase() === 'true';
        const triggerSource = String(runtime.triggerSource ?? 'programmatic')
            .trim()
            .toLowerCase();
        const webhookMethod = String(runtime.webhookMethod ?? 'POST')
            .trim()
            .toUpperCase();
        return {
            output: {
                started: true,
                startedAt: new Date().toISOString(),
                workflowId: payload.workflow?.metadata?.id ?? '',
                metadata: payload.workflow?.metadata ?? {},
                input: workflowInput,
                request: {
                    method: String(webhookRequest.method ?? ''),
                    headers: toRecordValue(webhookRequest.headers),
                    query: toRecordValue(webhookRequest.query),
                    body: webhookRequest.body ?? null,
                    path: String(webhookRequest.path ?? ''),
                    routeType: String(webhookRequest.routeType ?? '')
                },
                triggerSource,
                webhookMethod,
                variables,
                prompt,
                forwardSessionLogs,
                __activeOutputs: ['output']
            },
            status: 'passed',
            logs: []
        };
    } catch (error) {
        return toErrorResult(error instanceof Error ? error.message : 'Start node execution failed.');
    }
};

// AI Agent command contract: keep this node usable as a declared tool without adding proxy wrappers.
type __GigaCommandRecord = Record<string, unknown>;
const __gigaCommandRecord = (value: unknown): __GigaCommandRecord =>
  value && typeof value === 'object' && !Array.isArray(value) ? (value as __GigaCommandRecord) : {};
const __gigaCommandText = (value: unknown): string => String(value ?? '').trim();
const __gigaCommandNode = (payload: WorkerPayload): __GigaCommandRecord =>
  __gigaCommandRecord((payload as { NODE?: unknown }).NODE || (payload as { self?: unknown }).self || payload);
const __gigaCommandRuntime = (payload: WorkerPayload): __GigaCommandRecord => {
  const node = __gigaCommandNode(payload);
  return { ...__gigaCommandRecord(node.runtime), ...__gigaCommandRecord(node.properties) };
};

export const commandToolSpec = async (payload: WorkerPayload): Promise<WorkflowCommandToolSpec> => {
  const node = __gigaCommandNode(payload);
  const runtime = __gigaCommandRuntime(payload);
  const modelId = __gigaCommandText(node.modelId || runtime.modelId || 'start');
  const configuredName = __gigaCommandText(node.name || runtime.name || runtime.title);
  const operation = __gigaCommandText(runtime.operation || runtime.action || runtime.mode || modelId || 'start');
  const haystack = `${configuredName} ${operation} ${modelId}`.toLowerCase();
  const mutating = runtime.mutating === true || /\b(create|update|delete|remove|link|unlink|attach|detach|publish|execute|run|write|save|train|install|ingest|fix|stop|wait)\b/.test(haystack);
  return {
    toolName: configuredName || 'Start',
    toolDescription: __gigaCommandText(runtime.description || runtime.toolDescription) || 'Expose workflow start/input values as a command tool for planning chains.',
    inputContract: {
      required: [],
      optional: [

        { key: 'message', label: 'Message', description: 'Natural-language instruction or task for this node.' },
        { key: 'input', label: 'Input', description: 'Structured JSON input for the node.' },
        { key: 'operation', label: 'Operation', description: 'Operation/action name, when the node supports multiple operations.' },
        { key: 'prompt', label: 'Prompt', description: 'Prompt text for LLM or transformation nodes.' },
        { key: 'data', label: 'Data', description: 'Data payload for processing.' },
      ],
    },
    outputContract: [
      { key: 'output', label: 'Output', description: 'Node output payload.' },
      { key: 'status', label: 'Status', description: 'Execution status.' },
      { key: 'logs', label: 'Logs', description: 'Execution logs, when available.' },
    ],
    metadata: {
      modelId,
      nodeId: __gigaCommandText(node.id || node.nodeId),
      operation,
      toolDomain: 'control',
      mutating,
      reusableByAiAgent: true,
    },
    executionKind: 'tool',
  };
};

