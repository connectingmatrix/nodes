import type { WorkflowCommandToolSpec } from '@workflow/executor';
import type {
  WorkerExecuteResult,
  WorkerPayload,
  WorkerScope,
  WorkerUpdateResult,
  WorkerValidateResult,
} from "@workflow/executor";
import {
  normalizeResult,
  toErrorResult,
  toNode,
  toRecord,
} from "@workflow/executor";
import { executeBackend } from "@workflow/execute";

const NODE_SCOPE: WorkerScope = {};
const MODES = ["input", "history", "context", "pending"];
const ACTIONS = ["none", "store", "clear"];
const OPERATIONS = [
  "bundle",
  "get_or_create_chat",
  "update_chat_metadata",
  "get_chat_context",
  "resolve_subject_filter",
  "save_message",
];

const record = (value: unknown): Record<string, unknown> =>
  value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {};
const list = (value: unknown): string[] =>
  Array.isArray(value)
    ? value.map((entry) => String(entry || "").trim()).filter(Boolean)
    : [];
const text = (value: unknown): string => String(value || "").trim();

export const validate = async (
  payload: WorkerPayload,
): Promise<WorkerValidateResult> => {
  const runtime = record(toNode(payload).runtime);
  const errors = list(runtime.mode).every((entry) => MODES.includes(entry))
    ? []
    : ["Bundles contains an unsupported value."];
  if (!ACTIONS.includes(text(runtime.pendingAction || "none") || "none"))
    errors.push("Pending Action must be none, store, or clear.");
  if (!OPERATIONS.includes(text(runtime.operation || "bundle") || "bundle"))
    errors.push(
      "Operation must be bundle, get_or_create_chat, update_chat_metadata, get_chat_context, resolve_subject_filter, or save_message.",
    );
  return {
    ok: errors.length === 0,
    errors,
    warnings: [],
    normalizedRuntime: runtime,
  };
};

export const init = async (payload: WorkerPayload): Promise<boolean> => {
  NODE_SCOPE.workflowId = text(record(payload.workflow?.metadata).id);
  NODE_SCOPE.initialized = true;
  return true;
};

export const onUpdate = async (
  payload: WorkerPayload,
): Promise<WorkerUpdateResult> => {
  NODE_SCOPE.lastStatus = payload.self?.status ?? NODE_SCOPE.lastStatus;
  NODE_SCOPE.lastOutput = payload.self?.OUTPUT ?? NODE_SCOPE.lastOutput;
  return { ok: true, error: null };
};

export const execute = async (
  payload: WorkerPayload,
): Promise<WorkerExecuteResult> => {
  try {
    const result = await executeBackend(
      {
        key: "executeCurrentChatNode",
        description: "Current chat workflow node.",
      },
      {
        NODE: toNode(payload),
        payload,
        NODE_SCOPE,
      },
    );
    return normalizeResult(result);
  } catch (error) {
    return toErrorResult(
      error instanceof Error
        ? error.message
        : "Current Chat node execution failed.",
    );
  }
};

// AI Agent command contract: keep this node usable as a declared tool without adding proxy wrappers.
type __GigaCommandRecord = Record<string, unknown>;
const __gigaCommandRecord = (value: unknown): __GigaCommandRecord =>
  value && typeof value === 'object' && !Array.isArray(value) ? (value as __GigaCommandRecord) : {};
const __gigaCommandText = (value: unknown): string => String(value ?? '').trim();
const __gigaCommandNode = (payload: WorkerPayload): __GigaCommandRecord =>
  __gigaCommandRecord((payload as { NODE?: unknown }).NODE || (payload as { self?: unknown }).self || payload);
const __gigaCommandRuntime = (payload: WorkerPayload): __GigaCommandRecord => {
  const node = __gigaCommandNode(payload);
  return { ...__gigaCommandRecord(node.runtime), ...__gigaCommandRecord(node.properties) };
};

export const commandToolSpec = async (payload: WorkerPayload): Promise<WorkflowCommandToolSpec> => {
  const node = __gigaCommandNode(payload);
  const runtime = __gigaCommandRuntime(payload);
  const modelId = __gigaCommandText(node.modelId || runtime.modelId || 'current-chat');
  const configuredName = __gigaCommandText(node.name || runtime.name || runtime.title);
  const operation = __gigaCommandText(runtime.operation || runtime.action || runtime.mode || modelId || 'current-chat');
  const haystack = `${configuredName} ${operation} ${modelId}`.toLowerCase();
  const mutating = runtime.mutating === true || /\b(create|update|delete|remove|link|unlink|attach|detach|publish|execute|run|write|save|train|install|ingest|fix|stop|wait)\b/.test(haystack);
  return {
    toolName: configuredName || 'Current Chat',
    toolDescription: __gigaCommandText(runtime.description || runtime.toolDescription) || 'Read or update current chat context through the backend chat/entity bridge.',
    inputContract: {
      required: [],
      optional: [

        { key: 'message', label: 'Message', description: 'Natural-language instruction or task for this node.' },
        { key: 'input', label: 'Input', description: 'Structured JSON input for the node.' },
        { key: 'operation', label: 'Operation', description: 'Operation/action name, when the node supports multiple operations.' },
        { key: 'prompt', label: 'Prompt', description: 'Prompt text for LLM or transformation nodes.' },
        { key: 'data', label: 'Data', description: 'Data payload for processing.' },
      ],
    },
    outputContract: [
      { key: 'output', label: 'Output', description: 'Node output payload.' },
      { key: 'status', label: 'Status', description: 'Execution status.' },
      { key: 'logs', label: 'Logs', description: 'Execution logs, when available.' },
    ],
    metadata: {
      modelId,
      nodeId: __gigaCommandText(node.id || node.nodeId),
      operation,
      toolDomain: 'chat',
      mutating,
      reusableByAiAgent: true,
    },
    executionKind: 'tool',
  };
};

