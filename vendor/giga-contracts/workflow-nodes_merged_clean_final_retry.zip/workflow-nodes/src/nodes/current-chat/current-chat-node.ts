import rawSchema from '@workflow/nodes/nodes/current-chat/current-chat-schema.json';
import { createServerOnlyNodeModule } from '@workflow/nodes/nodes/server-only/server-node.module.factory';

const renderIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <rect x="7" y="8" width="34" height="26" rx="7" stroke="currentColor" stroke-width="2.4"/>
  <path d="M14 16h20M14 22h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
  <path d="M19 34v6l7-6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;

export default createServerOnlyNodeModule({
    id: 'current-chat',
    rawSchema,
    library: {
        id: 'current-chat-node',
        label: 'Current Chat',
        description: 'Load chat bundles and manage pending workflow plans.',
        gigaId: 'CurrentChatNode',
        modelId: 'current-chat',
        group: 'Context',
        order: 50,
        iconColor: '#0f766e',
        iconBackground: '#ecfeff'
    },
    iconSvg: renderIcon
});
