# Current Chat Node

## Runtime Ownership

Worker-owned chat state node with backend execution for chat reads and pending-plan writes.

## Usage

Select one or more chat bundles: `input`, `history`, `context`, or `pending`. Use `Pending Action` only when you want to store or clear a pending plan.

## Inputs

- `mode`: Multi-select chat bundles.
- `pendingAction`: `none`, `store`, or `clear`.
- `chatId`, `message`, `scopeType`, `scopeId`, `subjectIds`, `postIds`, `tagSlugs`, `subjectQuery`: Explicit runtime inputs for chat state and scoped context.
- `plan`: Pending plan payload for `store`.
- `limit` / `offset`: History paging controls.

## Outputs

- `output`: Combined chat bundle payload.

## Failure Cases

- Fails when no explicit or metadata-backed chat id is available.
- Fails when `Pending Action = Store` receives no plan.

## Backend Mapping

- Service: `/Users/abeer/dev/giga/giga-ai-backend/src/[backend handler key]`
- Handler: `executeCurrentChatNode`
