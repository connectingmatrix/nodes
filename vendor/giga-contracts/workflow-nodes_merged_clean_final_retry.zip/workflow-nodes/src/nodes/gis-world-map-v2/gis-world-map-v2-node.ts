export const gis_world_map_V2Node = {
  id: 'gis-world-map-v2',
  type: 'gis-world-map-v2',
  name: 'GIS World Map V2',
  version: '20.0.0',
  tool: 'gis.operation.v2',
};
export default gis_world_map_V2Node;
