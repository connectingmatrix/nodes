export const advanced_swarm_V2Node = {
  id: 'advanced-swarm-v2',
  type: 'advanced-swarm-v2',
  name: 'Advanced Swarm V2',
  version: '20.0.0',
  tool: 'agent.swarm.v2',
};
export default advanced_swarm_V2Node;
