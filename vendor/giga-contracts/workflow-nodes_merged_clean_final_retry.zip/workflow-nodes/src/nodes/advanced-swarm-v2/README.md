# Advanced Swarm V2

Routes to `agent.swarm.v2` through `executeBackend`. The node never opens Supabase, Neo4j, local files, or network resources directly.
