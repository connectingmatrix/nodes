# Current Subjects Node

## Runtime Ownership
Worker-first local node. No backend service is used.

## Usage
Resolve subjects from `workflow.input.subjectIds`, with optional fallback through `workflow.input.postIds`, using the configured GraphQL endpoint directly in the worker.

## Inputs
- `workflow.input.subjectIds`: Subject ids to load.
- `workflow.input.postIds`: Optional fallback post ids used to discover subject ids.

## Outputs
- `output`: Resolved `subjectIds`, `postIds`, subject records, count, and per-subject GraphQL responses.

## Backend Mapping
- No backend service is used.

## Failure Cases
- Fails when both `subjectIds` and `postIds` are missing.
- Fails when any required GraphQL lookup returns an error.
