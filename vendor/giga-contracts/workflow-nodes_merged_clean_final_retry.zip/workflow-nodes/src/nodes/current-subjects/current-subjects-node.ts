import rawSchema from '@workflow/nodes/nodes/current-subjects/current-subjects-schema.json';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';
import { WorkflowNodeKindEnum } from '@workflow/nodes/types';

const schema = parseNodeSchema(rawSchema, 'current-subjects');

const renderCurrentSubjectsIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <path d="M8 12h12l4 4h16v20H8z" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round"/>
  <path d="M14 23h20M14 29h16" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
  <circle cx="16" cy="12" r="2.5" fill="currentColor"/>
</svg>`;

const currentSubjectsNodeModule: WorkflowNodeModule = {
    id: 'current-subjects',
    schema,
    library: {
        id: 'current-subjects-node',
        label: 'Current Subjects',
        description: 'Fetches subjects by workflow input subjectIds.',
        gigaId: 'CurrentSubjectsNode',
        modelId: 'current-subjects',
        group: 'Context',
        nodeType: 'workflowStep',
        defaultKind: WorkflowNodeKindEnum.Process,
        iconColor: '#7c3aed',
        iconBackground: '#f5f3ff',
        order: 60
    },
    renderIcon: renderCurrentSubjectsIcon,
    buildInitialNode: (context) => buildInitialNodeFromSchema(context),
    ui: {
        localCapable: true,
        serverOnly: false
    },
    execute: createNodeModuleWorkerExecute('current-subjects')
};

export default currentSubjectsNodeModule;
