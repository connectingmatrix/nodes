import type { WorkflowCommandToolSpec } from '@workflow/executor';
import type { WorkerExecuteResult, WorkerPayload, WorkerScope, WorkerUpdateResult, WorkerValidateResult } from '@workflow/executor';
import { toErrorResult, toNode, toRecord } from '@workflow/executor';

const NODE_SCOPE: WorkerScope = {};
const POST_BY_ID_QUERY = `query GetPostById($id: UUID!) {
  ai_postsCollection(filter: { id: { eq: $id } }, first: 1) {
    edges {
      node {
        id
        subject_id
        title
        narrative
        metadata
        created_at
        updated_at
        ai_attachmentsCollection(first: 200, orderBy: [{ created_at: AscNullsFirst }]) {
          edges {
            node {
              id
              post_id
              file_name
              mime_type
              storage_path
              content_text
              metadata
              created_at
              updated_at
            }
          }
        }
      }
    }
  }
}`;
const SUBJECT_BY_ID_QUERY = `query GetSubjectById($id: UUID!) {
  ai_subjectsCollection(filter: { id: { eq: $id } }, first: 1) {
    edges {
      node {
        id
        name
        description
        metadata
        slug
        summary
        created_at
        updated_at
        ai_subject_tagsCollection(first: 200, orderBy: [{ created_at: AscNullsFirst }]) {
          edges {
            node {
              ai_tags {
                id
                name
                slug
              }
            }
          }
        }
      }
    }
  }
}`;
const ACCESS_TOKEN_STORAGE_KEY = 'giga_access_token';
const REFRESH_TOKEN_STORAGE_KEY = 'giga_refresh_token';

const toRecordValue = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});
const readWorkflowInput = (workflow: unknown): Record<string, unknown> => toRecordValue(toRecordValue(workflow).input);

const toStringValue = (value: unknown): string => String(value ?? '').trim();

const toStringList = (value: unknown): string[] => {
    if (!Array.isArray(value)) return [];
    return value.map((entry) => toStringValue(entry)).filter((entry) => entry.length > 0);
};

const parseHeaderRecord = (value: unknown): Record<string, string> =>
    Object.entries(toRecordValue(value)).reduce<Record<string, string>>((acc, [key, entry]) => {
        const normalizedKey = key.trim();
        const normalizedValue = toStringValue(entry);
        if (!normalizedKey || !normalizedValue) return acc;
        acc[normalizedKey] = normalizedValue;
        return acc;
    }, {});

const readStoredTokens = (): { accessToken?: string; refreshToken?: string } => {
    const storage = typeof globalThis !== 'undefined' ? (globalThis as { localStorage?: Storage }).localStorage : undefined;
    if (!storage) return {};
    return {
        accessToken: storage.getItem(ACCESS_TOKEN_STORAGE_KEY) ?? undefined,
        refreshToken: storage.getItem(REFRESH_TOKEN_STORAGE_KEY) ?? undefined
    };
};

const resolveAuthHeaders = (settings: Record<string, unknown>): Record<string, string> => {
    const authMode = toStringValue(settings.authMode).toLowerCase();
    if (authMode === 'none') return {};
    if (authMode === 'manual') return parseHeaderRecord(settings.manualHeaders);
    const tokens = readStoredTokens();
    if (!tokens.accessToken) return {};
    return {
        Authorization: `Bearer access_token=${tokens.accessToken};refresh_token=${tokens.refreshToken ?? ''}`
    };
};

const hasGraphqlErrors = (payload: unknown): boolean => {
    const errors = (payload as { errors?: unknown[] } | null)?.errors;
    return Array.isArray(errors) && errors.length > 0;
};

const getSettings = (payload: WorkerPayload): Record<string, unknown> => toRecordValue(toRecordValue(toRecordValue(payload.workflow?.metadata).runtime).settings);

const runGraphqlRequest = async (payload: WorkerPayload, queryText: string, variables: Record<string, unknown>): Promise<{ response: unknown; ok: boolean; status: number }> => {
    const settings = getSettings(payload);
    const graphqlUrl = toStringValue(settings.graphqlUrl);
    if (!graphqlUrl) {
        throw new Error('GraphQL URL is missing in workflow settings.');
    }

    const response = await fetch(graphqlUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            ...resolveAuthHeaders(settings)
        },
        body: JSON.stringify({ query: queryText, variables })
    });

    const body = await response.json().catch(() => ({}));
    return {
        response: body,
        status: response.status,
        ok: response.ok && !hasGraphqlErrors(body)
    };
};

const validateFailureMitigation = (runtime: Record<string, unknown>): WorkerValidateResult => {
    const errors: string[] = [];
    const warnings: string[] = [];
    const failureMitigation = toStringValue(runtime.failureMitigation || 'stop-workflow');
    if (failureMitigation !== 'retry-node' && failureMitigation !== 'stop-workflow') {
        errors.push('Failure Mitigation must be either "retry-node" or "stop-workflow".');
    }
    if (failureMitigation === 'retry-node') {
        const retryCount = Number(runtime.retryCount);
        if (!Number.isFinite(retryCount) || retryCount < 1 || retryCount > 6) {
            errors.push('Retry Count must be between 1 and 6 when Failure Mitigation is "retry-node".');
        }
    }
    return { ok: errors.length === 0, errors, warnings, normalizedRuntime: runtime };
};

export const validate = async (payload: WorkerPayload): Promise<WorkerValidateResult> => {
    const runtime = toRecordValue(toNode(payload).runtime);
    const result = validateFailureMitigation(runtime);
    const workflowInput = readWorkflowInput(payload.workflow);
    const subjectIds = toStringList(workflowInput.subjectIds);
    const postIds = toStringList(workflowInput.postIds);
    if (subjectIds.length === 0 && postIds.length === 0) {
        result.ok = false;
        result.errors.push('workflow.input.subjectIds or workflow.input.postIds is required.');
    }
    if (subjectIds.length > 0 && postIds.length === 0) {
        result.warnings = [...(result.warnings ?? []), 'Only subjectIds is present; post-based enrichment lookup will be skipped.'];
    }
    return result;
};

export const init = async (payload: WorkerPayload): Promise<boolean> => {
    NODE_SCOPE.workflowId = String(payload.workflow?.metadata?.id ?? '');
    NODE_SCOPE.initialized = true;
    return true;
};

export const onUpdate = async (payload: WorkerPayload): Promise<WorkerUpdateResult> => {
    NODE_SCOPE.lastStatus = payload.self?.status ?? NODE_SCOPE.lastStatus;
    NODE_SCOPE.lastOutput = payload.self?.OUTPUT ?? NODE_SCOPE.lastOutput;
    return { ok: true, error: null };
};

export const executeLocal = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => {
    try {
        const workflowInput = readWorkflowInput(payload.workflow);
        const subjectIds = new Set<string>(toStringList(workflowInput.subjectIds));
        const postIds = toStringList(workflowInput.postIds);

        if (subjectIds.size === 0 && postIds.length > 0) {
            for (const postId of postIds) {
                const postRequest = await runGraphqlRequest(payload, POST_BY_ID_QUERY, { id: postId });
                const subjectId = toStringValue((postRequest.response as { data?: { ai_postsCollection?: { edges?: Array<{ node?: { subject_id?: unknown } }> } } })?.data?.ai_postsCollection?.edges?.[0]?.node?.subject_id);
                if (subjectId) {
                    subjectIds.add(subjectId);
                }
            }
        }

        if (subjectIds.size === 0) {
            return toErrorResult('workflow.input.subjectIds or workflow.input.postIds is required for Current Subjects node.');
        }

        const responses: Record<string, unknown> = {};
        const subjects: unknown[] = [];
        let failed = false;

        for (const subjectId of Array.from(subjectIds)) {
            const request = await runGraphqlRequest(payload, SUBJECT_BY_ID_QUERY, { id: subjectId });
            responses[subjectId] = request.response;
            const subjectNode = (request.response as { data?: { ai_subjectsCollection?: { edges?: Array<{ node?: unknown }> } } })?.data?.ai_subjectsCollection?.edges?.[0]?.node;
            if (typeof subjectNode !== 'undefined') {
                subjects.push(subjectNode);
            }
            if (!request.ok) {
                failed = true;
            }
        }

        return {
            output: {
                subjectIds: Array.from(subjectIds),
                postIds,
                subjects,
                count: subjects.length,
                queryText: SUBJECT_BY_ID_QUERY,
                responses
            },
            status: failed ? 'failed' : 'passed'
        };
    } catch (error) {
        return toErrorResult(error instanceof Error ? error.message : 'Current Subjects node execution failed.');
    }
};

export const execute = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => executeLocal(payload);

// AI Agent command contract: keep this node usable as a declared tool without adding proxy wrappers.
type __GigaCommandRecord = Record<string, unknown>;
const __gigaCommandRecord = (value: unknown): __GigaCommandRecord =>
  value && typeof value === 'object' && !Array.isArray(value) ? (value as __GigaCommandRecord) : {};
const __gigaCommandText = (value: unknown): string => String(value ?? '').trim();
const __gigaCommandNode = (payload: WorkerPayload): __GigaCommandRecord =>
  __gigaCommandRecord((payload as { NODE?: unknown }).NODE || (payload as { self?: unknown }).self || payload);
const __gigaCommandRuntime = (payload: WorkerPayload): __GigaCommandRecord => {
  const node = __gigaCommandNode(payload);
  return { ...__gigaCommandRecord(node.runtime), ...__gigaCommandRecord(node.properties) };
};

export const commandToolSpec = async (payload: WorkerPayload): Promise<WorkflowCommandToolSpec> => {
  const node = __gigaCommandNode(payload);
  const runtime = __gigaCommandRuntime(payload);
  const modelId = __gigaCommandText(node.modelId || runtime.modelId || 'current-subjects');
  const configuredName = __gigaCommandText(node.name || runtime.name || runtime.title);
  const operation = __gigaCommandText(runtime.operation || runtime.action || runtime.mode || modelId || 'current-subjects');
  const haystack = `${configuredName} ${operation} ${modelId}`.toLowerCase();
  const mutating = runtime.mutating === true || /\b(create|update|delete|remove|link|unlink|attach|detach|publish|execute|run|write|save|train|install|ingest|fix|stop|wait)\b/.test(haystack);
  return {
    toolName: configuredName || 'Current Subjects',
    toolDescription: __gigaCommandText(runtime.description || runtime.toolDescription) || 'Read current subject context for tree/chat grounded workflows.',
    inputContract: {
      required: [],
      optional: [

        { key: 'message', label: 'Message', description: 'Natural-language instruction or task for this node.' },
        { key: 'input', label: 'Input', description: 'Structured JSON input for the node.' },
        { key: 'operation', label: 'Operation', description: 'Operation/action name, when the node supports multiple operations.' },
        { key: 'prompt', label: 'Prompt', description: 'Prompt text for LLM or transformation nodes.' },
        { key: 'data', label: 'Data', description: 'Data payload for processing.' },
      ],
    },
    outputContract: [
      { key: 'output', label: 'Output', description: 'Node output payload.' },
      { key: 'status', label: 'Status', description: 'Execution status.' },
      { key: 'logs', label: 'Logs', description: 'Execution logs, when available.' },
    ],
    metadata: {
      modelId,
      nodeId: __gigaCommandText(node.id || node.nodeId),
      operation,
      toolDomain: 'tree',
      mutating,
      reusableByAiAgent: true,
    },
    executionKind: 'tool',
  };
};

