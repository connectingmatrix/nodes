import rawSchema from './churn-analysis-schema.json';
import { createAgentBackendNodeModule } from '@workflow/nodes/nodes/_agent-backend-node-module';

export default createAgentBackendNodeModule({ id: 'churn-analysis', rawSchema, label: 'Churn Analysis', description: 'Analyze churn indicators from tabular/customer data.', kind: 'database', order: 524 });
