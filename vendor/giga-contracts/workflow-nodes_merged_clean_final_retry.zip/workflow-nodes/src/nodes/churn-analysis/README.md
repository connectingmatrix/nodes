# Churn Analysis

Analyze churn indicators from tabular/customer data.

This node is command-capable and routes backend operations through `executeBackend`. It does not access Supabase or Neo4j directly.
