# Channel

## Runtime Ownership
Server-only workflow node.

## Usage
Select one channel action and provide backend arguments in `parameters` rows.

## Inputs
- `action`: `read_channel`, `create_channel`, `update_channel`, `delete_channel`, or `link_channel`.
- `chatId`: Runtime chat scope, with workflow metadata fallback.
- `parameters`: Add key/value rows for the selected backend action.

## Outputs
- `action`: Backend `AgentActionResult` wrapper.

## Backend Mapping
- `[backend handler key]`
- `executeGroupedActionNode`
