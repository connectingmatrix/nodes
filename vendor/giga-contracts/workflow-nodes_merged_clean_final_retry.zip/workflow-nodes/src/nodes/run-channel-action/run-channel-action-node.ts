import rawSchema from '@workflow/nodes/nodes/run-channel-action/run-channel-action-schema.json';
import { resolveGroupedActionInspectorFields, withGroupedActionSchemaOptions } from '@workflow/nodes/nodes/giga-ai/grouped-action-schema';
import { createServerOnlyNodeModule } from '@workflow/nodes/nodes/server-only/server-node.module.factory';

const renderIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <rect x="8" y="9" width="32" height="30" rx="6" stroke="currentColor" stroke-width="2.4"/>
  <path d="M15 18h18M15 25h12M15 32h15" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>
</svg>`;

const nodeModule = createServerOnlyNodeModule({
    id: 'run-channel-action',
    rawSchema: withGroupedActionSchemaOptions(rawSchema, 'run-channel-action'),
    library: {
        id: 'giga-action-channel',
        label: 'Channel',
        description: 'Run a channel backend action.',
        gigaId: 'GigaActionChannelNode',
        modelId: 'run-channel-action',
        group: 'Giga Action Nodes',
        order: 220,
        iconColor: '#155e75',
        iconBackground: '#ecfeff'
    },
    iconSvg: renderIcon,
    resolveInspectorFields: ({ fields, node }) => resolveGroupedActionInspectorFields('run-channel-action', fields, node)
});

export default nodeModule;
