# Subject

## Runtime Ownership
Server-only workflow node.

## Usage
Select one subject action and provide backend arguments in `parameters` rows. For visible subject-reference sync, use `serp-search` before `update_subject`.

## Inputs
- `action`: Read, mutate, link, sync, or refresh a subject.
- `chatId`: Runtime chat scope, with workflow metadata fallback.
- `parameters`: Add key/value rows for the selected backend action.

## Outputs
- `action`: Backend `AgentActionResult` wrapper.

## Backend Mapping
- `[backend handler key]`
- `executeGroupedActionNode`
