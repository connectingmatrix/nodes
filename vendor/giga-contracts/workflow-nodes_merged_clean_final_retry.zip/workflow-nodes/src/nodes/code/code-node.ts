import rawSchema from '@workflow/nodes/nodes/code/code-schema.json';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';
import { WorkflowNodeKindEnum } from '@workflow/nodes/types';

const schema = parseNodeSchema(rawSchema, 'code');

const renderCodeIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <path d="M18 14l-8 10l8 10M30 14l8 10l-8 10M22 36l4-24" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;

const codeNodeModule: WorkflowNodeModule = {
    id: 'code',
    schema,
    library: {
        id: 'code-node',
        label: 'Code Node',
        description: 'JavaScript execution node.',
        gigaId: 'CodeNode',
        modelId: 'code',
        group: 'Data',
        nodeType: 'workflowStep',
        defaultKind: WorkflowNodeKindEnum.Process,
        iconColor: '#1d4ed8',
        iconBackground: '#eff6ff',
        order: 10
    },
    renderIcon: renderCodeIcon,
    buildInitialNode: (context) => buildInitialNodeFromSchema(context, { code: 'return input;' }),
    ui: {
        localCapable: true,
        serverOnly: false,
        inspector: {
            hiddenFieldKeys: ['payload'],
            codeAllowVariables: false
        }
    },
    execute: createNodeModuleWorkerExecute('code')
};

export default codeNodeModule;
