import type { WorkflowCommandToolSpec, WorkerExecuteResult, WorkerPayload, WorkerScope, WorkerUpdateResult, WorkerValidateResult } from '@workflow/executor';
import { toErrorResult, toNode, toRecord } from '@workflow/executor';

const NODE_SCOPE: WorkerScope = {};
const AsyncFunction = Object.getPrototypeOf(async function () {}).constructor as new (...args: string[]) => (...runtimeArgs: unknown[]) => Promise<unknown>;

const toRecordValue = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});
const normalizePublicOutput = (value: unknown): Record<string, unknown> => (!value || typeof value !== 'object' || Array.isArray(value) ? { output: value } : (value as Record<string, unknown>));
const readWorkflowInput = (workflow: unknown): Record<string, unknown> => toRecordValue(toRecordValue(workflow).input);
const buildNodeInput = (runtime: Record<string, unknown>): Record<string, unknown> => {
    const payload = runtime.payload;
    if (payload && typeof payload === 'object' && !Array.isArray(payload)) return payload as Record<string, unknown>;
    if (typeof payload !== 'undefined') return { value: payload };
    return {};
};
const buildPublicWorkflowContext = (workflow: Record<string, unknown>): Record<string, unknown> => ({
    metadata: toRecordValue(workflow.metadata),
    runtime: toRecordValue(toRecordValue(toRecordValue(workflow.metadata).runtime).settings),
    input: readWorkflowInput(workflow),
    nodes: (Array.isArray(workflow.nodes) ? workflow.nodes : []).map((entry) => {
        const node = toRecordValue(entry);
        return {
            id: String(node.id || ''),
            name: String(node.name || ''),
            modelId: String(node.modelId || ''),
            runtime: toRecordValue(node.runtime),
            properties: toRecordValue(node.properties)
        };
    }),
    connections: (Array.isArray(workflow.connections) ? workflow.connections : []).map((entry) => {
        const connection = toRecordValue(entry);
        return {
            id: String(connection.id || ''),
            name: String(connection.name || ''),
            from: String(connection.from || ''),
            to: String(connection.to || ''),
            sourceHandle: String(connection.sourceHandle || ''),
            targetHandle: String(connection.targetHandle || '')
        };
    })
});

const toLogLine = (value: unknown): string => {
    if (typeof value === 'string') return value;
    if (typeof value === 'number' || typeof value === 'boolean' || value === null || typeof value === 'undefined') {
        return String(value);
    }
    try {
        return JSON.stringify(value);
    } catch {
        return String(value);
    }
};

const createConsoleCapture = (logs: string[]) => {
    const push = (...values: unknown[]): void => {
        logs.push(values.map((value) => toLogLine(value)).join(' '));
    };

    return {
        log: (...values: unknown[]) => push(...values),
        info: (...values: unknown[]) => push(...values),
        warn: (...values: unknown[]) => push(...values),
        error: (...values: unknown[]) => push(...values),
        debug: (...values: unknown[]) => push(...values),
        table: (...values: unknown[]) => push(...values)
    };
};

const validateFailureMitigation = (runtime: Record<string, unknown>): WorkerValidateResult => {
    const errors: string[] = [];
    const failureMitigation = String(runtime.failureMitigation ?? 'stop-workflow').trim();
    if (failureMitigation !== 'retry-node' && failureMitigation !== 'stop-workflow') {
        errors.push('Failure Mitigation must be either "retry-node" or "stop-workflow".');
    }
    if (failureMitigation === 'retry-node') {
        const retryCount = Number(runtime.retryCount);
        if (!Number.isFinite(retryCount) || retryCount < 1 || retryCount > 6) {
            errors.push('Retry Count must be between 1 and 6 when Failure Mitigation is "retry-node".');
        }
    }
    return { ok: errors.length === 0, errors, warnings: [], normalizedRuntime: runtime };
};

const executeCode = async (code: string, context: Record<string, unknown>, logs: string[]): Promise<unknown> => {
    const capturedConsole = createConsoleCapture(logs);
    const runner = new AsyncFunction('input', 'properties', 'workflow', 'node', 'console', code);
    return runner(context.input, context.properties, context.workflow, context.node, capturedConsole);
};

export const validate = async (payload: WorkerPayload): Promise<WorkerValidateResult> => {
    const runtime = toRecordValue(toNode(payload).runtime);
    const result = validateFailureMitigation(runtime);
    if (!String(runtime.code ?? '').trim()) {
        return {
            ...result,
            ok: false,
            errors: [...result.errors, 'code is required.']
        };
    }
    return result;
};

export const init = async (payload: WorkerPayload): Promise<boolean> => {
    NODE_SCOPE.workflowId = String(payload.workflow?.metadata?.id ?? '');
    NODE_SCOPE.initialized = true;
    return true;
};

export const onUpdate = async (payload: WorkerPayload): Promise<WorkerUpdateResult> => {
    NODE_SCOPE.lastStatus = payload.self?.status ?? NODE_SCOPE.lastStatus;
    NODE_SCOPE.lastOutput = payload.self?.OUTPUT ?? NODE_SCOPE.lastOutput;
    return { ok: true, error: null };
};

export const commandToolSpec = async (payload: WorkerPayload): Promise<WorkflowCommandToolSpec> => {
    const node = toNode(payload);
    const runtime = toRecordValue(node.runtime);
    return {
        toolName: String(node.name || 'Code').trim() || 'Code',
        toolDescription: String(runtime.description || 'Run the configured code node with planner-supplied action input and dependency results.').trim(),
        inputContract: {
            required: [],
            optional: [{ key: 'payload', label: 'Payload', description: 'Planner-supplied JSON available to the code node through the payload inspector property.' }]
        },
        outputContract: [{ key: 'output', label: 'Output', description: 'Result returned by the configured code block.' }],
        metadata: { modelId: node.modelId },
        executionKind: 'tool'
    };
};

export const execute = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => {
    try {
        const node = toNode(payload);
        const runtime = toRecordValue(node.runtime);
        const code = String(runtime.code ?? 'return input;').trim() || 'return input;';
        const logs: string[] = [];
        const output = await executeCode(
            code,
            {
                input: buildNodeInput(runtime),
                properties: runtime,
                workflow: buildPublicWorkflowContext(toRecord(payload.workflow)),
                node: {
                    id: node.id,
                    name: node.name,
                    modelId: node.modelId,
                    status: node.status
                }
            },
            logs
        );

        return {
            output,
            status: 'passed',
            logs
        };
    } catch (error) {
        return toErrorResult(error instanceof Error ? error.message : 'Code node execution failed.');
    }
};
