# Code Node

## Runtime Ownership
Worker-first local node. No backend service is used.

## Usage
Write JavaScript in the node editor. The worker executes that code locally with access to `input`, `properties`, `workflow`, `node`, and `console`.

## Inputs
- `input`: Upstream payload for the code snippet.
- `code`: JavaScript authored in the inspector code editor.

## Outputs
- `output`: The direct return value from the executed code.
- `logs`: Any captured `console.*` output.

## Backend Mapping
- No backend service is used.

## Failure Cases
- Validation fails when the code editor is empty.
- Runtime fails when the code throws or rejects.
