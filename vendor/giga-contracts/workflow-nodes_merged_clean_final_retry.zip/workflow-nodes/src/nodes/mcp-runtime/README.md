# MCP Execute Node

## Runtime Ownership
Worker-first node. The UI/runtime enters through `worker.ts`, and backend execution is delegated through `[backend handler key]#executeMcpRuntimeNode`.

## Usage
Use this node to list tools and call a selected MCP tool through the selected `MCP` credential. Tool selection comes from upstream input, not from hardcoded node fields.

## Inputs
- `MCP` credential selected in the inspector.
- Tool call payload:
  - `{ "toolName": "GreetMe", "toolArguments": { "name": "Abeer" } }`
  - `{ "payload": { "toolName": "GreetMe", "toolArguments": { "name": "Abeer" } } }`
  - `{ "input": { "build_greet_request": { "toolName": "GreetMe", "toolArguments": { "name": "Abeer" } } } }`
  - `{ "current": { "toolName": "GreetMe", "toolArguments": { "name": "Abeer" } } }`
- Runtime fields: `capabilityQuery`, `forwardNonMcpWork`, `loopNonMcpWork`, `maxLoopPasses`, `outputContract`.

Connected workflow inputs are wrapped by upstream node id on the `input` port. MCP Execute unwraps a single valid tool-call payload automatically and fails if multiple upstream tool calls are present.

## Outputs
- `output`: Real MCP payload with `tools`, `toolCall`, `toolResult`, `serverInfo`, and `protocolVersion`.
- `loop`: Used only when no MCP tool call was provided and loop routing stays enabled.

## Backend Mapping
- Source: `/Users/abeer/dev/giga/giga-ai-backend/src/[backend handler key]`
- Handler: `executeMcpRuntimeNode`

## Failure Cases
- Validation fails when no MCP credential is selected.
- Validation fails when the selected MCP credential is malformed or unsupported.
- Runtime fails when more than one upstream payload contains an MCP tool call.
- Runtime fails with the MCP server error when the requested tool is rejected.
