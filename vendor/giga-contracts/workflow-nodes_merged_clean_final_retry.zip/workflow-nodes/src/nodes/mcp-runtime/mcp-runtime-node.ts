import rawSchema from '@workflow/nodes/nodes/mcp-runtime/mcp-runtime-schema.json';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';
import { MCP_LEGACY_FIELD_KEYS } from '@workflow/nodes/nodes/mcp/mcp-legacy-field-keys';
import { WorkflowNodeKindEnum } from '@workflow/nodes/types';

const schema = parseNodeSchema(rawSchema, 'mcp-runtime');

const renderMcpRuntimeIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <rect x="8" y="8" width="32" height="24" rx="6" stroke="currentColor" stroke-width="2.4"/>
  <path d="M16 20h16M24 32v8" stroke="currentColor" stroke-width="2.3" stroke-linecap="round"/>
  <circle cx="24" cy="20" r="2.3" fill="currentColor"/>
</svg>`;

const mcpRuntimeNodeModule: WorkflowNodeModule = {
    id: 'mcp-runtime',
    schema,
    library: {
        id: 'mcp-runtime-node',
        label: 'MCP Execute',
        description: 'List MCP tools and call an input-selected tool over streamable HTTP.',
        gigaId: 'McpRuntimeNode',
        modelId: 'mcp-runtime',
        group: 'MCP Group',
        nodeType: 'workflowStep',
        defaultKind: WorkflowNodeKindEnum.Process,
        iconColor: '#4f46e5',
        iconBackground: '#e0e7ff',
        order: 40
    },
    renderIcon: renderMcpRuntimeIcon,
    buildInitialNode: (context) => buildInitialNodeFromSchema(context),
    ui: {
        localCapable: false,
        serverOnly: true,
        inspector: {
            hiddenFieldKeys: MCP_LEGACY_FIELD_KEYS
        }
    },
    execute: createNodeModuleWorkerExecute('mcp-runtime')
};

export default mcpRuntimeNodeModule;
