import type { WorkflowCommandToolSpec } from '@workflow/executor';
import type { WorkerExecuteResult, WorkerPayload, WorkerScope, WorkerUpdateResult, WorkerValidateResult } from '@workflow/executor';
import {
    executeWorkflowMcpRuntimeNode,
    getWorkflowMcpRuntimeManager,
    normalizeResult,
    toErrorResult,
    toNode,
    toRecord,
    validateWorkflowMcpRuntime
} from '@workflow/executor';
import { executeBackend } from '@workflow/execute';

const NODE_SCOPE: WorkerScope = {};

const validateRetryPolicy = (runtime: Record<string, unknown>): string[] => {
    const failureMitigation = String(runtime.failureMitigation ?? 'stop-workflow').trim();
    if (failureMitigation !== 'retry-node' && failureMitigation !== 'stop-workflow') {
        return ['Failure Mitigation must be either "retry-node" or "stop-workflow".'];
    }
    if (failureMitigation !== 'retry-node') {
        return [];
    }
    const retryCount = Number(runtime.retryCount);
    if (!Number.isFinite(retryCount) || retryCount < 1 || retryCount > 6) {
        return ['Retry Count must be between 1 and 6 when Failure Mitigation is "retry-node".'];
    }
    return [];
};

export const validate = async (payload: WorkerPayload): Promise<WorkerValidateResult> => {
    const runtime = toRecord(toNode(payload).runtime);
    const mcpValidation = validateWorkflowMcpRuntime(runtime);
    const errors = [...validateRetryPolicy(runtime), ...mcpValidation.errors];
    return {
        ok: errors.length === 0,
        errors,
        warnings: [],
        normalizedRuntime: mcpValidation.normalizedRuntime
    };
};

export const init = async (payload: WorkerPayload): Promise<boolean> => {
    NODE_SCOPE.workflowId = String(toRecord(payload.workflow?.metadata).id ?? '');
    NODE_SCOPE.initialized = true;
    return true;
};

export const onUpdate = async (payload: WorkerPayload): Promise<WorkerUpdateResult> => {
    NODE_SCOPE.lastStatus = payload.self?.status ?? NODE_SCOPE.lastStatus;
    NODE_SCOPE.lastOutput = payload.self?.OUTPUT ?? NODE_SCOPE.lastOutput;
    return { ok: true, error: null };
};

const executeLocal = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => {
    try {
        const node = toNode(payload);
        const runtime = toRecord(node.runtime);
        const input = toRecord(runtime.sourceValue);
        const credential = toRecord(node.CREDENTIAL);
        return await executeWorkflowMcpRuntimeNode({
            runtime: node.runtime,
            input,
            manager: getWorkflowMcpRuntimeManager(payload.HOST_CONTEXT),
            credential: Object.keys(credential).length ? (node.CREDENTIAL as any) : null
        });
    } catch (error) {
        return toErrorResult(error instanceof Error ? error.message : 'Worker execution failed.');
    }
};

export const execute = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => {
    if (payload.ENVIRONMENT !== 'node') {
        return executeLocal(payload);
    }
    try {
        const result = await executeBackend(
            {
                key: 'executeMcpRuntimeNode',
                description: 'Execute node for MCP runtime tool discovery and tool calls.'
            },
            {
                NODE: toNode(payload),
                payload,
                NODE_SCOPE
            }
        );
        return normalizeResult(result);
    } catch (error) {
        return toErrorResult(error instanceof Error ? error.message : 'Worker execution failed.');
    }
};

// AI Agent command contract: keep this node usable as a declared tool without adding proxy wrappers.
type __GigaCommandRecord = Record<string, unknown>;
const __gigaCommandRecord = (value: unknown): __GigaCommandRecord =>
  value && typeof value === 'object' && !Array.isArray(value) ? (value as __GigaCommandRecord) : {};
const __gigaCommandText = (value: unknown): string => String(value ?? '').trim();
const __gigaCommandNode = (payload: WorkerPayload): __GigaCommandRecord =>
  __gigaCommandRecord((payload as { NODE?: unknown }).NODE || (payload as { self?: unknown }).self || payload);
const __gigaCommandRuntime = (payload: WorkerPayload): __GigaCommandRecord => {
  const node = __gigaCommandNode(payload);
  return { ...__gigaCommandRecord(node.runtime), ...__gigaCommandRecord(node.properties) };
};

export const commandToolSpec = async (payload: WorkerPayload): Promise<WorkflowCommandToolSpec> => {
  const node = __gigaCommandNode(payload);
  const runtime = __gigaCommandRuntime(payload);
  const modelId = __gigaCommandText(node.modelId || runtime.modelId || 'mcp-runtime');
  const configuredName = __gigaCommandText(node.name || runtime.name || runtime.title);
  const operation = __gigaCommandText(runtime.operation || runtime.action || runtime.mode || modelId || 'mcp-runtime');
  const haystack = `${configuredName} ${operation} ${modelId}`.toLowerCase();
  const mutating = runtime.mutating === true || /\b(create|update|delete|remove|link|unlink|attach|detach|publish|execute|run|write|save|train|install|ingest|fix|stop|wait)\b/.test(haystack);
  return {
    toolName: configuredName || 'MCP Runtime',
    toolDescription: __gigaCommandText(runtime.description || runtime.toolDescription) || 'Invoke an MCP runtime tool through the configured workflow/backend boundary.',
    inputContract: {
      required: [],
      optional: [

        { key: 'message', label: 'Message', description: 'Natural-language instruction or task for this node.' },
        { key: 'input', label: 'Input', description: 'Structured JSON input for the node.' },
        { key: 'operation', label: 'Operation', description: 'Operation/action name, when the node supports multiple operations.' },
        { key: 'prompt', label: 'Prompt', description: 'Prompt text for LLM or transformation nodes.' },
        { key: 'data', label: 'Data', description: 'Data payload for processing.' },
      ],
    },
    outputContract: [
      { key: 'output', label: 'Output', description: 'Node output payload.' },
      { key: 'status', label: 'Status', description: 'Execution status.' },
      { key: 'logs', label: 'Logs', description: 'Execution logs, when available.' },
    ],
    metadata: {
      modelId,
      nodeId: __gigaCommandText(node.id || node.nodeId),
      operation,
      toolDomain: 'mcp',
      mutating,
      reusableByAiAgent: true,
    },
    executionKind: 'tool',
  };
};

