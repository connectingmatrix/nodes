# Workflow

Worker-owned workflow node.

No backend service is used.

- `operation`: list, get, save, delete, publish
- `definitionSource`: cypher or ai
- `publishAfterSave`: publish immediately after save
- `workflowIdSource`: selector or input
- `workflowId`, `workflowName`, `workflowPrompt`, and `cypher` are explicit inspector fields
- `reason` can be patched by AI Agent or AI Governor through runtime fields

Connect one LLM node on `cmd:llm` when `definitionSource = ai`.
