import type { WorkflowCommandToolSpec, WorkerControlNodeFacade, WorkerExecuteResult, WorkerPayload, WorkerScope, WorkerUpdateResult, WorkerValidateResult } from '@workflow/executor';
import { normalizeResult, toNode } from '@workflow/executor';
import { compileWorkflowCypher, executeBackend } from '@workflow/execute';

const NODE_SCOPE: WorkerScope = {};
const descriptor = {
    key: 'executeWorkflowManagementBackendRequest',
    description: 'Manage workflows through existing backend workflow APIs.'
};
const recordValue = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});
const textValue = (value: unknown): string => String(value || '').trim();
const nodeValue = (payload: WorkerPayload) => recordValue((payload as { NODE?: unknown }).NODE || payload.self);
const extractCypher = (value: unknown): string => {
    let text = assistantText(value);
    const fenced = text.match(/```(?:cypher|txt|text)?\s*([\s\S]*?)```/i);
    if (fenced && fenced[1]) text = fenced[1].trim();
    const start = text.indexOf('(');
    return start > 0 ? text.slice(start).trim() : text;
};
const aiPrompt = (prompt: string): string => [
    'You generate Workflow Cypher.',
    'Return Workflow Cypher only.',
    'Do not explain the workflow.',
    'Do not use markdown fences.',
    'The result must compile as executable Workflow Cypher.',
    'Use this Cypher grammar:',
    '(alias:modelId {"name":"Name","runtime":{...}})',
    '(from)-[:CONNECT {"source":"out:output","target":"in:input"}]->(to)',
    'Executable workflows require exactly one start node and at least one respond-end node.',
    'Keep the workflow minimal and generic for the user request.',
    'Use code when a direct computed or text output is enough.',
    'Respond End must set runtime.response with an explicit variable binding from the code alias output or text field; write that token with double-left-brace, the alias path, and double-right-brace.',
    'Hello world example:',
    '(start:start {"name":"Start","runtime":{}})',
    '(code:code {"name":"Build Output","runtime":{"code":"return \\"hello world\\";"}})',
    '(end:respond-end {"name":"Respond End","runtime":{"response":"double-left-brace code.output double-right-brace"}})',
    '(start)-[:CONNECT {"source":"out:output","target":"in:input"}]->(code)',
    '(code)-[:CONNECT {"source":"out:output","target":"in:input"}]->(end)',
    `User request:\n${prompt}`
].join('\n\n');
const assistantText = (value: unknown): string => {
    if (typeof value === 'string') return value.trim();
    const record = recordValue(value);
    return textValue(record.text || record.output || record.result || record.content || record.answer);
};
const llmPeers = async (payload: WorkerPayload): Promise<Array<{ facade: WorkerControlNodeFacade; nodeId: string; key: string }>> => {
    const peers: Array<{ facade: WorkerControlNodeFacade; nodeId: string; key: string }> = [];
    for (const [key, value] of Object.entries(recordValue(recordValue((payload.NODE as { CONTROL_NODES?: unknown }).CONTROL_NODES).llm))) {
        const facade = value as WorkerControlNodeFacade;
        if (typeof facade?.get !== 'function' || typeof facade?.execute !== 'function' || typeof facade?.validate !== 'function' || typeof facade?.executeInputs !== 'function') continue;
        const snapshot = await facade.get();
        peers.push({ facade, nodeId: snapshot.nodeId, key });
    }
    return peers;
};
const resolveLlmPeer = async (payload: WorkerPayload) => {
    const peers = await llmPeers(payload);
    return peers[0] || null;
};
const generateCypher = async (payload: WorkerPayload, prompt: string): Promise<string> => {
    const peer = await resolveLlmPeer(payload);
    if (!peer) throw new Error('Workflow node requires one connected LLM when Definition Source is "AI".');
    const patch = { runtime: { prompt: aiPrompt(prompt) }, properties: { prompt: aiPrompt(prompt) } };
    const prepared = await peer.facade.executeInputs({ patch });
    const input = { ...prepared.input, input: { ...recordValue(prepared.input?.input), [toNode(payload).id]: { prompt: aiPrompt(prompt) } } };
    const validation = await peer.facade.validate({ input, patch });
    if (!validation.ok) throw new Error(validation.errors[0] || 'Connected LLM validation failed.');
    const executed = await peer.facade.execute({ input, patch });
    return extractCypher(recordValue(executed.result).output);
};
const workflowInput = (payload: WorkerPayload) => {
    const runtime = recordValue(toNode(payload).runtime);
    return {
        reason: textValue(runtime.reason || 'Workflow node execution.'),
        operation: textValue(runtime.operation || 'save'),
        saveMode: textValue(runtime.saveMode || 'create'),
        definitionSource: textValue(runtime.definitionSource || 'cypher'),
        publishAfterSave: runtime.publishAfterSave === true,
        workflowIdSource: textValue(runtime.workflowIdSource || 'input'),
        scope: textValue(runtime.scope || 'user') || 'user',
        organizationId: textValue(runtime.organizationId || runtime.organization_id),
        workflowId: textValue(runtime.workflowId || runtime.workflow_id),
        workflowName: textValue(runtime.workflowName || runtime.name),
        workflowDescription: textValue(runtime.workflowDescription || runtime.description),
        scopeType: textValue(runtime.scopeType || runtime.scope_type || 'channel') || 'channel',
        scopeId: textValue(runtime.scopeId || runtime.scope_id),
        scopeName: textValue(runtime.scopeName || runtime.scope_name || runtime.channelName || runtime.channel_name || runtime.targetName || runtime.target),
        workflowPrompt: textValue(runtime.workflowPrompt || runtime.prompt || runtime.request),
        cypher: textValue(runtime.cypher),
        executable: runtime.executable !== false
    };
};
const compileInput = async (payload: WorkerPayload, input: ReturnType<typeof workflowInput>) => {
    const metadata = recordValue(payload.workflow?.metadata);
    const cypher = input.definitionSource === 'ai' ? await generateCypher(payload, input.workflowPrompt) : input.cypher;
    const compiled = await compileWorkflowCypher({
        cypher,
        name: input.workflowName || 'Workflow',
        description: input.workflowDescription,
        executable: input.executable,
        metadata: { chat_id: textValue(metadata.chatId || metadata.chat_id), message: textValue(metadata.message) }
    });
    if (recordValue(compiled.validation).ok !== true) throw new Error((Array.isArray(recordValue(compiled.validation).errors) ? (recordValue(compiled.validation).errors as unknown[]) : []).map((entry) => textValue(entry)).filter(Boolean).join(' ') || 'Workflow Cypher is invalid.');
    return { compiled, cypher };
};

export const validate = async (payload: WorkerPayload): Promise<WorkerValidateResult> => {
    const runtime = recordValue(toNode(payload).runtime);
    const errors: string[] = [];
    const operation = textValue(runtime.operation || 'save');
    if (!['list', 'get', 'save', 'delete', 'publish', 'attach'].includes(operation)) errors.push('Operation must be list, get, save, delete, publish, or attach.');
    if (operation === 'save' && !['create', 'update'].includes(textValue(runtime.saveMode || 'create'))) errors.push('Save Mode must be create or update.');
    if (operation === 'save' && !['cypher', 'ai'].includes(textValue(runtime.definitionSource || 'cypher'))) errors.push('Definition Source must be cypher or ai.');
    return { ok: errors.length === 0, errors, warnings: [], normalizedRuntime: runtime };
};

export const init = async (payload: WorkerPayload): Promise<boolean> => ((NODE_SCOPE.workflowId = textValue(recordValue(payload.workflow?.metadata).id)), true);
export const onUpdate = async (payload: WorkerPayload): Promise<WorkerUpdateResult> => ((NODE_SCOPE.lastOutput = payload.self?.OUTPUT || NODE_SCOPE.lastOutput), { ok: true, error: null });

export const commandToolSpec = async (payload: WorkerPayload): Promise<WorkflowCommandToolSpec> => {
    const node = toNode(payload);
    const runtime = recordValue(node.runtime);
    const input = workflowInput(payload);
    return {
        toolName: textValue(node.name || 'Workflow') || 'Workflow',
        toolDescription: textValue(runtime.description || 'Manage workflows by listing, getting, saving, publishing, deleting, attaching, and executing workflow operations by explicit input.operation.'),
        inputContract: {
            required: [],
            optional: [
                { key: 'operation', label: 'Operation', description: 'One of list, get, save, delete, publish, or attach.' },
                { key: 'saveMode', label: 'Save Mode', description: 'For save operation: create or update.' },
                { key: 'definitionSource', label: 'Definition Source', description: 'For save operation: cypher or ai.' },
                { key: 'workflowId', label: 'Workflow ID', description: 'Workflow id for an existing workflow.' },
                { key: 'workflowName', label: 'Workflow Name', description: 'Workflow name when id is not known.' },
                { key: 'workflowDescription', label: 'Workflow Description', description: 'Optional workflow description.' },
                { key: 'workflowPrompt', label: 'Workflow Prompt', description: 'Prompt used when definitionSource is ai.' },
                { key: 'cypher', label: 'Workflow Cypher', description: 'Cypher used when definitionSource is cypher.' },
                { key: 'scope', label: 'Scope', description: 'Workflow scope: user or organization.' },
                { key: 'organizationId', label: 'Organization ID', description: 'Organization id when scope is organization.' },
                { key: 'scopeType', label: 'Scope Type', description: 'Target scope type such as channel, category, subject, or post.' },
                { key: 'scopeId', label: 'Scope ID', description: 'Target channel/category/subject/post id for attachment.' },
                { key: 'scopeName', label: 'Scope Name', description: 'Target channel/category/subject/post name for attachment.' }
            ]
        },
        outputContract: [{ key: 'workflow', label: 'Workflow', description: 'Saved or loaded workflow metadata.' }, { key: 'editorUrl', label: 'Editor URL', description: 'Workflow editor link.' }],
        metadata: {
            modelId: node.modelId,
            operation: 'dynamic',
            definitionSource: input.definitionSource,
            saveMode: input.saveMode,
            toolDomain: 'workflow',
            mutating: false,
            mutatingActions: ['save', 'publish', 'delete', 'attach'],
            workflowActions: ['save', 'publish', 'delete', 'attach', 'get', 'list'],
            workflowOutput: false
        },
        executionKind: 'tool'
    };
};

export const execute = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => {
    try {
        const input = workflowInput(payload);
        const compiled = input.operation === 'save' ? await compileInput(payload, input) : null;
        const result = await executeBackend(descriptor, {
            request: {
                ...input,
                workflow: compiled?.compiled.workflow || null,
                validation: recordValue(compiled?.compiled.validation),
                cypher: compiled?.cypher || input.cypher
            }
        });
        return normalizeResult(result);
    } catch (error) {
        const message = error instanceof Error ? error.message : 'Workflow node execution failed.';
        return { output: { error: message }, status: 'failed', logs: [message] };
    }
};
