import rawSchema from '@workflow/nodes/nodes/workflow/workflow-schema.json';
import { createServerOnlyNodeModule } from '@workflow/nodes/nodes/server-only/server-node.module.factory';

const renderIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <rect x="8" y="8" width="32" height="32" rx="6" stroke="currentColor" stroke-width="2.4"/>
  <path d="M16 18h16M16 24h16M16 30h10" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>
</svg>`;

export default createServerOnlyNodeModule({
    id: 'workflow',
    rawSchema,
    library: {
        id: 'giga-workflow',
        label: 'Workflow',
        description: 'Create, fetch, save, publish, and delete workflows through reusable worker-owned logic.',
        gigaId: 'GigaWorkflowNode',
        modelId: 'workflow',
        group: 'Giga AI Nodes',
        order: 221,
        iconColor: '#155e75',
        iconBackground: '#ecfeff'
    },
    iconSvg: renderIcon
});
