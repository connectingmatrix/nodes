import rawSchema from './slack-schema.json';
import { createAgentBackendNodeModule } from '@workflow/nodes/nodes/_agent-backend-node-module';

export default createAgentBackendNodeModule({ id: 'slack', rawSchema, label: 'Slack', description: 'Read/send Slack messages through centralized backend capabilities.', kind: 'chat', order: 515 });
