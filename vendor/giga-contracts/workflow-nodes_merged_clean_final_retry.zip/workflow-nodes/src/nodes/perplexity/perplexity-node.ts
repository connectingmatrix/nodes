import rawSchema from '@workflow/nodes/nodes/perplexity/perplexity-schema.json';
import { createServerOnlyNodeModule } from '@workflow/nodes/nodes/server-only/server-node.module.factory';

const renderIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <circle cx="24" cy="24" r="14" stroke="currentColor" stroke-width="2.4"/>
  <circle cx="24" cy="24" r="5" fill="currentColor"/>
  <path d="M24 10v5M24 33v5M10 24h5M33 24h5" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>
</svg>`;

const nodeModule = createServerOnlyNodeModule({
    id: 'perplexity',
    rawSchema,
    library: {
        id: 'perplexity-node',
        label: 'Perplexity',
        description: 'Execute Perplexity model on server.',
        gigaId: 'PerplexityNode',
        modelId: 'perplexity',
        group: 'AI Models',
        order: 129,
        iconColor: '#1d4ed8',
        iconBackground: '#dbeafe'
    },
    iconSvg: renderIcon
});

export default nodeModule;
