import type { WorkflowCommandToolSpec } from '@workflow/executor';
import type { WorkerExecuteResult, WorkerPayload, WorkerScope, WorkerUpdateResult, WorkerValidateResult } from '@workflow/executor';
import { toErrorResult, toNode, toRecord } from '@workflow/executor';

const NODE_SCOPE: WorkerScope = {};
const ACCESS_TOKEN_STORAGE_KEY = 'giga_access_token';
const REFRESH_TOKEN_STORAGE_KEY = 'giga_refresh_token';
const VALID_METHODS = new Set<string>(['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS']);

const toRecordValue = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});

const toStringValue = (value: unknown): string => String(value ?? '').trim();

const parseHeaderRecord = (value: unknown): Record<string, string> =>
    Object.entries(toRecordValue(value)).reduce<Record<string, string>>((acc, [key, entry]) => {
        const normalizedKey = key.trim();
        const normalizedValue = toStringValue(entry);
        if (!normalizedKey || !normalizedValue) return acc;
        acc[normalizedKey] = normalizedValue;
        return acc;
    }, {});

const decodeBase64 = (value: string): Uint8Array => {
    if (typeof atob === 'function') {
        const binary = atob(value);
        return Uint8Array.from(binary, (entry) => entry.charCodeAt(0));
    }
    const bufferCtor = (globalThis as { Buffer?: { from: (value: string, encoding: string) => ArrayLike<number> } }).Buffer;
    if (bufferCtor) {
        return Uint8Array.from(bufferCtor.from(value, 'base64'));
    }
    return new Uint8Array();
};

const readStoredTokens = (): { accessToken?: string; refreshToken?: string } => {
    const storage = typeof globalThis !== 'undefined' ? (globalThis as { localStorage?: Storage }).localStorage : undefined;
    if (!storage) return {};
    const accessToken = storage.getItem(ACCESS_TOKEN_STORAGE_KEY) ?? undefined;
    const refreshToken = storage.getItem(REFRESH_TOKEN_STORAGE_KEY) ?? undefined;
    return { accessToken, refreshToken };
};

const resolveAuthHeaders = (settings: Record<string, unknown>): Record<string, string> => {
    const authMode = toStringValue(settings.authMode).toLowerCase();
    if (authMode === 'none') return {};
    if (authMode === 'manual') return parseHeaderRecord(settings.manualHeaders);
    const tokens = readStoredTokens();
    if (!tokens.accessToken) return {};
    return {
        Authorization: `Bearer access_token=${tokens.accessToken};refresh_token=${tokens.refreshToken ?? ''}`
    };
};

const getSettings = (payload: WorkerPayload): Record<string, unknown> => toRecordValue(toRecordValue(toRecordValue(payload.workflow?.metadata).runtime).settings);

const buildRequestBody = (runtime: Record<string, unknown>, method: string): { body?: BodyInit; headers: Record<string, string> } => {
    const headers = parseHeaderRecord(runtime.headers);
    if (method === 'GET' || method === 'HEAD' || method === 'OPTIONS') {
        return { headers };
    }

    const bodyMode = toStringValue(runtime.bodyMode || 'json').toLowerCase();
    if (bodyMode === 'form-data') {
        const form = new FormData();
        Object.entries(toRecordValue(runtime.formBody)).forEach(([key, value]) => {
            form.append(key, toStringValue(value));
        });
        const files = Array.isArray(runtime.files) ? runtime.files : [];
        files.forEach((entry) => {
            const file = toRecordValue(entry);
            const contentBase64 = toStringValue(file.contentBase64);
            if (!contentBase64) return;
            const name = toStringValue(file.name) || 'attachment.bin';
            const mimeType = toStringValue(file.mimeType) || 'application/octet-stream';
            const bytes = decodeBase64(contentBase64);
            const buffer = new ArrayBuffer(bytes.byteLength);
            new Uint8Array(buffer).set(bytes);
            const blob = new Blob([buffer], { type: mimeType });
            form.append('files', blob, name);
        });
        return { body: form, headers };
    }

    if (bodyMode === 'url-encoded') {
        const params = new URLSearchParams();
        Object.entries(toRecordValue(runtime.formBody)).forEach(([key, value]) => {
            params.set(key, toStringValue(value));
        });
        return {
            body: params,
            headers: {
                ...headers,
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        };
    }

    return {
        body: JSON.stringify(toRecordValue(runtime.jsonBody)),
        headers: {
            ...headers,
            'Content-Type': 'application/json'
        }
    };
};

const validateFailureMitigation = (runtime: Record<string, unknown>): WorkerValidateResult => {
    const errors: string[] = [];
    const warnings: string[] = [];
    const failureMitigation = toStringValue(runtime.failureMitigation || 'stop-workflow');
    if (failureMitigation !== 'retry-node' && failureMitigation !== 'stop-workflow') {
        errors.push('Failure Mitigation must be either "retry-node" or "stop-workflow".');
    }
    if (failureMitigation === 'retry-node') {
        const retryCount = Number(runtime.retryCount);
        if (!Number.isFinite(retryCount) || retryCount < 1 || retryCount > 6) {
            errors.push('Retry Count must be between 1 and 6 when Failure Mitigation is "retry-node".');
        }
    }
    return { ok: errors.length === 0, errors, warnings, normalizedRuntime: runtime };
};

export const validate = async (payload: WorkerPayload): Promise<WorkerValidateResult> => {
    const runtime = toRecordValue(toNode(payload).runtime);
    const result = validateFailureMitigation(runtime);
    const url = toStringValue(runtime.url);
    if (!url) {
        result.ok = false;
        result.errors.push('url is required.');
    }
    const method = toStringValue(runtime.method || 'GET').toUpperCase();
    if (!VALID_METHODS.has(method)) {
        result.ok = false;
        result.errors.push(`method must be one of: ${Array.from(VALID_METHODS).join(', ')}.`);
    }
    const timeout = Number(runtime.timeout ?? 60000);
    if (!Number.isFinite(timeout) || timeout < 100 || timeout > 300000) {
        result.ok = false;
        result.errors.push('timeout must be a number between 100 and 300000 milliseconds.');
    }
    result.normalizedRuntime = {
        ...(result.normalizedRuntime ?? runtime),
        method
    };
    return result;
};

export const init = async (payload: WorkerPayload): Promise<boolean> => {
    NODE_SCOPE.workflowId = String(payload.workflow?.metadata?.id ?? '');
    NODE_SCOPE.initialized = true;
    return true;
};

export const onUpdate = async (payload: WorkerPayload): Promise<WorkerUpdateResult> => {
    NODE_SCOPE.lastStatus = payload.self?.status ?? NODE_SCOPE.lastStatus;
    NODE_SCOPE.lastOutput = payload.self?.OUTPUT ?? NODE_SCOPE.lastOutput;
    return { ok: true, error: null };
};

export const executeLocal = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => {
    try {
        const node = toNode(payload);
        const runtime = toRecordValue(node.runtime);
        const settings = getSettings(payload);
        const method = toStringValue(runtime.method || 'GET').toUpperCase();
        const endpoint = toStringValue(runtime.url);
        const baseUrl = toStringValue(settings.httpBaseUrl);
        const url = endpoint.startsWith('http://') || endpoint.startsWith('https://') ? endpoint : `${baseUrl}${endpoint}`;
        if (!url) {
            return toErrorResult('url is required.');
        }

        const timeoutMs = Number(runtime.timeout ?? 60000);
        const controller = new AbortController();
        const timeoutId = Number.isFinite(timeoutMs) ? setTimeout(() => controller.abort(), timeoutMs) : null;
        const { body, headers } = buildRequestBody(runtime, method);
        const response = await fetch(url, {
            method,
            headers: {
                ...resolveAuthHeaders(settings),
                ...headers
            },
            body,
            signal: controller.signal
        });
        if (timeoutId) clearTimeout(timeoutId);

        const responseText = await response.text();
        let data: unknown = responseText;
        try {
            data = JSON.parse(responseText);
        } catch {
            data = responseText;
        }

        const responseHeaders = Array.from(response.headers.entries()).reduce<Record<string, string>>((acc, [key, value]) => {
            acc[key] = value;
            return acc;
        }, {});

        return {
            output: {
                status: response.status,
                ok: response.ok,
                data,
                headers: responseHeaders,
                url
            },
            status: response.ok ? 'passed' : 'failed'
        };
    } catch (error) {
        return toErrorResult(error instanceof Error ? error.message : 'HTTP Request node execution failed.');
    }
};

export const execute = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => executeLocal(payload);

// AI Agent command contract: keep this node usable as a declared tool without adding proxy wrappers.
type __GigaCommandRecord = Record<string, unknown>;
const __gigaCommandRecord = (value: unknown): __GigaCommandRecord =>
  value && typeof value === 'object' && !Array.isArray(value) ? (value as __GigaCommandRecord) : {};
const __gigaCommandText = (value: unknown): string => String(value ?? '').trim();
const __gigaCommandNode = (payload: WorkerPayload): __GigaCommandRecord =>
  __gigaCommandRecord((payload as { NODE?: unknown }).NODE || (payload as { self?: unknown }).self || payload);
const __gigaCommandRuntime = (payload: WorkerPayload): __GigaCommandRecord => {
  const node = __gigaCommandNode(payload);
  return { ...__gigaCommandRecord(node.runtime), ...__gigaCommandRecord(node.properties) };
};

export const commandToolSpec = async (payload: WorkerPayload): Promise<WorkflowCommandToolSpec> => {
  const node = __gigaCommandNode(payload);
  const runtime = __gigaCommandRuntime(payload);
  const modelId = __gigaCommandText(node.modelId || runtime.modelId || 'http-request');
  const configuredName = __gigaCommandText(node.name || runtime.name || runtime.title);
  const operation = __gigaCommandText(runtime.operation || runtime.action || runtime.mode || modelId || 'http-request');
  const haystack = `${configuredName} ${operation} ${modelId}`.toLowerCase();
  const mutating = runtime.mutating === true || /\b(create|update|delete|remove|link|unlink|attach|detach|publish|execute|run|write|save|train|install|ingest|fix|stop|wait)\b/.test(haystack);
  return {
    toolName: configuredName || 'HTTP Request',
    toolDescription: __gigaCommandText(runtime.description || runtime.toolDescription) || 'Perform an HTTP request when allowed by workflow policy and node configuration.',
    inputContract: {
      required: [],
      optional: [

        { key: 'message', label: 'Message', description: 'Natural-language instruction or task for this node.' },
        { key: 'input', label: 'Input', description: 'Structured JSON input for the node.' },
        { key: 'operation', label: 'Operation', description: 'Operation/action name, when the node supports multiple operations.' },
        { key: 'prompt', label: 'Prompt', description: 'Prompt text for LLM or transformation nodes.' },
        { key: 'data', label: 'Data', description: 'Data payload for processing.' },
      ],
    },
    outputContract: [
      { key: 'output', label: 'Output', description: 'Node output payload.' },
      { key: 'status', label: 'Status', description: 'Execution status.' },
      { key: 'logs', label: 'Logs', description: 'Execution logs, when available.' },
    ],
    metadata: {
      modelId,
      nodeId: __gigaCommandText(node.id || node.nodeId),
      operation,
      toolDomain: 'http',
      mutating,
      reusableByAiAgent: true,
    },
    executionKind: 'tool',
  };
};

