import rawSchema from '@workflow/nodes/nodes/http-request/http-request-schema.json';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { WorkflowNodeKindEnum } from '@workflow/nodes/types';
import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';

const schema = parseNodeSchema(rawSchema, 'http-request');

const renderHttpIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <circle cx="24" cy="24" r="17" stroke="currentColor" stroke-width="2.4"/>
  <path d="M7 24h34M24 7c4 4.2 6.2 10 6.2 17S28 36.8 24 41M24 7c-4 4.2-6.2 10-6.2 17S20 36.8 24 41" stroke="currentColor" stroke-width="2"/>
</svg>`;

const httpRequestNodeModule: WorkflowNodeModule = {
    id: 'http-request',
    schema,
    library: {
        id: 'http-node',
        label: 'HTTP Request',
        description: 'GET/POST/OPTIONS request node with files.',
        gigaId: 'HttpRequestNode',
        modelId: 'http-request',
        group: 'Server Actions',
        nodeType: 'workflowStep',
        defaultKind: WorkflowNodeKindEnum.Process,
        iconColor: '#0369a1',
        iconBackground: '#e0f2fe',
        order: 70
    },
    renderIcon: renderHttpIcon,
    buildInitialNode: (context) => buildInitialNodeFromSchema(context),
    ui: {
        localCapable: true,
        serverOnly: false
    },
    execute: createNodeModuleWorkerExecute('http-request')
};

export default httpRequestNodeModule;
