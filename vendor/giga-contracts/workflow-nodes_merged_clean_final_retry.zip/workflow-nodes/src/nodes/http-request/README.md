# Http Request Node

## Runtime Ownership
Worker-first local node. No backend service is used.

## Usage
Issue HTTP requests directly from the worker with JSON, URL-encoded, or multipart form bodies, including optional attached files.

## Inputs
- `method`: HTTP method.
- `url`: Absolute URL or path resolved against `httpBaseUrl`.
- `headers`: Optional request headers.
- `bodyMode`: `json`, `url-encoded`, or `form-data`.
- `jsonBody` / `formBody`: Request payload fields.
- `files`: Optional file envelopes for multipart uploads.

## Outputs
- `output`: Response status, success flag, parsed response data, response headers, and final URL.

## Backend Mapping
- No backend service is used.

## Failure Cases
- Fails when `url` is missing.
- Fails when the method is invalid.
- Fails when the request throws or times out.
