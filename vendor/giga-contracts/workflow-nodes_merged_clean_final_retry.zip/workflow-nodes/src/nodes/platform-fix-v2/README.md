# Platform Fix V2

Routes to `platform.fix.plan.v2` through `executeBackend`. The node never opens Supabase, Neo4j, local files, or network resources directly.
