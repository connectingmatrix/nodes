export const platform_fix_V2Node = {
  id: 'platform-fix-v2',
  type: 'platform-fix-v2',
  name: 'Platform Fix V2',
  version: '20.0.0',
  tool: 'platform.fix.plan.v2',
};
export default platform_fix_V2Node;
