import rawSchema from '@workflow/nodes/nodes/replace-me/replace-me-schema.json';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { WorkflowNodeKindEnum } from '@workflow/nodes/types';

const schema = parseNodeSchema(rawSchema, 'replace-me');

const renderReplaceMeIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <rect x="10" y="10" width="12" height="12" rx="2.5" stroke="currentColor" stroke-width="2.4"/>
  <rect x="26" y="26" width="12" height="12" rx="2.5" stroke="currentColor" stroke-width="2.4"/>
  <path d="M23 16h3a6 6 0 0 1 6 6v3" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>
  <path d="M17 32h-3a6 6 0 0 1-6-6v-3" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>
</svg>`;

const replaceMeNodeModule: WorkflowNodeModule = {
    id: 'replace-me',
    schema,
    library: {
        id: 'replace-me-node',
        label: 'Replace Me',
        description: 'Replace string values across the input payload.',
        gigaId: 'ReplaceMeNode',
        modelId: 'replace-me',
        group: 'Flow Nodes',
        nodeType: 'workflowStep',
        defaultKind: WorkflowNodeKindEnum.Process,
        iconColor: '#334155',
        iconBackground: '#f1f5f9',
        order: 19
    },
    renderIcon: renderReplaceMeIcon,
    buildInitialNode: (context) => buildInitialNodeFromSchema(context),
    ui: {
        localCapable: true,
        serverOnly: false
    },
    execute: createNodeModuleWorkerExecute('replace-me')
};

export default replaceMeNodeModule;
