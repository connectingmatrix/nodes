# Replace Me Node

## Runtime Ownership
Worker-first local node. No backend service is used.

## Usage
Set Find Value and Replace With. Replacement is case-sensitive and global in string values; object keys are untouched.

## Inputs
- `Control Port: Command`: Bi-directional control-state input from connected command peers.
- `Input Port: Input`: Incoming data edge payload for this port.
- `Find Value`: String or variable value to find in payload string values.
- `Replace With`: String or variable value used as replacement for each match.
- `Failure Mitigation`: Failure Mitigation value for this node.
- `Retry Count`: Retries value for this node.

## Outputs
- `Control Port: Command`: Publishes this node control state for connected command peers.
- `Output Port: Output`: Outgoing payload emitted after node execution.

## Backend Mapping
- No backend service is used.

## Failure Cases
- No-op when Find Value resolves to an empty string.
- Runtime failures are surfaced in workflow logs and node output as an `error` payload.
