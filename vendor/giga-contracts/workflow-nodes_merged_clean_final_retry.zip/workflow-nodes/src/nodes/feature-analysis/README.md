# Feature Analysis

Analyze product/data feature impact from datasets.

This node is command-capable and routes backend operations through `executeBackend`. It does not access Supabase or Neo4j directly.
