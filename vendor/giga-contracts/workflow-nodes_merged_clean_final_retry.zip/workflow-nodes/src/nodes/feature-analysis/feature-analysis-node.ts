import rawSchema from './feature-analysis-schema.json';
import { createAgentBackendNodeModule } from '@workflow/nodes/nodes/_agent-backend-node-module';

export default createAgentBackendNodeModule({ id: 'feature-analysis', rawSchema, label: 'Feature Analysis', description: 'Analyze product/data feature impact from datasets.', kind: 'database', order: 525 });
