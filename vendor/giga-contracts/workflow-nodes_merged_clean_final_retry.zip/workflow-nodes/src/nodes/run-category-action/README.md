# Category

## Runtime Ownership
Server-only workflow node.

## Usage
Select one category action and provide backend arguments in `parameters` rows.

## Inputs
- `action`: `read_category`, `create_category`, `update_category`, `delete_category`, or `link_category`.
- `chatId`: Runtime chat scope, with workflow metadata fallback.
- `parameters`: Add key/value rows for the selected backend action.

## Outputs
- `action`: Backend `AgentActionResult` wrapper.

## Backend Mapping
- `[backend handler key]`
- `executeGroupedActionNode`
