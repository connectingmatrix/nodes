# Chart Node

Worker-owned server node that creates `[chart]` markup through `@workflow/charts`.

- Uses the connected LLM command port when Library or Template is `Auto`.
- Does not call `executeBackend`.
- Emits the exact markup block plus the renderable chart object when Output Mode is `Chart Markup + Chart`.
- Returns a clear validation error in browser/local runtime for v1.
