import { chartLibraries, chartTemplates, getTemplatesByLibrary } from '@workflow/charts/catalog';
import rawSchema from '@workflow/nodes/nodes/chart/chart-schema.json';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';
import { WorkflowNodeFieldMap, WorkflowNodeKindEnum } from '@workflow/nodes/types';

const schema = parseNodeSchema(rawSchema, 'chart');
const option = (label: string, value: string) => ({ label, value });
const libraryOptions = [option('Auto (use connected LLM)', 'auto'), ...chartLibraries.map((library) => option(library.name, library.id))];
const templateOptions = (libraryId: string) => [
    option('Auto (use connected LLM)', 'auto'),
    ...(libraryId && libraryId !== 'auto' ? getTemplatesByLibrary(libraryId) : chartTemplates).map((template) => option(template.chartName, template.id))
];
const inputOptions = (templateId: string) => (chartTemplates.find((template) => template.id === templateId)?.inputDefinitions || []).map((field) => option(field.label, field.key));
const resolveTemplateInputs = (templateId: string) => chartTemplates.find((template) => template.id === templateId)?.inputDefinitions || [];
const seedTemplateInputRows = (templateInputs: Array<{ key: string; defaultValue?: unknown }>) => {
    const rows: Array<{ key: string; value: unknown }> = [];
    for (const input of templateInputs) rows.push({ key: input.key, value: input.defaultValue ?? '' });
    return rows;
};

const renderChartIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <rect x="8" y="8" width="32" height="32" rx="6" stroke="currentColor" stroke-width="2.4"/>
  <path d="M16 32V22M24 32V16M32 32V26" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>
</svg>`;

const withChartOptions = (fields: WorkflowNodeFieldMap, libraryId: string, templateId: string): WorkflowNodeFieldMap => {
    const templateInputs = resolveTemplateInputs(templateId);
    const firstInput = templateInputs[0];

    return {
        ...fields,
        libraryId: { ...fields.libraryId, options: libraryOptions },
        chartTemplateId: { ...fields.chartTemplateId, options: templateOptions(libraryId) },
        selectedInputs: {
            ...fields.selectedInputs,
            defaultValue: seedTemplateInputRows(templateInputs),
            subFields: {
                ...fields.selectedInputs?.subFields,
                key: {
                    ...fields.selectedInputs?.subFields?.key,
                    defaultValue: firstInput?.key ?? '',
                    options: inputOptions(templateId)
                },
                value: {
                    ...fields.selectedInputs?.subFields?.value,
                    defaultValue: firstInput?.defaultValue ?? ''
                }
            }
        }
    };
};

const chartNodeModule: WorkflowNodeModule = {
    id: 'chart',
    schema,
    library: {
        id: 'chart-node',
        label: 'Chart',
        description: 'Create renderable [chart] markup from a prompt and selected chart options.',
        gigaId: 'ChartNode',
        modelId: 'chart',
        group: 'Giga AI Nodes',
        nodeType: 'workflowStep',
        defaultKind: WorkflowNodeKindEnum.Process,
        iconColor: '#0f766e',
        iconBackground: '#ccfbf1',
        order: 132
    },
    renderIcon: renderChartIcon,
    buildInitialNode: (context) => buildInitialNodeFromSchema(context),
    ui: { localCapable: false, serverOnly: true },
    resolveInspectorFields: ({ node, fields }) => withChartOptions(fields, String(node.runtime?.libraryId || 'auto'), String(node.runtime?.chartTemplateId || 'auto')),
    execute: createNodeModuleWorkerExecute('chart')
};

export default chartNodeModule;
