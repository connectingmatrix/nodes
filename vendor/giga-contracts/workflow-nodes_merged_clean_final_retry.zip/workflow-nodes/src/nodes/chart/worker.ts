import type {
  WorkflowCommandToolSpec,
  WorkerControlNodeFacade,
  WorkerExecuteResult,
  WorkerPayload,
  WorkerScope,
  WorkerUpdateResult,
  WorkerValidateResult,
} from "@workflow/executor";
import type {
  ChartInputs,
  ChartLayout,
  WorkflowChartSelection,
} from "@workflow/charts";
import { toNode } from "@workflow/executor";
import {
  buildChartSelectionPrompt,
  chartTemplates,
  createWorkflowChart,
  getTemplateById,
  inferTemplateFromPrompt,
  parseChartSelectionResponse,
  serializeWorkflowChartMarkdown,
} from "@workflow/charts";

const NODE_SCOPE: WorkerScope = {};
const recordValue = (value: unknown): Record<string, unknown> =>
  value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {};
const textValue = (value: unknown): string => String(value || "").trim();
const numericValue = (value: unknown, fallback: number): number =>
  Number.isFinite(Number(value)) ? Number(value) : fallback;
const nodeRuntime = (payload: WorkerPayload): Record<string, unknown> =>
  recordValue(toNode(payload).runtime);
const selectedInputs = (value: unknown): ChartInputs =>
  recordValue(value) as ChartInputs;
const needsLlm = (input: ReturnType<typeof chartInput>): boolean =>
  input.libraryId === "auto" || input.chartTemplateId === "auto";

const selectFromCatalog = (prompt: string): WorkflowChartSelection => {
  const templateId = inferTemplateFromPrompt(
    prompt,
    chartTemplates.map((template) => template.id),
  );
  const template = getTemplateById(templateId);
  if (!template) throw new Error(`Unknown chart template: ${templateId}`);
  return {
    libraryId: template.libraryId,
    rankedChartTemplateIds: [template.id],
    debugJson: JSON.stringify({
      libraryId: template.libraryId,
      rankedChartTemplateIds: [template.id],
      selectionSource: "catalog",
    }),
  };
};

const assistantText = (value: unknown): string => {
  if (typeof value === "string") return value.trim();
  const record = recordValue(value);
  return textValue(
    record.text ||
      record.output ||
      record.result ||
      record.content ||
      record.answer ||
      record.markdown,
  );
};

const llmPeers = async (
  payload: WorkerPayload,
): Promise<
  Array<{ facade: WorkerControlNodeFacade; nodeId: string; key: string }>
> => {
  const peers: Array<{
    facade: WorkerControlNodeFacade;
    nodeId: string;
    key: string;
  }> = [];
  for (const [key, value] of Object.entries(
    recordValue(
      recordValue((payload.NODE as { CONTROL_NODES?: unknown }).CONTROL_NODES)
        .llm,
    ),
  )) {
    const facade = value as WorkerControlNodeFacade;
    if (
      typeof facade?.get !== "function" ||
      typeof facade?.execute !== "function" ||
      typeof facade?.validate !== "function" ||
      typeof facade?.executeInputs !== "function"
    )
      continue;
    const snapshot = await facade.get();
    peers.push({ facade, nodeId: snapshot.nodeId, key });
  }
  return peers;
};

const chartInput = (payload: WorkerPayload) => {
  const runtime = nodeRuntime(payload);
  const height = Math.max(
    120,
    Math.floor(numericValue(runtime.layoutHeight, 360)),
  );
  const colSpan = numericValue(runtime.colSpan, 12);
  const resolvedColSpan: ChartLayout["colSpan"] =
    colSpan === 3 || colSpan === 4 || colSpan === 6 ? colSpan : 12;
  return {
    prompt: textValue(runtime.prompt),
    libraryId: textValue(runtime.libraryId || "auto") || "auto",
    chartTemplateId: textValue(runtime.chartTemplateId || "auto") || "auto",
    selectedInputs: selectedInputs(runtime.selectedInputs),
    layout: { height, colSpan: resolvedColSpan },
    outputMode: textValue(runtime.outputMode || "both") || "both",
  };
};

const selectWithLlm = async (
  payload: WorkerPayload,
  prompt: string,
): Promise<WorkflowChartSelection> => {
  const peer = (await llmPeers(payload))[0];
  if (!peer)
    throw new Error(
      "Chart node requires one connected LLM when Library or Template is Auto.",
    );
  const llmPrompt = buildChartSelectionPrompt(prompt);
  const patch = {
    runtime: { prompt: llmPrompt },
    properties: { prompt: llmPrompt },
  };
  const prepared = await peer.facade.executeInputs({ patch });
  const input = {
    ...prepared.input,
    input: {
      ...recordValue(prepared.input?.input),
      [toNode(payload).id]: { prompt: llmPrompt },
    },
  };
  const validation = await peer.facade.validate({ input, patch });
  if (!validation.ok)
    throw new Error(validation.errors[0] || "Connected LLM validation failed.");
  const executed = await peer.facade.execute({ input, patch });
  return parseChartSelectionResponse(
    assistantText(recordValue(executed.result).output),
  );
};

export const validate = async (
  payload: WorkerPayload,
): Promise<WorkerValidateResult> => {
  const input = chartInput(payload);
  const errors: string[] = [];
  if (payload.EXECUTOR.environment !== "node")
    errors.push(
      "Chart node is server-worker only for v1. Run this workflow on the server.",
    );
  if (!input.prompt) errors.push("Chart Prompt is required.");
  if (!["both", "markup", "chart"].includes(input.outputMode))
    errors.push(
      "Output Mode must be Chart Markup + Chart, Chart Markup Only, or Chart Object Only.",
    );
  return {
    ok: errors.length === 0,
    errors,
    warnings: [],
    normalizedRuntime: nodeRuntime(payload),
  };
};

export const init = async (payload: WorkerPayload): Promise<boolean> => (
  (NODE_SCOPE.workflowId = textValue(
    recordValue(payload.workflow?.metadata).id,
  )),
  true
);
export const onUpdate = async (
  payload: WorkerPayload,
): Promise<WorkerUpdateResult> => (
  (NODE_SCOPE.lastOutput = payload.self?.OUTPUT || NODE_SCOPE.lastOutput),
  { ok: true, error: null }
);

export const commandToolSpec = async (
  payload: WorkerPayload,
): Promise<WorkflowCommandToolSpec> => ({
  toolName: textValue(toNode(payload).name || "Chart") || "Chart",
  toolDescription: textValue(
    nodeRuntime(payload).description ||
      "Create renderable [chart] markup from chart requests.",
  ),
  inputContract: {
    required: [
      {
        key: "prompt",
        label: "Chart Prompt",
        description: "Natural language chart request.",
        required: true,
      },
    ],
    optional: [
      {
        key: "libraryId",
        label: "Library",
        description: "Chart library id or auto.",
      },
      {
        key: "chartTemplateId",
        label: "Template",
        description: "Chart template id or auto.",
      },
    ],
  },
  outputContract: [
    { key: "markup", label: "Chart Markup", description: "Exact [chart] markup." },
    { key: "chart", label: "Chart", description: "DashboardChart object." },
  ],
  metadata: {
    modelId: "chart",
    toolDomain: "chart",
    mutating: false,
    workflowOutput: true,
  },
  executionKind: "tool",
});

export const execute = async (
  payload: WorkerPayload,
): Promise<WorkerExecuteResult> => {
  try {
    if (payload.EXECUTOR.environment !== "node")
      throw new Error(
        "Chart node is server-worker only for v1. Run this workflow on the server.",
      );
    const input = chartInput(payload);
    const selection = needsLlm(input)
      ? selectFromCatalog(input.prompt)
      : undefined;
    const chart = createWorkflowChart({
      prompt: input.prompt,
      libraryId: input.libraryId,
      chartTemplateId: input.chartTemplateId,
      selectedInputs: input.selectedInputs,
      layout: input.layout,
      selection,
    });
    const markup = serializeWorkflowChartMarkdown(chart);
    const output =
      input.outputMode === "markup"
        ? markup
        : input.outputMode === "chart"
          ? chart
          : { markup, markdown: markup, chart, type: "chart", version: 1 };
    return {
      output,
      status: "passed",
      logs: [
        selection
          ? "Chart markup created with catalog auto-selection."
          : "Chart markup created.",
      ],
    };
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Chart node execution failed.";
    return { output: { error: message }, status: "failed", logs: [message] };
  }
};
