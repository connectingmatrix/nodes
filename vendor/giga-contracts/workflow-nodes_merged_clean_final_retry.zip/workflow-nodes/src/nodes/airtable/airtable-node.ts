import rawSchema from './airtable-schema.json';
import { createAgentBackendNodeModule } from '@workflow/nodes/nodes/_agent-backend-node-module';

export default createAgentBackendNodeModule({ id: 'airtable', rawSchema, label: 'Airtable', description: 'Read/write Airtable through centralized backend capabilities.', kind: 'database', order: 512 });
