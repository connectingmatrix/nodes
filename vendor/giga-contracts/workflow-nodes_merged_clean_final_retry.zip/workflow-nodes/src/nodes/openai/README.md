# Openai Node

## Runtime Ownership
Worker-first node. The UI/runtime enters through `worker.ts`, and backend execution is delegated through `[backend handler key]#executeOpenAINode`.

## Usage
Use Openai to process runtime input and emit output for downstream nodes.

## Inputs
- `Control Port: Command`: Bi-directional control-state input from connected command peers.
- `Input Port: Input`: Incoming data edge payload for this port.
- `Model`: Model runtime parameter.
- `Prompt`: Prompt runtime parameter.
- `Temperature`: Temperature runtime parameter.
- `Failure Mitigation`: Failure Mitigation value for this node.
- `Retry Count`: Retries value for this node.

## Outputs
- `Control Port: Command`: Publishes this node control state for connected command peers.
- `Output Port: Output`: Outgoing payload emitted after node execution.

## Backend Mapping
- Source: `/Users/abeer/dev/giga/giga-ai-backend/src/[backend handler key]`
- Handler: `executeOpenAINode`

## Failure Cases
- Runtime failures are surfaced as node errors.
