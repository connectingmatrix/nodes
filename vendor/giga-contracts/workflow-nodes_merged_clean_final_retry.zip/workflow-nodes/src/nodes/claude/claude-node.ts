import rawSchema from '@workflow/nodes/nodes/claude/claude-schema.json';
import { createServerOnlyNodeModule } from '@workflow/nodes/nodes/server-only/server-node.module.factory';

const renderIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <rect x="9" y="8" width="30" height="20" rx="4" stroke="currentColor" stroke-width="2.4"/>
  <path d="M15 32h18M20 38h8" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>
</svg>`;

const nodeModule = createServerOnlyNodeModule({
    id: 'claude',
    rawSchema,
    library: {
        id: 'claude-node',
        label: 'Claude',
        description: 'Execute Anthropic Claude model on server.',
        gigaId: 'ClaudeNode',
        modelId: 'claude',
        group: 'AI Models',
        order: 125,
        iconColor: '#7c2d12',
        iconBackground: '#ffedd5'
    },
    iconSvg: renderIcon
});

export default nodeModule;
