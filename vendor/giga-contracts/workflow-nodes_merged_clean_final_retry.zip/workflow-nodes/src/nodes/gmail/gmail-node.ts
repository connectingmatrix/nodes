import rawSchema from './gmail-schema.json';
import { createAgentBackendNodeModule } from '@workflow/nodes/nodes/_agent-backend-node-module';

export default createAgentBackendNodeModule({ id: 'gmail', rawSchema, label: 'Gmail', description: 'Use Gmail operations through centralized backend capabilities.', kind: 'chat', order: 510 });
