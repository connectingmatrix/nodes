import rawSchema from '@workflow/nodes/nodes/deepseek/deepseek-schema.json';
import { createServerOnlyNodeModule } from '@workflow/nodes/nodes/server-only/server-node.module.factory';

const renderIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <path d="M12 14h24M12 24h24M12 34h24" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>
  <circle cx="11" cy="14" r="2.2" fill="currentColor"/>
  <circle cx="11" cy="24" r="2.2" fill="currentColor"/>
  <circle cx="11" cy="34" r="2.2" fill="currentColor"/>
</svg>`;

const nodeModule = createServerOnlyNodeModule({
    id: 'deepseek',
    rawSchema,
    library: {
        id: 'deepseek-node',
        label: 'DeepSeek',
        description: 'Execute DeepSeek model on server.',
        gigaId: 'DeepSeekNode',
        modelId: 'deepseek',
        group: 'AI Models',
        order: 128,
        iconColor: '#0f172a',
        iconBackground: '#e2e8f0'
    },
    iconSvg: renderIcon
});

export default nodeModule;
