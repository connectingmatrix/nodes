# Software System Builder V2

Routes to `agent.software.create.v2` through `executeBackend`. The node never opens Supabase, Neo4j, local files, or network resources directly.
