export const software_system_builder_V2Node = {
  id: 'software-system-builder-v2',
  type: 'software-system-builder-v2',
  name: 'Software System Builder V2',
  version: '20.0.0',
  tool: 'agent.software.create.v2',
};
export default software_system_builder_V2Node;
