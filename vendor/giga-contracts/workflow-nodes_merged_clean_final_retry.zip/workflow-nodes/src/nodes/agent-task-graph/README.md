# Agent Task Graph

Routes to `agent.task_graph` through `executeBackend`. The node never opens Supabase, Neo4j, local files, or network resources directly.
