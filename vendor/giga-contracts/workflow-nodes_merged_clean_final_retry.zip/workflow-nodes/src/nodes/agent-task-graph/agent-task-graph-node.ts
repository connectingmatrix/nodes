export const agent_task_graphNode = {
  id: 'agent-task-graph',
  type: 'agent-task-graph',
  name: 'Agent Task Graph',
  version: '20.0.0',
  tool: 'agent.task_graph',
};
export default agent_task_graphNode;
