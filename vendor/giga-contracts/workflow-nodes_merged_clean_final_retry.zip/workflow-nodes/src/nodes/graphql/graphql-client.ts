import type { WorkflowNodeHandlerContext } from '@workflow/executor';
import { parseHeaderRecord, parseStringValue } from '@workflow/nodes/node-utils/node-runtime.utils';
import { WorkflowAuthModeEnum } from '@workflow/nodes/types';

const ACCESS_TOKEN_STORAGE_KEY = 'giga_access_token';
const REFRESH_TOKEN_STORAGE_KEY = 'giga_refresh_token';

const readStoredTokens = (): { accessToken?: string; refreshToken?: string } | undefined => {
    if (typeof window === 'undefined') return undefined;
    const accessToken = window.localStorage.getItem(ACCESS_TOKEN_STORAGE_KEY) ?? '';
    if (!accessToken) return undefined;
    return {
        accessToken,
        refreshToken: window.localStorage.getItem(REFRESH_TOKEN_STORAGE_KEY) ?? ''
    };
};

const authPairHeader = (tokens: { accessToken?: string; refreshToken?: string }): string => {
    return `Bearer access_token=${tokens.accessToken ?? ''};refresh_token=${tokens.refreshToken ?? ''}`;
};

const hasGraphqlErrors = (payload: unknown): boolean => {
    const errors = (payload as { errors?: unknown[] } | null)?.errors;
    return Array.isArray(errors) && errors.length > 0;
};

export const resolveAuthHeaders = (context: WorkflowNodeHandlerContext): Record<string, string> => {
    if (context.settings.authMode === WorkflowAuthModeEnum.None) return {};
    if (context.settings.authMode === WorkflowAuthModeEnum.Manual) return parseHeaderRecord(context.settings.manualHeaders);
    const tokens = readStoredTokens();
    if (!tokens?.accessToken) return {};
    return { Authorization: authPairHeader(tokens) };
};

export const runGraphqlRequest = async (context: WorkflowNodeHandlerContext, queryText: string, variables: Record<string, unknown>, nodeHeaders?: unknown): Promise<{ response: unknown; ok: boolean; status: number }> => {
    const graphqlUrl = parseStringValue(context.settings.graphqlUrl ?? '').trim();
    if (!graphqlUrl) throw new Error('GraphQL URL is missing in workflow settings.');

    const headers = {
        'Content-Type': 'application/json',
        ...resolveAuthHeaders(context),
        ...parseHeaderRecord(nodeHeaders)
    };

    const networkResponse = await fetch(graphqlUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify({ query: queryText, variables }),
        signal: context.signal
    });

    const response = await networkResponse.json().catch(() => ({}));
    return {
        response,
        status: networkResponse.status,
        ok: networkResponse.ok && !hasGraphqlErrors(response)
    };
};
