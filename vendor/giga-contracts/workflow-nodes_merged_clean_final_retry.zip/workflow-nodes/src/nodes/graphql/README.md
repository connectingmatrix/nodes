# GraphQL Node

## Runtime Ownership
Worker-first local node. No backend service is used.

## Usage
Execute GraphQL requests directly from the worker using workflow runtime settings, optional auth headers, and node-scoped request headers.

The package ships no product-specific query catalog. Hosts can provide query text through inspector/runtime properties.

## Inputs
- `queryKey`: Host-provided query catalog id used when the host injects matching query text.
- `queryText`: Manual GraphQL query text. When present, this overrides `queryKey`.
- `variables`: JSON variables object.
- `headers`: Optional per-node request headers.

## Outputs
- `output`: Query text, variables, raw response payload, status code, and request success flag.

## Backend Mapping
- No backend service is used.

## Failure Cases
- Fails when `queryText` is missing and `queryKey` cannot resolve a runtime query catalog entry.
- Fails when the configured GraphQL request returns network or GraphQL errors.
