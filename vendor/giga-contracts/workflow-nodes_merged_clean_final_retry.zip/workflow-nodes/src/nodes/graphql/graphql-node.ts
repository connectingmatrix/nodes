import rawSchema from '@workflow/nodes/nodes/graphql/graphql-schema.json';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';
import { WorkflowNodeKindEnum } from '@workflow/nodes/types';

const schema = parseNodeSchema(rawSchema, 'graphql');

const renderGraphqlIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <polygon points="24,5 37,12.5 37,35.5 24,43 11,35.5 11,12.5" stroke="currentColor" stroke-width="2.4"/>
  <circle cx="24" cy="5" r="3" fill="currentColor"/>
  <circle cx="37" cy="12.5" r="3" fill="currentColor"/>
  <circle cx="37" cy="35.5" r="3" fill="currentColor"/>
  <circle cx="24" cy="43" r="3" fill="currentColor"/>
  <circle cx="11" cy="35.5" r="3" fill="currentColor"/>
  <circle cx="11" cy="12.5" r="3" fill="currentColor"/>
  <circle cx="24" cy="24" r="4.5" fill="currentColor"/>
</svg>`;

const graphqlNodeModule: WorkflowNodeModule = {
    id: 'graphql',
    schema,
    library: {
        id: 'graphql-node',
        label: 'GraphQL',
        description: 'Execute GraphQL query with variables.',
        gigaId: 'GraphqlNode',
        modelId: 'graphql',
        group: 'Server Actions',
        nodeType: 'workflowStep',
        defaultKind: WorkflowNodeKindEnum.Process,
        iconColor: '#e535ab',
        iconBackground: '#fdf2f8',
        order: 40
    },
    renderIcon: renderGraphqlIcon,
    buildInitialNode: (context) =>
        buildInitialNodeFromSchema(context, {
            properties: {
                queryKey: '',
                queryText: ''
            }
        }),
    ui: {
        localCapable: true,
        serverOnly: false,
        inspector: {
            showGraphqlQuerySection: true
        }
    },
    execute: createNodeModuleWorkerExecute('graphql')
};

export default graphqlNodeModule;
