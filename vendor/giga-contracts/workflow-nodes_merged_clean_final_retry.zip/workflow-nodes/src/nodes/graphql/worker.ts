import type { WorkflowCommandToolSpec } from '@workflow/executor';
import type { WorkerExecuteResult, WorkerPayload, WorkerScope, WorkerUpdateResult, WorkerValidateResult } from '@workflow/executor';

const NODE_SCOPE: WorkerScope = {};
const ACCESS_TOKEN_STORAGE_KEY = 'giga_access_token';
const REFRESH_TOKEN_STORAGE_KEY = 'giga_refresh_token';

const recordValue = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});

const stringValue = (value: unknown): string => String(value ?? '').trim();

const nodeValue = (payload: WorkerPayload): Record<string, unknown> => recordValue((payload as { NODE?: unknown }).NODE || payload.self);

const errorResult = (message: string): WorkerExecuteResult => ({ output: { error: message }, status: 'failed', logs: [message] });

const parseHeaderRecord = (value: unknown): Record<string, string> =>
    Object.entries(recordValue(value)).reduce<Record<string, string>>((acc, [key, entry]) => {
        const normalizedKey = key.trim();
        const normalizedValue = stringValue(entry);
        if (!normalizedKey || !normalizedValue) return acc;
        acc[normalizedKey] = normalizedValue;
        return acc;
    }, {});

const readStoredTokens = (): { accessToken?: string; refreshToken?: string } => {
    const storage = typeof globalThis !== 'undefined' ? (globalThis as { localStorage?: Storage }).localStorage : undefined;
    if (!storage) return {};
    const accessToken = storage.getItem(ACCESS_TOKEN_STORAGE_KEY) ?? undefined;
    const refreshToken = storage.getItem(REFRESH_TOKEN_STORAGE_KEY) ?? undefined;
    return { accessToken, refreshToken };
};

const resolveAuthHeaders = (settings: Record<string, unknown>): Record<string, string> => {
    const authMode = stringValue(settings.authMode).toLowerCase();
    if (authMode === 'none') return {};
    if (authMode === 'manual') return parseHeaderRecord(settings.manualHeaders);
    const tokens = readStoredTokens();
    if (!tokens.accessToken) return {};
    return {
        Authorization: `Bearer access_token=${tokens.accessToken};refresh_token=${tokens.refreshToken ?? ''}`
    };
};

const hasGraphqlErrors = (payload: unknown): boolean => {
    const errors = (payload as { errors?: unknown[] } | null)?.errors;
    return Array.isArray(errors) && errors.length > 0;
};

const graphqlErrorMessages = (payload: unknown): string[] => {
    const errors = (payload as { errors?: Array<{ message?: unknown }> } | null)?.errors;
    if (!Array.isArray(errors)) return [];
    const messages: string[] = [];
    for (const entry of errors) {
        const message = stringValue(entry?.message || 'GraphQL error');
        if (message) messages.push(message);
    }
    return messages;
};

const queryTextFromRuntime = (runtime: Record<string, unknown>): { queryKey: string; queryText: string; source: string } => {
    const manualQuery = stringValue(runtime.queryText);
    const queryKey = stringValue(runtime.queryKey);
    if (manualQuery) return { queryKey, queryText: manualQuery, source: 'manual' };
    const runtimeCatalog = recordValue(runtime.queryCatalog);
    const runtimeQuery = stringValue(runtimeCatalog[queryKey]);
    if (runtimeQuery) return { queryKey, queryText: runtimeQuery, source: 'runtime-catalog' };
    return { queryKey, queryText: '', source: 'queryKey' };
};

const validateFailureMitigation = (runtime: Record<string, unknown>): WorkerValidateResult => {
    const errors: string[] = [];
    const warnings: string[] = [];
    const failureMitigation = stringValue(runtime.failureMitigation || 'stop-workflow');
    if (failureMitigation !== 'retry-node' && failureMitigation !== 'stop-workflow') {
        errors.push('Failure Mitigation must be either "retry-node" or "stop-workflow".');
    }
    if (failureMitigation === 'retry-node') {
        const retryCount = Number(runtime.retryCount);
        if (!Number.isFinite(retryCount) || retryCount < 1 || retryCount > 6) {
            errors.push('Retry Count must be between 1 and 6 when Failure Mitigation is "retry-node".');
        }
    }
    return { ok: errors.length === 0, errors, warnings, normalizedRuntime: runtime };
};

const getSettings = (payload: WorkerPayload): Record<string, unknown> => recordValue(recordValue(recordValue(payload.workflow?.metadata).runtime).settings);

const runGraphqlRequest = async (payload: WorkerPayload, queryText: string, variables: Record<string, unknown>, nodeHeaders?: unknown): Promise<{ response: unknown; ok: boolean; status: number }> => {
    const settings = getSettings(payload);
    const graphqlUrl = stringValue(settings.graphqlUrl);
    if (!graphqlUrl) {
        throw new Error('GraphQL URL is missing in workflow settings.');
    }

    const response = await fetch(graphqlUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            ...resolveAuthHeaders(settings),
            ...parseHeaderRecord(nodeHeaders)
        },
        body: JSON.stringify({ query: queryText, variables })
    });

    const payloadBody = await response.json().catch(() => ({}));
    return {
        response: payloadBody,
        status: response.status,
        ok: response.ok && !hasGraphqlErrors(payloadBody)
    };
};

export const validate = async (payload: WorkerPayload): Promise<WorkerValidateResult> => {
    const runtime = recordValue(nodeValue(payload).runtime);
    const result = validateFailureMitigation(runtime);
    const query = queryTextFromRuntime(runtime);
    if (!query.queryText) {
        return {
            ...result,
            ok: false,
            errors: [...result.errors, 'queryText is required or queryKey must resolve a runtime queryCatalog entry.']
        };
    }
    if (typeof runtime.variables !== 'undefined') {
        const variables = runtime.variables;
        if (!variables || typeof variables !== 'object' || Array.isArray(variables)) {
            return {
                ...result,
                ok: false,
                errors: [...result.errors, 'variables must be a JSON object.']
            };
        }
    }
    if (!stringValue(getSettings(payload).graphqlUrl)) {
        result.warnings = [...(result.warnings ?? []), 'GraphQL URL is empty in runtime settings.'];
    }
    return { ...result, normalizedRuntime: { ...runtime, queryText: query.queryText } };
};

export const init = async (payload: WorkerPayload): Promise<boolean> => {
    NODE_SCOPE.workflowId = String(payload.workflow?.metadata?.id ?? '');
    NODE_SCOPE.initialized = true;
    return true;
};

export const onUpdate = async (payload: WorkerPayload): Promise<WorkerUpdateResult> => {
    NODE_SCOPE.lastStatus = payload.self?.status ?? NODE_SCOPE.lastStatus;
    NODE_SCOPE.lastOutput = payload.self?.OUTPUT ?? NODE_SCOPE.lastOutput;
    return { ok: true, error: null };
};

export const executeLocal = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => {
    try {
        const runtime = recordValue(nodeValue(payload).runtime);
        const query = queryTextFromRuntime(runtime);
        const queryText = query.queryText;
        if (!queryText) {
            return errorResult('queryText is required or queryKey must resolve a runtime queryCatalog entry.');
        }
        const variables = recordValue(runtime.variables);
        const request = await runGraphqlRequest(payload, queryText, variables, runtime.headers);
        const errorLogs = request.ok ? [] : graphqlErrorMessages(request.response);

        return {
            output: {
                queryKey: query.queryKey,
                querySource: query.source,
                queryText,
                variables,
                response: request.response,
                statusCode: request.status,
                ok: request.ok
            },
            status: request.ok ? 'passed' : 'failed',
            logs: errorLogs
        };
    } catch (error) {
        return errorResult(error instanceof Error ? error.message : 'GraphQL node execution failed.');
    }
};

export const execute = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => executeLocal(payload);

// AI Agent command contract: keep this node usable as a declared tool without adding proxy wrappers.
type __GigaCommandRecord = Record<string, unknown>;
const __gigaCommandRecord = (value: unknown): __GigaCommandRecord =>
  value && typeof value === 'object' && !Array.isArray(value) ? (value as __GigaCommandRecord) : {};
const __gigaCommandText = (value: unknown): string => String(value ?? '').trim();
const __gigaCommandNode = (payload: WorkerPayload): __GigaCommandRecord =>
  __gigaCommandRecord((payload as { NODE?: unknown }).NODE || (payload as { self?: unknown }).self || payload);
const __gigaCommandRuntime = (payload: WorkerPayload): __GigaCommandRecord => {
  const node = __gigaCommandNode(payload);
  return { ...__gigaCommandRecord(node.runtime), ...__gigaCommandRecord(node.properties) };
};

export const commandToolSpec = async (payload: WorkerPayload): Promise<WorkflowCommandToolSpec> => {
  const node = __gigaCommandNode(payload);
  const runtime = __gigaCommandRuntime(payload);
  const modelId = __gigaCommandText(node.modelId || runtime.modelId || 'graphql');
  const configuredName = __gigaCommandText(node.name || runtime.name || runtime.title);
  const operation = __gigaCommandText(runtime.operation || runtime.action || runtime.mode || modelId || 'graphql');
  const haystack = `${configuredName} ${operation} ${modelId}`.toLowerCase();
  const mutating = runtime.mutating === true || /\b(create|update|delete|remove|link|unlink|attach|detach|publish|execute|run|write|save|train|install|ingest|fix|stop|wait)\b/.test(haystack);
  return {
    toolName: configuredName || 'GraphQL',
    toolDescription: __gigaCommandText(runtime.description || runtime.toolDescription) || 'Execute a GraphQL query/mutation through the configured workflow/backend boundary.',
    inputContract: {
      required: [],
      optional: [

        { key: 'message', label: 'Message', description: 'Natural-language instruction or task for this node.' },
        { key: 'input', label: 'Input', description: 'Structured JSON input for the node.' },
        { key: 'operation', label: 'Operation', description: 'Operation/action name, when the node supports multiple operations.' },
        { key: 'prompt', label: 'Prompt', description: 'Prompt text for LLM or transformation nodes.' },
        { key: 'data', label: 'Data', description: 'Data payload for processing.' },
      ],
    },
    outputContract: [
      { key: 'output', label: 'Output', description: 'Node output payload.' },
      { key: 'status', label: 'Status', description: 'Execution status.' },
      { key: 'logs', label: 'Logs', description: 'Execution logs, when available.' },
    ],
    metadata: {
      modelId,
      nodeId: __gigaCommandText(node.id || node.nodeId),
      operation,
      toolDomain: 'graphql',
      mutating,
      reusableByAiAgent: true,
    },
    executionKind: 'tool',
  };
};

