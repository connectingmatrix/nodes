import rawSchema from './email-schema.json';
import { createAgentBackendNodeModule } from '@workflow/nodes/nodes/_agent-backend-node-module';

export default createAgentBackendNodeModule({ id: 'email', rawSchema, label: 'Email', description: 'Use generic email operations through centralized backend capabilities.', kind: 'chat', order: 511 });
