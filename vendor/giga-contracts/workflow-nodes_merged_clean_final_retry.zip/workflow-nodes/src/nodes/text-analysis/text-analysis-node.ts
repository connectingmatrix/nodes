import rawSchema from '@workflow/nodes/nodes/text-analysis/text-analysis-schema.json';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';
import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { WorkflowNodeKindEnum } from '@workflow/nodes/types';

const schema = parseNodeSchema(rawSchema, 'text-analysis');

const icon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <circle cx="24" cy="24" r="15" stroke="currentColor" stroke-width="2.4"/>
  <path d="M24 15v9l6 6" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;

const textAnalysisNodeModule: WorkflowNodeModule = {
  id: 'text-analysis',
  schema,
  library: {
    id: 'giga-text-analysis',
    label: 'Text Analysis',
    description: 'Analyze text and workflow context into reusable intent flags.',
    gigaId: 'GigaTextAnalysisNode',
    modelId: 'text-analysis',
    group: 'Giga AI Nodes',
    nodeType: 'workflowStep',
    defaultKind: WorkflowNodeKindEnum.Process,
    iconColor: '#7c3aed',
    iconBackground: '#f5f3ff',
    order: 219
  },
  renderIcon: icon,
  buildInitialNode: (context) => buildInitialNodeFromSchema(context),
  ui: { localCapable: true, serverOnly: false },
  execute: createNodeModuleWorkerExecute('text-analysis')
};

export default textAnalysisNodeModule;
