import type { WorkflowCommandToolSpec } from '@workflow/executor';
import type { WorkerExecuteResult, WorkerPayload, WorkerScope, WorkerUpdateResult, WorkerValidateResult } from '@workflow/executor';

const NODE_SCOPE: WorkerScope = {};
const ALLOWED_KINDS = ['confirmation', 'mutation', 'workflow-request', 'workflow-followup', 'reference-sync', 'explanation'];
const recordValue = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});
const textValue = (value: unknown): string => String(value || '').trim();
const linesValue = (value: unknown): string[] => (Array.isArray(value) ? value : String(value || '').split(/\r?\n|,/)).map((entry) => textValue(entry)).filter(Boolean);
const nodeValue = (payload: WorkerPayload) => recordValue((payload as { NODE?: unknown }).NODE || payload.self);
const wants = (kinds: string[], key: string) => kinds.includes(key);
const summary = (flags: string[]) => (flags.length ? `Detected ${flags.join(', ')}.` : 'No selected text-analysis rules matched.');
const escapeRegex = (value: string) => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const phraseMatch = (message: string, phrases: string[]) => phrases.some((phrase) => RegExp(`\\b${escapeRegex(phrase)}\\b`, 'i').test(message));
const phraseText = (value: string): string => value.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
const exactPhraseMatch = (message: string, phrases: string[]) => {
    const normalized = phraseText(message);
    for (const phrase of phrases) {
        const current = phraseText(phrase);
        if (normalized === current || normalized === `please ${current}` || normalized === `${current} please`) return true;
    }
    return false;
};
const planHasActions = (value: unknown): boolean => Array.isArray(recordValue(value).actions) && (recordValue(value).actions as unknown[]).length > 0;
const pendingPlanReady = (input: { context: Record<string, unknown>; pendingPlan: Record<string, unknown> }): boolean => planHasActions(input.pendingPlan) || planHasActions(recordValue(recordValue(input.context).chat_agent_state).pendingPlan);
const regexMatch = (message: string, override: string, fallback: () => boolean) => {
    if (!override) return fallback();
    return RegExp(override, 'i').test(message);
};
const inputValue = (payload: WorkerPayload) => {
    const runtime = recordValue(nodeValue(payload).runtime);
    const message = textValue(runtime.message);
    return {
        context: recordValue(runtime.context),
        pendingPlan: recordValue(runtime.pendingPlan),
        message
    };
};
const defaultTerms = {
    confirmationPhrases: ['yes', 'y', 'confirm', 'confirmed', 'approve', 'approved', 'proceed', 'go ahead', 'do it', 'run it', 'execute', 'confirm all changes'],
    workflowEntityTerms: ['workflow'],
    workflowVerbTerms: ['create', 'build', 'make', 'update', 'write', 'edit', 'replace', 'run', 'execute', 'publish', 'delete', 'remove', 'read', 'list', 'get', 'attach', 'detach', 'cypher', 'code'],
    followupReferenceTerms: ['that workflow', 'recent workflow', 'the workflow you just ran', 'it'],
    followupVerbTerms: ['change', 'update', 'run', 'execute', 'edit'],
    mutationVerbs: ['create', 'add', 'update', 'edit', 'change', 'delete', 'remove', 'link', 'unlink', 'attach', 'detach', 'publish', 'save', 'write', 'execute', 'run', 'build', 'make'],
    mutationTargets: ['channel', 'category', 'subject', 'post', 'workflow', 'tree', 'reference', 'metadata', 'cypher'],
    referenceTerms: ['reference', 'references', 'links', 'source', 'sources', 'web', 'serp', 'sync'],
    referenceTargets: ['subject', 'metadata'],
    explanationTerms: ['explain', 'understand', 'clarify', 'what happened', 'why', 'help me understand']
};

export const validate = async (payload: WorkerPayload): Promise<WorkerValidateResult> => {
    const runtime = recordValue(nodeValue(payload).runtime);
    const kinds = linesValue(runtime.analysisKinds);
    const errors = kinds.length ? [] : ['Analysis Kinds is required.'];
    for (const kind of kinds) if (!ALLOWED_KINDS.includes(kind)) errors.push(`Unsupported analysis kind: ${kind}.`);
    for (const key of ['confirmationRegexOverride', 'workflowRequestRegexOverride', 'workflowFollowupRegexOverride', 'mutationRegexOverride', 'referenceRegexOverride', 'explanationRegexOverride']) {
        const value = textValue(runtime[key]);
        if (!value) continue;
        try {
            RegExp(value, 'i');
        } catch (error) {
            errors.push(`${key} is not a valid regex: ${error instanceof Error ? error.message : String(error)}`);
        }
    }
    return { ok: errors.length === 0, errors, warnings: [], normalizedRuntime: runtime };
};

export const init = async (payload: WorkerPayload) => ((NODE_SCOPE.workflowId = textValue(recordValue(payload.workflow?.metadata).id)), true);
export const onUpdate = async (payload: WorkerPayload): Promise<WorkerUpdateResult> => ((NODE_SCOPE.lastOutput = payload.self?.OUTPUT || NODE_SCOPE.lastOutput), { ok: true, error: null });

export const execute = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => {
    try {
        const runtime = recordValue(nodeValue(payload).runtime);
        const input = inputValue(payload);
        const kinds = linesValue(runtime.analysisKinds);
        const message = textValue(input.message);
        const lower = message.toLowerCase();
        const state = recordValue(recordValue(input.context).chat_agent_state);
        const workflowEntityTerms = linesValue(runtime.workflowEntityTerms || defaultTerms.workflowEntityTerms);
        const workflowVerbTerms = linesValue(runtime.workflowVerbTerms || defaultTerms.workflowVerbTerms);
        const followupReferenceTerms = linesValue(runtime.followupReferenceTerms || defaultTerms.followupReferenceTerms);
        const followupVerbTerms = linesValue(runtime.followupVerbTerms || defaultTerms.followupVerbTerms);
        const confirmationPhrases = linesValue(runtime.confirmationPhrases || defaultTerms.confirmationPhrases);
        const confirmation = regexMatch(message, textValue(runtime.confirmationRegexOverride), () => pendingPlanReady(input) ? phraseMatch(message, confirmationPhrases) : exactPhraseMatch(message, confirmationPhrases));
        const workflowRequest = regexMatch(message, textValue(runtime.workflowRequestRegexOverride), () => phraseMatch(lower, workflowEntityTerms) && phraseMatch(lower, workflowVerbTerms));
        const workflowFollowup = regexMatch(message, textValue(runtime.workflowFollowupRegexOverride), () => {
            const hasReference = phraseMatch(lower, followupReferenceTerms);
            const hasWorkflow = phraseMatch(lower, workflowEntityTerms);
            const requireLastWorkflowState = runtime.requireLastWorkflowState !== false;
            if (hasReference && (!requireLastWorkflowState || textValue(state.last_workflow_id))) return true;
            return hasWorkflow && phraseMatch(lower, followupVerbTerms);
        });
        const mutationIntent = regexMatch(message, textValue(runtime.mutationRegexOverride), () => phraseMatch(lower, linesValue(runtime.mutationVerbs || defaultTerms.mutationVerbs)) && phraseMatch(lower, linesValue(runtime.mutationTargets || defaultTerms.mutationTargets)));
        const referenceSync = regexMatch(message, textValue(runtime.referenceRegexOverride), () => phraseMatch(lower, linesValue(runtime.referenceTerms || defaultTerms.referenceTerms)) && phraseMatch(lower, linesValue(runtime.referenceTargets || defaultTerms.referenceTargets)));
        const explanationIntent = regexMatch(message, textValue(runtime.explanationRegexOverride), () => phraseMatch(lower, linesValue(runtime.explanationTerms || defaultTerms.explanationTerms)));
        const hits = [
            wants(kinds, 'confirmation') && confirmation ? 'confirmation' : '',
            wants(kinds, 'mutation') && mutationIntent ? 'mutation' : '',
            wants(kinds, 'workflow-request') && workflowRequest ? 'workflow request' : '',
            wants(kinds, 'workflow-followup') && workflowFollowup ? 'workflow followup' : '',
            wants(kinds, 'reference-sync') && referenceSync ? 'reference sync' : '',
            wants(kinds, 'explanation') && explanationIntent ? 'explanation' : ''
        ].filter(Boolean);
        const logs = [JSON.stringify({ text_analysis_debug: { message, analysisSummary: summary(hits), workflowRequest, confirmation, mutationIntent, referenceSync, explanationIntent } })];
        return {
            output: {
                ...input,
                confirmed: wants(kinds, 'confirmation') && confirmation,
                newMessage: !confirmation,
                mutationIntent: wants(kinds, 'mutation') && mutationIntent,
                workflowRequestIntent: wants(kinds, 'workflow-request') && workflowRequest,
                workflowFollowupIntent: wants(kinds, 'workflow-followup') && workflowFollowup,
                referenceSyncIntent: wants(kinds, 'reference-sync') && referenceSync,
                explanationIntent: wants(kinds, 'explanation') && explanationIntent,
                analysisSummary: summary(hits),
                __activeOutputs: ['output']
            },
            status: 'passed',
            logs
        };
    } catch (error) {
        const message = error instanceof Error ? error.message : 'Text Analysis failed.';
        return { output: { error: message }, status: 'failed', logs: [message] };
    }
};

// AI Agent command contract: keep this node usable as a declared tool without adding proxy wrappers.
type __GigaCommandRecord = Record<string, unknown>;
const __gigaCommandRecord = (value: unknown): __GigaCommandRecord =>
  value && typeof value === 'object' && !Array.isArray(value) ? (value as __GigaCommandRecord) : {};
const __gigaCommandText = (value: unknown): string => String(value ?? '').trim();
const __gigaCommandNode = (payload: WorkerPayload): __GigaCommandRecord =>
  __gigaCommandRecord((payload as { NODE?: unknown }).NODE || (payload as { self?: unknown }).self || payload);
const __gigaCommandRuntime = (payload: WorkerPayload): __GigaCommandRecord => {
  const node = __gigaCommandNode(payload);
  return { ...__gigaCommandRecord(node.runtime), ...__gigaCommandRecord(node.properties) };
};

export const commandToolSpec = async (payload: WorkerPayload): Promise<WorkflowCommandToolSpec> => {
  const node = __gigaCommandNode(payload);
  const runtime = __gigaCommandRuntime(payload);
  const modelId = __gigaCommandText(node.modelId || runtime.modelId || 'text-analysis');
  const configuredName = __gigaCommandText(node.name || runtime.name || runtime.title);
  const operation = __gigaCommandText(runtime.operation || runtime.action || runtime.mode || modelId || 'text-analysis');
  const haystack = `${configuredName} ${operation} ${modelId}`.toLowerCase();
  const mutating = runtime.mutating === true || /\b(create|update|delete|remove|link|unlink|attach|detach|publish|execute|run|write|save|train|install|ingest|fix|stop|wait)\b/.test(haystack);
  return {
    toolName: configuredName || 'Text Analysis',
    toolDescription: __gigaCommandText(runtime.description || runtime.toolDescription) || 'Analyze, extract, classify, or summarize text using configured rules.',
    inputContract: {
      required: [],
      optional: [

        { key: 'message', label: 'Message', description: 'Natural-language instruction or task for this node.' },
        { key: 'input', label: 'Input', description: 'Structured JSON input for the node.' },
        { key: 'operation', label: 'Operation', description: 'Operation/action name, when the node supports multiple operations.' },
        { key: 'prompt', label: 'Prompt', description: 'Prompt text for LLM or transformation nodes.' },
        { key: 'data', label: 'Data', description: 'Data payload for processing.' },
      ],
    },
    outputContract: [
      { key: 'output', label: 'Output', description: 'Node output payload.' },
      { key: 'status', label: 'Status', description: 'Execution status.' },
      { key: 'logs', label: 'Logs', description: 'Execution logs, when available.' },
    ],
    metadata: {
      modelId,
      nodeId: __gigaCommandText(node.id || node.nodeId),
      operation,
      toolDomain: 'text',
      mutating,
      reusableByAiAgent: true,
    },
    executionKind: 'tool',
  };
};

