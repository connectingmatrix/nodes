# Text Analysis

Worker-owned text intent analysis node.

No backend service is used.

- `analysisKinds`: enable only the rule families you need.
- Structured fields use newline or comma separated terms.
- Regex override fields replace the structured matcher for that rule.

Common outputs:

- `confirmed`
- `workflowRequestIntent`
- `workflowFollowupIntent`
- `mutationIntent`
- `referenceSyncIntent`
- `explanationIntent`
- `analysisSummary`
