# Chat

## Runtime Ownership
Server-only workflow node.

## Usage
Select one chat, retrieval, or analysis action and provide backend arguments in `parameters` rows.

## Inputs
- `action`: Chat/retrieval backend action.
- `chatId`: Runtime chat scope, with workflow metadata fallback.
- `parameters`: Add key/value rows for the selected backend action.

## Outputs
- `action`: Backend `AgentActionResult` wrapper.

## Backend Mapping
- `[backend handler key]`
- `executeGroupedActionNode`
