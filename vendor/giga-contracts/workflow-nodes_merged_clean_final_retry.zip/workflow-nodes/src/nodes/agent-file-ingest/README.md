# Agent File Ingest

Ingest files and attachments using size-aware backend rules.

This node is command-capable and routes backend operations through `executeBackend`. It does not access Supabase or Neo4j directly.
