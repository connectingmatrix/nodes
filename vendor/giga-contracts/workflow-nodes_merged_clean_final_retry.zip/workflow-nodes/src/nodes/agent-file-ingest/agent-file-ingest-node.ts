import rawSchema from './agent-file-ingest-schema.json';
import { createAgentBackendNodeModule } from '@workflow/nodes/nodes/_agent-backend-node-module';

export default createAgentBackendNodeModule({ id: 'agent-file-ingest', rawSchema, label: 'Agent File Ingest', description: 'Ingest files and attachments using size-aware backend rules.', kind: 'file', order: 516 });
