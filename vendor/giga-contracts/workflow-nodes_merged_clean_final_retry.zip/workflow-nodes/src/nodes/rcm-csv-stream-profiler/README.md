# RCM CSV Stream Profiler

Worker-owned backend tool node that profiles large RCM CSV files with bounded memory.

- Uses `executeBackend` function `executeRcmCsvStreamProfilerNode`.
- Configure `sourceFile` with a workflow variable or explicit file reference.
- Keep `phiSafe` enabled unless the workflow is running in a controlled PHI-safe context.
- Emits JSON aggregate profile data for downstream RCM pipeline nodes.

