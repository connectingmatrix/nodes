import { createBackendToolWorker } from '@workflow/nodes/nodes/server-only/backend-tool-worker';

const worker = createBackendToolWorker({
    functionName: 'executeRcmCsvStreamProfilerNode',
    description: 'Profiles a large RCM CSV using bounded streaming memory.',
    toolName: 'RCM CSV Stream Profiler'
});

export const validate = worker.validate;
export const init = worker.init;
export const onUpdate = worker.onUpdate;
export const commandToolSpec = worker.commandToolSpec;
export const execute = worker.execute;
