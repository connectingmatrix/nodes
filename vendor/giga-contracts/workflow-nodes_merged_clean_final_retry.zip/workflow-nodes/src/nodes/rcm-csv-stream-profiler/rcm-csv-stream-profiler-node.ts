import { createBackendToolNodeModule } from '@workflow/nodes/nodes/server-only/backend-tool-node.module';

export default createBackendToolNodeModule({
    id: 'rcm-csv-stream-profiler',
    label: 'RCM CSV Stream Profiler',
    description: 'Streams an RCM CSV and emits PHI-safe aggregate dataset profiles.',
    group: 'RCM Pipeline',
    order: 210,
    fields: {
        sourceFile: { type: 'string', editable: true, label: 'Source File', allowVariables: true },
        phiSafe: { type: 'boolean', editable: true, defaultValue: true, label: 'PHI Safe' }
    }
});
