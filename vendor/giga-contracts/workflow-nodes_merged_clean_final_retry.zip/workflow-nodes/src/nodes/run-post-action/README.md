# Post

## Runtime Ownership
Server-only workflow node.

## Usage
Select one post action and provide backend arguments in `parameters` rows.

## Inputs
- `action`: `read_post`, `read_attachments`, `create_post`, `update_post`, `delete_post`, or `link_post`.
- `chatId`: Runtime chat scope, with workflow metadata fallback.
- `parameters`: Add key/value rows for the selected backend action.

## Outputs
- `action`: Backend `AgentActionResult` wrapper.

## Backend Mapping
- `[backend handler key]`
- `executeGroupedActionNode`
