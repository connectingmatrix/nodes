import rawSchema from '@workflow/nodes/nodes/run-post-action/run-post-action-schema.json';
import { resolveGroupedActionInspectorFields, withGroupedActionSchemaOptions } from '@workflow/nodes/nodes/giga-ai/grouped-action-schema';
import { createServerOnlyNodeModule } from '@workflow/nodes/nodes/server-only/server-node.module.factory';

const renderIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <rect x="8" y="9" width="32" height="30" rx="6" stroke="currentColor" stroke-width="2.4"/>
  <path d="M15 18h18M15 25h12M15 32h15" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>
</svg>`;

const nodeModule = createServerOnlyNodeModule({
    id: 'run-post-action',
    rawSchema: withGroupedActionSchemaOptions(rawSchema, 'run-post-action'),
    library: {
        id: 'giga-action-post',
        label: 'Post',
        description: 'Run a post backend action.',
        gigaId: 'GigaActionPostNode',
        modelId: 'run-post-action',
        group: 'Giga Action Nodes',
        order: 223,
        iconColor: '#155e75',
        iconBackground: '#ecfeff'
    },
    iconSvg: renderIcon,
    resolveInspectorFields: ({ fields, node }) => resolveGroupedActionInspectorFields('run-post-action', fields, node)
});

export default nodeModule;
