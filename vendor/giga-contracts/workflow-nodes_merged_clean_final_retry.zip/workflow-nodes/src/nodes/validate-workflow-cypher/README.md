# Validate Workflow Cypher

Worker-owned node that compiles Workflow Cypher and returns validation output without creating or updating a workflow.

## Usage
Choose `Cypher Source`, then validate that source before workflow mutation actions.

## Inputs
- `cypherSource`: `input`, `property`, or `plan-action`.
- `workflowTitle`: Name used while compiling the workflow.
- `cypher`: Required only when `Cypher Source = Property`.

## Outputs
- `ok`
- `errors`
- `workflow`

## Backend Mapping
No backend service is used.
