import rawSchema from '@workflow/nodes/nodes/validate-workflow-cypher/validate-workflow-cypher-schema.json';
import { createServerOnlyNodeModule } from '@workflow/nodes/nodes/server-only/server-node.module.factory';

const icon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <rect x="8" y="8" width="32" height="32" rx="7" stroke="currentColor" stroke-width="2.4"/>
  <path d="M16 25l6 6 11-14" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;

export default createServerOnlyNodeModule({
    id: 'validate-workflow-cypher',
    rawSchema,
    library: {
        id: 'giga-validate-workflow-cypher',
        label: 'Validate Workflow Cypher',
        description: 'Validate Workflow Cypher from an explicit source.',
        gigaId: 'GigaValidateWorkflowCypherNode',
        modelId: 'validate-workflow-cypher',
        group: 'Giga AI Nodes',
        order: 229,
        iconColor: '#166534',
        iconBackground: '#f0fdf4'
    },
    iconSvg: icon
});
