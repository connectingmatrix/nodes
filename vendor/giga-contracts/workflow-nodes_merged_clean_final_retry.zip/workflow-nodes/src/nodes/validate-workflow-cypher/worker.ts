import type { WorkflowCommandToolSpec } from '@workflow/executor';
import type { WorkerExecuteResult, WorkerPayload, WorkerScope, WorkerUpdateResult, WorkerValidateResult } from '@workflow/executor';
import { compileWorkflowCypher } from '@workflow/execute';

const NODE_SCOPE: WorkerScope = {};
const recordValue = (value: unknown): Record<string, any> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, any>) : {});
const textValue = (value: unknown): string => String(value || '').trim();
const nodeValue = (payload: WorkerPayload) => recordValue((payload as { NODE?: unknown }).NODE || payload.self);
const fail = (message: string): WorkerExecuteResult => ({ output: { ok: false, errors: [message], warnings: [], cypher: '', __activeOutputs: ['output'] }, status: 'passed', logs: [message] });
const skip = (message: string): WorkerExecuteResult => ({ output: { ok: true, skipped: true, errors: [], warnings: [], cypher: '', workflow: null, validation: null, __activeOutputs: ['output'] }, status: 'passed', logs: [message] });
const firstRecord = (value: unknown, match: (record: Record<string, any>) => boolean, seen = new WeakSet<object>()): Record<string, any> => {
    const record = recordValue(value);
    if (!Object.keys(record).length) return {};
    if (match(record)) return record;
    const source = value && typeof value === 'object' ? (value as object) : null;
    if (!source || seen.has(source)) return {};
    seen.add(source);
    for (const entry of Object.values(record)) {
        const nested = firstRecord(entry, match, seen);
        if (Object.keys(nested).length) return nested;
    }
    return {};
};
const normalizeCypher = (value: unknown): string => textValue(value).replace(/^CREATE\s+/i, '').replace(/\s+RETURN\s+[\s\S]*$/i, '').replace(/\s+CREATE\s+/gi, '\n').replace(/\),\s+\(/g, ')\n(').replace(/([A-Za-z_][\w-]*)-\[:(?:CONNECT|NEXT)\]->([A-Za-z_][\w-]*)/g, '($1)-[:CONNECT {"source":"out:output","target":"in:input"}]->($2)').replace(/\(([A-Za-z_][\w-]*)\)-\[:(?:CONNECT|NEXT)\]->\(([A-Za-z_][\w-]*)\)/g, '($1)-[:CONNECT {"source":"out:output","target":"in:input"}]->($2)');
const planCypher = (value: unknown) => {
    const source = firstRecord(value, (record) => Array.isArray(record.actions) || Array.isArray(recordValue(record.plan).actions));
    const plan = Array.isArray(source.actions) ? source : recordValue(source.plan);
    for (const entry of Array.isArray(plan.actions) ? plan.actions : []) {
        const action = recordValue(entry);
        const input = recordValue(action.input);
        const actionInput = recordValue(action.actionInput || input.actionInput || (input.action ? {} : input));
        const cypher = normalizeCypher(actionInput.cypher || input.cypher);
        if (cypher) return cypher;
    }
    return '';
};
const inputCypher = (value: unknown) => normalizeCypher(firstRecord(value, (record) => Boolean(textValue(record.cypher))).cypher);

export const validate = async (payload: WorkerPayload): Promise<WorkerValidateResult> => {
    const runtime = recordValue(nodeValue(payload).runtime);
    const failure = textValue(runtime.failureMitigation || 'stop-workflow');
    const errors = failure === 'retry-node' || failure === 'stop-workflow' ? [] : ['Failure Mitigation must be either "retry-node" or "stop-workflow".'];
    const emptySourceBehavior = textValue(runtime.emptySourceBehavior || 'fail') || 'fail';
    if (emptySourceBehavior !== 'fail' && emptySourceBehavior !== 'skip') errors.push('Empty Source Behavior must be fail or skip.');
    return { ok: errors.length === 0, errors, warnings: [], normalizedRuntime: runtime };
};
export const init = async (payload: WorkerPayload) => ((NODE_SCOPE.workflowId = textValue(recordValue(payload.workflow?.metadata).id)), (NODE_SCOPE.initialized = true), true);
export const onUpdate = async (payload: WorkerPayload): Promise<WorkerUpdateResult> => ((NODE_SCOPE.lastStatus = payload.self?.status || NODE_SCOPE.lastStatus), (NODE_SCOPE.lastOutput = payload.self?.OUTPUT || NODE_SCOPE.lastOutput), { ok: true, error: null });

export const execute = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => {
    try {
        const runtime = recordValue(nodeValue(payload).runtime);
        const input = recordValue(runtime.sourceValue);
        const cypherSource = textValue(runtime.cypherSource || 'input') || 'input';
        const emptySourceBehavior = textValue(runtime.emptySourceBehavior || 'fail') || 'fail';
        const cypher = cypherSource === 'property' ? normalizeCypher(runtime.cypher) : cypherSource === 'plan-action' ? planCypher(input) : inputCypher(input);
        if (!cypher) return emptySourceBehavior === 'skip' ? skip(`Cypher Source "${cypherSource}" did not provide Workflow Cypher.`) : fail(`Cypher Source "${cypherSource}" did not provide Workflow Cypher.`);
        const metadata = recordValue(payload.workflow?.metadata);
        const compiled = await compileWorkflowCypher({
            cypher,
            name: textValue(runtime.workflowTitle || runtime.name || 'Workflow'),
            description: textValue(runtime.description),
            executable: runtime.executable !== false,
            metadata: { chat_id: textValue(metadata.chatId || metadata.chat_id), message: textValue(metadata.message) },
        });
        const validation = recordValue(compiled.validation);
        return { output: { ok: validation.ok === true, errors: Array.isArray(validation.errors) ? validation.errors : [], warnings: Array.isArray(validation.warnings) ? validation.warnings : [], workflow: compiled.workflow || null, validation: compiled.validation, cypher, __activeOutputs: ['output'] }, status: 'passed', logs: [validation.ok === true ? 'Workflow Cypher is valid.' : 'Workflow Cypher has validation errors.'] };
    } catch (error) {
        return fail(error instanceof Error ? error.message : 'Validate Workflow Cypher node execution failed.');
    }
};

// AI Agent command contract: keep this node usable as a declared tool without adding proxy wrappers.
type __GigaCommandRecord = Record<string, unknown>;
const __gigaCommandRecord = (value: unknown): __GigaCommandRecord =>
  value && typeof value === 'object' && !Array.isArray(value) ? (value as __GigaCommandRecord) : {};
const __gigaCommandText = (value: unknown): string => String(value ?? '').trim();
const __gigaCommandNode = (payload: WorkerPayload): __GigaCommandRecord =>
  __gigaCommandRecord((payload as { NODE?: unknown }).NODE || (payload as { self?: unknown }).self || payload);
const __gigaCommandRuntime = (payload: WorkerPayload): __GigaCommandRecord => {
  const node = __gigaCommandNode(payload);
  return { ...__gigaCommandRecord(node.runtime), ...__gigaCommandRecord(node.properties) };
};

export const commandToolSpec = async (payload: WorkerPayload): Promise<WorkflowCommandToolSpec> => {
  const node = __gigaCommandNode(payload);
  const runtime = __gigaCommandRuntime(payload);
  const modelId = __gigaCommandText(node.modelId || runtime.modelId || 'validate-workflow-cypher');
  const configuredName = __gigaCommandText(node.name || runtime.name || runtime.title);
  const operation = __gigaCommandText(runtime.operation || runtime.action || runtime.mode || modelId || 'validate-workflow-cypher');
  const haystack = `${configuredName} ${operation} ${modelId}`.toLowerCase();
  const mutating = runtime.mutating === true || /\b(create|update|delete|remove|link|unlink|attach|detach|publish|execute|run|write|save|train|install|ingest|fix|stop|wait)\b/.test(haystack);
  return {
    toolName: configuredName || 'Validate Workflow Cypher',
    toolDescription: __gigaCommandText(runtime.description || runtime.toolDescription) || 'Validate workflow graph/cypher structures before execution or saving.',
    inputContract: {
      required: [],
      optional: [

        { key: 'message', label: 'Message', description: 'Natural-language instruction or task for this node.' },
        { key: 'input', label: 'Input', description: 'Structured JSON input for the node.' },
        { key: 'operation', label: 'Operation', description: 'Operation/action name, when the node supports multiple operations.' },
        { key: 'prompt', label: 'Prompt', description: 'Prompt text for LLM or transformation nodes.' },
        { key: 'data', label: 'Data', description: 'Data payload for processing.' },
      ],
    },
    outputContract: [
      { key: 'output', label: 'Output', description: 'Node output payload.' },
      { key: 'status', label: 'Status', description: 'Execution status.' },
      { key: 'logs', label: 'Logs', description: 'Execution logs, when available.' },
    ],
    metadata: {
      modelId,
      nodeId: __gigaCommandText(node.id || node.nodeId),
      operation,
      toolDomain: 'workflow',
      mutating,
      reusableByAiAgent: true,
    },
    executionKind: 'tool',
  };
};

