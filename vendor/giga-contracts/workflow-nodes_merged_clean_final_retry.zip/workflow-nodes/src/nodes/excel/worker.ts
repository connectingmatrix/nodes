import type { WorkflowCommandToolSpec } from '@workflow/executor';
import type { WorkerExecuteResult, WorkerPayload, WorkerScope, WorkerUpdateResult, WorkerValidateResult } from '@workflow/executor';
import { toErrorResult, toNode } from '@workflow/executor';

const NODE_SCOPE: WorkerScope = {};

const toRecordValue = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});

const toStringValue = (value: unknown): string => String(value ?? '').trim();

const decodeBase64Text = (value: string): string => {
    if (typeof atob === 'function') {
        return atob(value);
    }
    const bufferCtor = (globalThis as { Buffer?: { from: (value: string, encoding: string) => { toString: (encoding: string) => string } } }).Buffer;
    if (bufferCtor) {
        return bufferCtor.from(value, 'base64').toString('utf8');
    }
    return '';
};

const parseCsvRow = (line: string): string[] => {
    const values: string[] = [];
    let current = '';
    let inQuotes = false;

    for (let index = 0; index < line.length; index += 1) {
        const character = line[index];
        const nextCharacter = line[index + 1];
        if (character === '"') {
            if (inQuotes && nextCharacter === '"') {
                current += '"';
                index += 1;
            } else {
                inQuotes = !inQuotes;
            }
            continue;
        }
        if (character === ',' && !inQuotes) {
            values.push(current);
            current = '';
            continue;
        }
        current += character;
    }

    values.push(current);
    return values.map((entry) => entry.trim());
};

const parseCsvText = (csvText: string): { columns: string[]; rows: Record<string, unknown>[] } => {
    const lines = csvText
        .replace(/\r\n/g, '\n')
        .replace(/\r/g, '\n')
        .split('\n')
        .map((line) => line.trim())
        .filter((line) => line.length > 0);

    if (lines.length === 0) {
        return { columns: [], rows: [] };
    }

    const [headerLine, ...bodyLines] = lines;
    const columns = parseCsvRow(headerLine).map((column, index) => column || `col_${index + 1}`);
    const rows = bodyLines.map((line) => {
        const values = parseCsvRow(line);
        return columns.reduce<Record<string, unknown>>((acc, column, index) => {
            acc[column] = values[index] ?? '';
            return acc;
        }, {});
    });

    return { columns, rows };
};

const validateFailureMitigation = (runtime: Record<string, unknown>): WorkerValidateResult => {
    const errors: string[] = [];
    const warnings: string[] = [];
    const failureMitigation = toStringValue(runtime.failureMitigation || 'stop-workflow');
    if (failureMitigation !== 'retry-node' && failureMitigation !== 'stop-workflow') {
        errors.push('Failure Mitigation must be either "retry-node" or "stop-workflow".');
    }
    if (failureMitigation === 'retry-node') {
        const retryCount = Number(runtime.retryCount);
        if (!Number.isFinite(retryCount) || retryCount < 1 || retryCount > 6) {
            errors.push('Retry Count must be between 1 and 6 when Failure Mitigation is "retry-node".');
        }
    }
    const files = Array.isArray(runtime.files) ? runtime.files : [];
    if (files.length === 0) {
        warnings.push('No file is attached. Excel node will emit warning output.');
    }
    return { ok: errors.length === 0, errors, warnings, normalizedRuntime: runtime };
};

export const validate = async (payload: WorkerPayload): Promise<WorkerValidateResult> => validateFailureMitigation(toRecordValue(toNode(payload).runtime));

export const init = async (payload: WorkerPayload): Promise<boolean> => {
    NODE_SCOPE.workflowId = String(payload.workflow?.metadata?.id ?? '');
    NODE_SCOPE.initialized = true;
    return true;
};

export const onUpdate = async (payload: WorkerPayload): Promise<WorkerUpdateResult> => {
    NODE_SCOPE.lastStatus = payload.self?.status ?? NODE_SCOPE.lastStatus;
    NODE_SCOPE.lastOutput = payload.self?.OUTPUT ?? NODE_SCOPE.lastOutput;
    return { ok: true, error: null };
};

export const executeLocal = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => {
    try {
        const runtime = toRecordValue(toNode(payload).runtime);
        const files = Array.isArray(runtime.files) ? runtime.files : [];
        const first = toRecordValue(files[0]);
        if (Object.keys(first).length === 0) {
            return {
                output: { rows: [], columns: [] },
                status: 'warning',
                logs: ['No file was attached to the Excel node.']
            };
        }

        const fileName = toStringValue(first.name);
        const lowerName = fileName.toLowerCase();
        const mimeType = toStringValue(first.mimeType);
        const isCsvLike = lowerName.endsWith('.csv') || mimeType === 'text/csv';
        if (!isCsvLike) {
            return {
                output: {
                    rows: [],
                    columns: [],
                    error: 'Only CSV parsing is supported by worker-first Excel node in the current version.'
                },
                status: 'warning',
                logs: ['Only CSV parsing is supported by worker-first Excel node in the current version.']
            };
        }

        const csvText = toStringValue(first.extractedText) || decodeBase64Text(toStringValue(first.contentBase64));
        const parsed = parseCsvText(csvText);
        return {
            output: {
                fileName,
                sheetName: 'Sheet1',
                columns: parsed.columns,
                rows: parsed.rows,
                rowCount: parsed.rows.length
            },
            status: 'passed'
        };
    } catch (error) {
        const message = error instanceof Error ? error.message : 'Unable to parse attached file.';
        return {
            output: {
                rows: [],
                columns: [],
                error: message
            },
            status: 'warning',
            logs: [message]
        };
    }
};

export const execute = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => executeLocal(payload);

// AI Agent command contract: keep this node usable as a declared tool without adding proxy wrappers.
type __GigaCommandRecord = Record<string, unknown>;
const __gigaCommandRecord = (value: unknown): __GigaCommandRecord =>
  value && typeof value === 'object' && !Array.isArray(value) ? (value as __GigaCommandRecord) : {};
const __gigaCommandText = (value: unknown): string => String(value ?? '').trim();
const __gigaCommandNode = (payload: WorkerPayload): __GigaCommandRecord =>
  __gigaCommandRecord((payload as { NODE?: unknown }).NODE || (payload as { self?: unknown }).self || payload);
const __gigaCommandRuntime = (payload: WorkerPayload): __GigaCommandRecord => {
  const node = __gigaCommandNode(payload);
  return { ...__gigaCommandRecord(node.runtime), ...__gigaCommandRecord(node.properties) };
};

export const commandToolSpec = async (payload: WorkerPayload): Promise<WorkflowCommandToolSpec> => {
  const node = __gigaCommandNode(payload);
  const runtime = __gigaCommandRuntime(payload);
  const modelId = __gigaCommandText(node.modelId || runtime.modelId || 'excel');
  const configuredName = __gigaCommandText(node.name || runtime.name || runtime.title);
  const operation = __gigaCommandText(runtime.operation || runtime.action || runtime.mode || modelId || 'excel');
  const haystack = `${configuredName} ${operation} ${modelId}`.toLowerCase();
  const mutating = runtime.mutating === true || /\b(create|update|delete|remove|link|unlink|attach|detach|publish|execute|run|write|save|train|install|ingest|fix|stop|wait)\b/.test(haystack);
  return {
    toolName: configuredName || 'Excel',
    toolDescription: __gigaCommandText(runtime.description || runtime.toolDescription) || 'Parse, inspect, create, or transform spreadsheet-like tables, CSV rows, and workbook data.',
    inputContract: {
      required: [],
      optional: [

        { key: 'message', label: 'Message', description: 'Natural-language instruction or task for this node.' },
        { key: 'input', label: 'Input', description: 'Structured JSON input for the node.' },
        { key: 'operation', label: 'Operation', description: 'Operation/action name, when the node supports multiple operations.' },
        { key: 'prompt', label: 'Prompt', description: 'Prompt text for LLM or transformation nodes.' },
        { key: 'data', label: 'Data', description: 'Data payload for processing.' },
      ],
    },
    outputContract: [
      { key: 'output', label: 'Output', description: 'Node output payload.' },
      { key: 'status', label: 'Status', description: 'Execution status.' },
      { key: 'logs', label: 'Logs', description: 'Execution logs, when available.' },
    ],
    metadata: {
      modelId,
      nodeId: __gigaCommandText(node.id || node.nodeId),
      operation,
      toolDomain: 'excel',
      mutating,
      reusableByAiAgent: true,
    },
    executionKind: 'tool',
  };
};

