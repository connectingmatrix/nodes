import rawSchema from '@workflow/nodes/nodes/excel/excel-schema.json';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { WorkflowNodeKindEnum } from '@workflow/nodes/types';
import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';

const schema = parseNodeSchema(rawSchema, 'excel');

const renderExcelIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <rect x="8" y="6" width="32" height="36" rx="4" stroke="currentColor" stroke-width="2.4"/>
  <path d="M18 6v36M8 16h32M8 26h32M8 36h32" stroke="currentColor" stroke-width="1.8"/>
  <path d="M12.5 11.5l4 6l-4 6M19 11.5l-4 6l4 6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>
</svg>`;

const excelNodeModule: WorkflowNodeModule = {
    id: 'excel',
    schema,
    library: {
        id: 'excel-node',
        label: 'Excel',
        description: 'CSV/Excel parser node with table output.',
        gigaId: 'ExcelNode',
        modelId: 'excel',
        group: 'Data',
        nodeType: 'workflowStep',
        defaultKind: WorkflowNodeKindEnum.Process,
        iconColor: '#15803d',
        iconBackground: '#ecfdf3',
        order: 90
    },
    renderIcon: renderExcelIcon,
    buildInitialNode: (context) => buildInitialNodeFromSchema(context),
    ui: {
        localCapable: true,
        serverOnly: false
    },
    execute: createNodeModuleWorkerExecute('excel')
};

export default excelNodeModule;
