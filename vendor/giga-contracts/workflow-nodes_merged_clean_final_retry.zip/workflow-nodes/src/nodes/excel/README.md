# Excel Node

## Runtime Ownership
Worker-first local node. No backend service is used.

## Usage
Parse attached CSV files directly in the worker to emit columns, rows, and row counts for downstream formatting or transformation.

## Inputs
- `files`: Attached CSV file envelopes.

## Outputs
- `output`: `fileName`, `sheetName`, `columns`, `rows`, and `rowCount`.

## Backend Mapping
- No backend service is used.

## Failure Cases
- Emits a warning when no file is attached.
- Emits a warning when the attached file is not CSV.
