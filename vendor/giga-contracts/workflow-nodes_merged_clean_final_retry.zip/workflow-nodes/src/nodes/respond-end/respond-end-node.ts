import rawSchema from '@workflow/nodes/nodes/respond-end/respond-end-schema.json';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';
import { WorkflowNodeKindEnum } from '@workflow/nodes/types';

const schema = parseNodeSchema(rawSchema, 'respond-end');

const renderRespondEndIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <path d="M12 8v32" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/>
  <path d="M12 10h21l-3.5 6L33 22H12z" fill="currentColor"/>
</svg>`;

const respondEndNodeModule: WorkflowNodeModule = {
    id: 'respond-end',
    schema,
    library: {
        id: 'respond-end-node',
        label: 'Respond / End',
        description: 'Collect workflow outputs and finish execution.',
        gigaId: 'RespondEndNode',
        modelId: 'respond-end',
        group: 'Flow Nodes',
        nodeType: 'workflowStep',
        defaultKind: WorkflowNodeKindEnum.Output,
        iconColor: '#065f46',
        iconBackground: '#ecfdf5',
        order: 95
    },
    renderIcon: renderRespondEndIcon,
    buildInitialNode: (context) => buildInitialNodeFromSchema(context),
    ui: {
        localCapable: true,
        serverOnly: false
    },
    execute: createNodeModuleWorkerExecute('respond-end')
};

export default respondEndNodeModule;
