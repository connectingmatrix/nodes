# Respond End Node

## Runtime Ownership
Worker-first local node. No backend service is used.

## Usage
Place Respond / End at the end of a workflow and bind the final `response` value through the inspector. The node emits that payload unchanged.

## Inputs
- `response`: Variable-bound terminal payload.

## Outputs
- `output`: Final response payload without workflow/node wrapper metadata.

## Backend Mapping
- No backend service is used.

## Failure Cases
- This node is deterministic and only fails if worker execution itself is unavailable.
