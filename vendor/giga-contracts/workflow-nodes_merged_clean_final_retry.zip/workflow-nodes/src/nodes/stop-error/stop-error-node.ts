import rawSchema from '@workflow/nodes/nodes/stop-error/stop-error-schema.json';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { WorkflowNodeKindEnum } from '@workflow/nodes/types';
import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';

const schema = parseNodeSchema(rawSchema, 'stop-error');

const renderStopErrorIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <circle cx="24" cy="24" r="17" stroke="currentColor" stroke-width="2.4"/>
  <rect x="18" y="18" width="12" height="12" fill="currentColor" rx="2"/>
</svg>`;

const stopErrorNodeModule: WorkflowNodeModule = {
    id: 'stop-error',
    schema,
    library: {
        id: 'stop-error-node',
        label: 'Stop & Error',
        description: 'Explicit stop/error control node.',
        gigaId: 'StopErrorNode',
        modelId: 'stop-error',
        group: 'Flow Nodes',
        nodeType: 'workflowStep',
        defaultKind: WorkflowNodeKindEnum.Error,
        iconColor: '#b91c1c',
        iconBackground: '#fef2f2',
        order: 100
    },
    renderIcon: renderStopErrorIcon,
    buildInitialNode: (context) => buildInitialNodeFromSchema(context),
    ui: {
        localCapable: true,
        serverOnly: false
    },
    execute: createNodeModuleWorkerExecute('stop-error')
};

export default stopErrorNodeModule;
