# Stop Error Node

## Runtime Ownership
Worker-first local node. No backend service is used.

## Usage
Use Stop & Error to explicitly stop the workflow or fail it with a deterministic worker-owned error output.

## Inputs
- `mode`: `stop` or `error`.

## Outputs
- `output`: `{ stopped: true }` for stop mode or `{ error: ... }` for error mode.

## Backend Mapping
- No backend service is used.

## Failure Cases
- Emits a failed status when mode is `error`.
