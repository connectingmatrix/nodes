import { groupedActionOptions, groupedActionParameterOptions, groupedActionParameterOptionsByAction } from '@workflow/nodes/nodes/giga-ai/grouped-action-catalog';
import { WorkflowNodeFieldMap, WorkflowNodeModel } from '@workflow/nodes/types';

const clone = <T>(value: T): T => JSON.parse(JSON.stringify(value)) as T;
const record = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});
const text = (value: unknown): string => String(value || '').trim();
const list = (value: unknown): string[] => (Array.isArray(value) ? value.map(text).filter(Boolean) : []);
const runtime = (node: WorkflowNodeModel): Record<string, unknown> => record(node.runtime || node.properties);
const fieldClone = (fields: WorkflowNodeFieldMap): WorkflowNodeFieldMap => clone(fields);
const parameterOptions = (modelId: string, action: string) => groupedActionParameterOptionsByAction(modelId)[action] || [];
const setParameterOptions = (fields: WorkflowNodeFieldMap, options: ReturnType<typeof groupedActionParameterOptions>, hideWhenEmpty: boolean) => {
    const parameters = { ...record(fields.parameters) };
    const key = { ...record(record(parameters.subFields).key), options };
    parameters.subFields = { ...record(parameters.subFields), key };
    parameters.hidden = hideWhenEmpty && options.length === 0;
    fields.parameters = parameters;
};

export const withGroupedActionSchemaOptions = (rawSchema: unknown, modelId: string): unknown => {
    const schema = clone(rawSchema);
    const fields = record(record(schema).fields);
    const action = record(fields.action);
    const parameters = record(fields.parameters);
    const key = record(record(parameters.subFields).key);
    action.options = groupedActionOptions(modelId);
    key.options = groupedActionParameterOptions(modelId);
    parameters.subFields = { ...record(parameters.subFields), key };
    fields.action = action;
    fields.parameters = parameters;
    record(schema).fields = fields;
    return schema;
};

export const withActionRouterSchemaOptions = (rawSchema: unknown): unknown => {
    const schema = clone(rawSchema);
    const fields = record(record(schema).fields);
    const action = record(fields.action);
    const allowedActions = record(fields.allowedActions);
    const parameters = record(fields.parameters);
    const key = record(record(parameters.subFields).key);
    const actionOptions = groupedActionOptions(record(fields.broadcastModelId).defaultValue as string);
    action.options = actionOptions;
    allowedActions.options = [
        ...groupedActionOptions('run-channel-action'),
        ...groupedActionOptions('run-category-action'),
        ...groupedActionOptions('run-subject-action'),
        ...groupedActionOptions('run-post-action'),
        ...groupedActionOptions('run-user-tree-action'),
        ...groupedActionOptions('run-chat-action')
    ];
    key.options = [
        ...groupedActionParameterOptions('run-channel-action'),
        ...groupedActionParameterOptions('run-category-action'),
        ...groupedActionParameterOptions('run-subject-action'),
        ...groupedActionParameterOptions('run-post-action'),
        ...groupedActionParameterOptions('run-user-tree-action'),
        ...groupedActionParameterOptions('run-chat-action')
    ];
    parameters.subFields = { ...record(parameters.subFields), key };
    action.metadata = { parameterOptionsByAction: groupedActionParameterOptionsByAction(record(fields.broadcastModelId).defaultValue as string) };
    fields.action = action;
    fields.allowedActions = allowedActions;
    fields.parameters = parameters;
    record(schema).fields = fields;
    return schema;
};

export const resolveGroupedActionInspectorFields = (modelId: string, fields: WorkflowNodeFieldMap, node: WorkflowNodeModel): WorkflowNodeFieldMap => {
    const next = fieldClone(fields);
    const selectedAction = text(runtime(node).action);
    setParameterOptions(next, parameterOptions(modelId, selectedAction), true);
    return next;
};

export const resolveActionRouterInspectorFields = (fields: WorkflowNodeFieldMap, node: WorkflowNodeModel): WorkflowNodeFieldMap => {
    const next = fieldClone(fields);
    const nodeRuntime = runtime(node);
    const modelId = text(nodeRuntime.broadcastModelId) || text(record(fields.broadcastModelId).defaultValue) || 'run-channel-action';
    const availableActions = groupedActionOptions(modelId);
    const allowed = list(nodeRuntime.allowedActions);
    const actionOptions = allowed.length ? availableActions.filter((option) => allowed.includes(option.value)) : availableActions;
    const selectedAction = text(nodeRuntime.action);
    next.allowedActions = { ...next.allowedActions, options: availableActions };
    next.action = { ...next.action, options: actionOptions, metadata: { parameterOptionsByAction: groupedActionParameterOptionsByAction(modelId) } };
    setParameterOptions(next, selectedAction ? parameterOptions(modelId, selectedAction) : [], true);
    return next;
};
