const catalog = {
    'run-channel-action': {
        label: 'Channel',
        actions: {
            read_channel: ['id', 'name', 'name_prefix', 'organization_id'],
            create_channel: ['channel.id', 'channel.name', 'channel.slug', 'channel.description', 'parent_channel_id', 'categories'],
            update_channel: ['id', 'name', 'slug', 'description', 'image'],
            delete_channel: ['id', 'name', 'name_prefix'],
            link_channel: ['parent_channel_id', 'channel_id'],
            unlink_channel: ['parent_channel_id', 'channel_id']
        }
    },
    'run-category-action': {
        label: 'Category',
        actions: {
            read_category: ['id', 'organization_id'],
            create_category: ['category.id', 'category.name', 'category.slug', 'category.description', 'parent_channel_id', 'parent_category_id'],
            update_category: ['id', 'name', 'slug', 'description', 'image'],
            delete_category: ['id'],
            link_category: ['category_id', 'channel_ids'],
            unlink_category: ['category_id', 'channel_ids', 'channel_id']
        }
    },
    'run-subject-action': {
        label: 'Subject',
        actions: {
            read_subject: ['id', 'organization_id'],
            create_subject: ['name', 'description', 'category_id', 'summary'],
            update_subject: ['id', 'name', 'description', 'summary', 'metadata'],
            delete_subject: ['id'],
            link_subject: ['subject_id', 'category_id'],
            unlink_subject: ['subject_id', 'category_id'],
            sync_subject_references_from_web: ['subject_ids', 'max_results_per_subject'],
            refresh_subject_metadata_links: ['subject_ids', 'max_results_per_subject']
        }
    },
    'run-post-action': {
        label: 'Post',
        actions: {
            read_post: ['id', 'organization_id'],
            read_attachments: ['post_id', 'attachment_id', 'organization_id'],
            create_post: ['subject_id', 'title', 'narrative', 'metadata'],
            update_post: ['id', 'subject_id', 'title', 'narrative', 'metadata'],
            delete_post: ['id']
        }
    },
    'run-user-tree-action': {
        label: 'User Tree',
        actions: {
            fetch_user_tree: ['root_id']
        }
    },
    'run-chat-action': {
        label: 'Chat',
        actions: {
            search_web_with_tags: ['query', 'max_results'],
            retrieve_db_chunks_and_analyze: ['top_k', 'all_chunks_limit'],
            search_cross_subject_knowledge: ['top_k'],
            scan_user_chats: ['max_chats'],
            extract_llm_background_knowledge: ['focus']
        }
    }
} as const;

type GroupId = keyof typeof catalog;

const title = (value: string): string => {
    const parts = value.split(/[._]/g).filter(Boolean);
    if (!parts.length) return '';
    if (parts.length > 1 && (parts[parts.length - 1] === 'id' || parts[parts.length - 1] === 'ids')) parts.pop();
    return parts
        .map((entry) => `${entry.slice(0, 1).toUpperCase()}${entry.slice(1)}`)
        .join(' ');
};

const option = (value: string) => ({ label: title(value), value });

export const groupedActionGroupIds = Object.keys(catalog) as GroupId[];

export const groupedActionGroupLabel = (modelId: string): string => catalog[modelId as GroupId]?.label || '';

export const groupedActionNames = (modelId: string): string[] => Object.keys(catalog[modelId as GroupId]?.actions || {});

export const groupedActionOptions = (modelId: string): Array<{ label: string; value: string }> => groupedActionNames(modelId).map(option);

export const groupedActionParameterOptionsByAction = (modelId: string): Record<string, Array<{ label: string; value: string }>> => {
    const source = (catalog[modelId as GroupId]?.actions || {}) as Record<string, string[]>;
    const next: Record<string, Array<{ label: string; value: string }>> = {};
    for (const [action, keys] of Object.entries(source)) next[action] = keys.map(option);
    return next;
};

export const groupedActionParameterOptions = (modelId: string): Array<{ label: string; value: string }> => {
    const seen = new Set<string>();
    const next: Array<{ label: string; value: string }> = [];
    for (const values of Object.values(groupedActionParameterOptionsByAction(modelId))) {
        for (const entry of values) {
            if (seen.has(entry.value)) continue;
            seen.add(entry.value);
            next.push(entry);
        }
    }
    return next;
};

export const groupedActionMutatingActions = (modelId: string): string[] =>
    groupedActionNames(modelId).filter((value) => /^(create|update|delete|link|unlink|sync|refresh|attach|detach|save|publish|execute)_/.test(value));
