export const agent_memoryNode = {
  id: 'agent-memory',
  type: 'agent-memory',
  name: 'Agent Memory',
  version: '20.0.0',
  tool: 'agent.memory.search.v2',
};
export default agent_memoryNode;
