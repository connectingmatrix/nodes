# Agent Memory

Routes to `agent.memory.search.v2` through `executeBackend`. The node never opens Supabase, Neo4j, local files, or network resources directly.
