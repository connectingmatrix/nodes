import type { WorkflowCommandToolSpec, WorkerExecuteResult, WorkerPayload, WorkerScope, WorkerUpdateResult, WorkerValidateResult } from '@workflow/executor';
import { normalizeResult, toNode } from '@workflow/executor';
import { executeBackend } from '@workflow/execute';

const NODE_SCOPE: WorkerScope = {};
const descriptor = {
    key: 'executeWorkflowReferenceBackendRequest',
    description: 'Execute one published workflow through the backend workflow runner.'
};
const recordValue = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});
const textValue = (value: unknown): string => String(value || '').trim();
const nodeValue = (payload: WorkerPayload) => recordValue((payload as { NODE?: unknown }).NODE || payload.self);
const parameterValue = (value: unknown): Record<string, unknown> => {
    const record = recordValue(value);
    if (Object.keys(record).length) return record;
    const entries = Array.isArray(value) ? value : [];
    const next: Record<string, unknown> = {};
    for (const entry of entries) {
        const item = recordValue(entry);
        const key = textValue(item.key);
        if (!key) continue;
        next[key] = item.value;
    }
    return next;
};
const workflowIdFromDependency = (runtime: Record<string, unknown>): string => {
    const workflowActionId = textValue(runtime.workflowActionId || runtime.workflow_action_id);
    if (!workflowActionId) return '';
    const dependency = recordValue(recordValue(runtime.dependencyResults)[workflowActionId]);
    const data = recordValue(dependency.data);
    const workflow = recordValue(data.workflow || dependency.workflow);
    return textValue(data.workflow_id || data.workflowId || workflow.workflowId || workflow.id || dependency.workflow_id || dependency.workflowId);
};
export const validate = async (payload: WorkerPayload): Promise<WorkerValidateResult> => {
    const runtime = recordValue(toNode(payload).runtime);
    const errors: string[] = [];
    const executionSource = textValue(runtime.executionSource || 'selected-workflow');
    if (executionSource !== 'selected-workflow' && executionSource !== 'input-workflow-id') errors.push('Execution Source must be "selected-workflow" or "input-workflow-id".');
    if (executionSource === 'selected-workflow' && !textValue(runtime.workflowId)) errors.push('Workflow selection is required when Execution Source is "selected-workflow".');
    return { ok: errors.length === 0, errors, warnings: [], normalizedRuntime: runtime };
};

export const init = async (payload: WorkerPayload): Promise<boolean> => ((NODE_SCOPE.workflowId = textValue(recordValue(payload.workflow?.metadata).id)), true);
export const onUpdate = async (payload: WorkerPayload): Promise<WorkerUpdateResult> => ((NODE_SCOPE.lastOutput = payload.self?.OUTPUT || NODE_SCOPE.lastOutput), { ok: true, error: null });

export const commandToolSpec = async (payload: WorkerPayload): Promise<WorkflowCommandToolSpec> => {
    const node = toNode(payload);
    const runtime = recordValue(node.runtime);
    const executionSource = textValue(runtime.executionSource || 'selected-workflow');
    return {
        toolName: textValue(node.name || 'Execute Workflow') || 'Execute Workflow',
        toolDescription: textValue(runtime.description || 'Execute one published workflow and return its terminal output.'),
        inputContract: {
            required: [],
            optional: executionSource === 'input-workflow-id'
                ? [
                    { key: 'workflowId', label: 'Workflow ID', description: 'Published workflow id to execute directly.' },
                    { key: 'workflowName', label: 'Workflow Name', description: 'Published workflow name to execute when the id is not known.' },
                    { key: 'workflowActionId', label: 'Workflow Action ID', description: 'Prior Workflow action id whose result contains the published workflow id.' },
                    { key: 'organizationId', label: 'Organization ID', description: 'Organization id for organization workflow execution.' },
                    { key: 'parameters', label: 'Start Input', description: 'Named Start node input values passed from the workflow.' }
                ]
                : [{ key: 'workflowName', label: 'Workflow Name', description: 'Published workflow name to execute when the selected workflow id is not set.' }, { key: 'parameters', label: 'Start Input', description: 'Named Start node input values passed from the workflow.' }]
        },
        outputContract: [{ key: 'text', label: 'Text', description: 'Terminal output text from the published workflow.' }, { key: 'editorUrl', label: 'Editor URL', description: 'Workflow editor link for the executed workflow.' }],
        metadata: { modelId: node.modelId, executionSource, toolDomain: 'workflow', mutating: true, workflowOutput: true },
        executionKind: 'tool'
    };
};

export const execute = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => {
    const runtime = recordValue(toNode(payload).runtime);
    try {
        const reason = textValue(runtime.reason || 'Execute the selected workflow.');
        const workflowName = textValue(runtime.workflowName || runtime.workflow_name);
        const workflowId = textValue(runtime.workflowId || runtime.workflow_id || workflowIdFromDependency(runtime) || (textValue(runtime.executionSource || 'selected-workflow') === 'selected-workflow' ? runtime.workflowId : ''));
        if (!workflowId && !workflowName) return { output: { error: 'Workflow ID, Workflow Name, or Workflow Action ID is required.' }, status: 'failed', logs: ['Workflow ID, Workflow Name, or Workflow Action ID is required.'] };
        const result = await executeBackend(descriptor, {
            NODE: nodeValue(payload),
            payload,
            NODE_SCOPE,
            request: {
                workflowId,
                workflowName,
                organizationId: textValue(runtime.organizationId || runtime.organization_id),
                parameters: parameterValue(runtime.parameters),
                reason
            }
        });
        return normalizeResult(result);
    } catch (error) {
        const message = error instanceof Error ? error.message : 'Workflow execution failed.';
        return { output: { error: message }, status: 'failed', logs: [message] };
    }
};
