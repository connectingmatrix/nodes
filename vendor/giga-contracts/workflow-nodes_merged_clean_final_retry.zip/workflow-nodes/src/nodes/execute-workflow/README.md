# Execute Workflow

Worker-owned workflow execution node.

No backend service is used.

- `executionSource`: selected-workflow or input-workflow-id
- `workflowId`: published workflow id when executing by explicit input
- `workflowActionId`: prior `Workflow` action id when execution should resolve from dependency results
- `parameters`: add-row start input values forwarded into the workflow start input
- `reason`: explicit execution reason supplied by the planner
