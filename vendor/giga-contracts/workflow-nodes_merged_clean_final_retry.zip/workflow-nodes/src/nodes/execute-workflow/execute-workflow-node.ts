import rawSchema from '@workflow/nodes/nodes/execute-workflow/execute-workflow-schema.json';
import { createServerOnlyNodeModule } from '@workflow/nodes/nodes/server-only/server-node.module.factory';

const renderIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <rect x="8" y="10" width="14" height="20" rx="4" stroke="currentColor" stroke-width="2.4"/>
  <rect x="26" y="18" width="14" height="20" rx="4" stroke="currentColor" stroke-width="2.4"/>
  <path d="M22 20h8m-3-4 4 4-4 4" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;

const nodeModule = createServerOnlyNodeModule({
    id: 'execute-workflow',
    rawSchema,
    library: {
        id: 'execute-workflow-node',
        label: 'Execute Workflow',
        description: 'Execute a published workflow reference on the server.',
        gigaId: 'ExecuteWorkflowNode',
        modelId: 'execute-workflow',
        group: 'Flow Nodes',
        order: 94,
        iconColor: '#1d4ed8',
        iconBackground: '#dbeafe'
    },
    iconSvg: renderIcon
});

export default nodeModule;
