import type { WorkflowCommandToolSpec } from '@workflow/executor';
import type { WorkerExecuteResult, WorkerPayload, WorkerScope, WorkerUpdateResult, WorkerValidateResult } from '@workflow/executor';
import { toErrorResult, toNode } from '@workflow/executor';

const NODE_SCOPE: WorkerScope = {};

const toRecordValue = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});

const resolvePath = (source: unknown, path: string): unknown => {
    if (!path.trim()) return undefined;
    const normalized = path.replace(/\[(\d+)\]/g, '.$1').trim();
    const segments = normalized.split('.').filter(Boolean);
    let current: unknown = source;
    for (const segment of segments) {
        if (!current || typeof current !== 'object') return undefined;
        current = (current as Record<string, unknown>)[segment];
    }
    return current;
};

const normalizeLoopItems = (value: unknown): unknown[] => {
    if (Array.isArray(value)) return value;
    if (value === null || typeof value === 'undefined') return [];
    if (value && typeof value === 'object') {
        return Object.values(value as Record<string, unknown>);
    }
    return [value];
};

const resolveLoopItems = (sourceValue: unknown, configuredLoopItems: unknown): { source: string; items: unknown[] } => {
    if (Array.isArray(configuredLoopItems)) {
        return { source: 'runtime.loopItems', items: configuredLoopItems };
    }

    if (typeof configuredLoopItems === 'string' && configuredLoopItems.trim().length > 0) {
        const path = configuredLoopItems.trim();
        const resolved = resolvePath(sourceValue, path);
        if (typeof resolved !== 'undefined') {
            return { source: path, items: normalizeLoopItems(resolved) };
        }
        return { source: path, items: [] };
    }

    if (typeof sourceValue !== 'undefined' && sourceValue !== null) {
        return { source: 'runtime.sourceValue', items: normalizeLoopItems(sourceValue) };
    }

    return { source: 'empty', items: [] };
};

const validateFailureMitigation = (runtime: Record<string, unknown>): WorkerValidateResult => {
    const errors: string[] = [];
    const failureMitigation = String(runtime.failureMitigation ?? 'stop-workflow').trim();
    if (failureMitigation !== 'retry-node' && failureMitigation !== 'stop-workflow') {
        errors.push('Failure Mitigation must be either "retry-node" or "stop-workflow".');
    }
    if (failureMitigation === 'retry-node') {
        const retryCount = Number(runtime.retryCount);
        if (!Number.isFinite(retryCount) || retryCount < 1 || retryCount > 6) {
            errors.push('Retry Count must be between 1 and 6 when Failure Mitigation is "retry-node".');
        }
    }
    return { ok: errors.length === 0, errors, warnings: [], normalizedRuntime: runtime };
};

export const validate = async (payload: WorkerPayload): Promise<WorkerValidateResult> => validateFailureMitigation(toRecordValue(toNode(payload).runtime));

export const init = async (payload: WorkerPayload): Promise<boolean> => {
    NODE_SCOPE.workflowId = String(payload.workflow?.metadata?.id ?? '');
    return true;
};

export const onUpdate = async (payload: WorkerPayload): Promise<WorkerUpdateResult> => {
    NODE_SCOPE.lastOutput = payload.self?.OUTPUT ?? NODE_SCOPE.lastOutput;
    return { ok: true, error: null };
};

export const execute = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => {
    try {
        const node = toNode(payload);
        const runtime = toRecordValue(node.runtime);
        const sourceValue = runtime.sourceValue;
        const configuredLoopItems = runtime.loopItems;
        const resolved = resolveLoopItems(sourceValue, configuredLoopItems);
        const itemCount = resolved.items.length;
        const hasItems = itemCount > 0;
        const selectedBranch = hasItems ? 'loop' : 'done';

        return {
            output: {
                source: resolved.source,
                itemCount,
                items: resolved.items,
                selectedBranch,
                doneBranch: {
                    active: !hasItems,
                    outputPort: 'done',
                    value: {
                        loop: {
                            source: resolved.source,
                            itemCount,
                            items: resolved.items,
                            selectedBranch: 'done'
                        }
                    }
                },
                loopBranch: {
                    active: hasItems,
                    outputPort: 'loop',
                    value: {
                        loop: {
                            source: resolved.source,
                            itemCount,
                            items: resolved.items,
                            selectedBranch: 'loop'
                        }
                    }
                },
                __activeOutputs: [selectedBranch]
            },
            status: 'passed',
            logs: [`Loop Over Items resolved ${itemCount} item(s) from "${resolved.source}" and selected "${selectedBranch}" branch.`]
        };
    } catch (error) {
        return toErrorResult(error instanceof Error ? error.message : 'Loop Over Items node execution failed.');
    }
};

// AI Agent command contract: keep this node usable as a declared tool without adding proxy wrappers.
type __GigaCommandRecord = Record<string, unknown>;
const __gigaCommandRecord = (value: unknown): __GigaCommandRecord =>
  value && typeof value === 'object' && !Array.isArray(value) ? (value as __GigaCommandRecord) : {};
const __gigaCommandText = (value: unknown): string => String(value ?? '').trim();
const __gigaCommandNode = (payload: WorkerPayload): __GigaCommandRecord =>
  __gigaCommandRecord((payload as { NODE?: unknown }).NODE || (payload as { self?: unknown }).self || payload);
const __gigaCommandRuntime = (payload: WorkerPayload): __GigaCommandRecord => {
  const node = __gigaCommandNode(payload);
  return { ...__gigaCommandRecord(node.runtime), ...__gigaCommandRecord(node.properties) };
};

export const commandToolSpec = async (payload: WorkerPayload): Promise<WorkflowCommandToolSpec> => {
  const node = __gigaCommandNode(payload);
  const runtime = __gigaCommandRuntime(payload);
  const modelId = __gigaCommandText(node.modelId || runtime.modelId || 'loop-over-items');
  const configuredName = __gigaCommandText(node.name || runtime.name || runtime.title);
  const operation = __gigaCommandText(runtime.operation || runtime.action || runtime.mode || modelId || 'loop-over-items');
  const haystack = `${configuredName} ${operation} ${modelId}`.toLowerCase();
  const mutating = runtime.mutating === true || /\b(create|update|delete|remove|link|unlink|attach|detach|publish|execute|run|write|save|train|install|ingest|fix|stop|wait)\b/.test(haystack);
  return {
    toolName: configuredName || 'Loop Over Items',
    toolDescription: __gigaCommandText(runtime.description || runtime.toolDescription) || 'Iterate over a list and emit one workflow iteration per item.',
    inputContract: {
      required: [],
      optional: [

        { key: 'message', label: 'Message', description: 'Natural-language instruction or task for this node.' },
        { key: 'input', label: 'Input', description: 'Structured JSON input for the node.' },
        { key: 'operation', label: 'Operation', description: 'Operation/action name, when the node supports multiple operations.' },
        { key: 'prompt', label: 'Prompt', description: 'Prompt text for LLM or transformation nodes.' },
        { key: 'data', label: 'Data', description: 'Data payload for processing.' },
      ],
    },
    outputContract: [
      { key: 'output', label: 'Output', description: 'Node output payload.' },
      { key: 'status', label: 'Status', description: 'Execution status.' },
      { key: 'logs', label: 'Logs', description: 'Execution logs, when available.' },
    ],
    metadata: {
      modelId,
      nodeId: __gigaCommandText(node.id || node.nodeId),
      operation,
      toolDomain: 'control',
      mutating,
      reusableByAiAgent: true,
    },
    executionKind: 'tool',
  };
};

