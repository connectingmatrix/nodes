import rawSchema from '@workflow/nodes/nodes/loop-over-items/loop-over-items-schema.json';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { WorkflowNodeKindEnum } from '@workflow/nodes/types';

const schema = parseNodeSchema(rawSchema, 'loop-over-items');
const renderLoopOverItemsIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <path d="M10 18a14 14 0 0 1 24-8l3 3" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>
  <path d="M38 30a14 14 0 0 1-24 8l-3-3" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>
  <path d="M11 10h10v10M37 38H27V28" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;

const loopOverItemsNodeModule: WorkflowNodeModule = {
    id: 'loop-over-items',
    schema,
    library: {
        id: 'loop-over-items-node',
        label: 'Loop Over Items',
        description: 'Select a collection and route to loop/done in a single pass.',
        gigaId: 'LoopOverItemsNode',
        modelId: 'loop-over-items',
        group: 'Flow Nodes',
        nodeType: 'workflowStep',
        defaultKind: WorkflowNodeKindEnum.Process,
        iconColor: '#166534',
        iconBackground: '#dcfce7',
        order: 18
    },
    renderIcon: renderLoopOverItemsIcon,
    buildInitialNode: (context) => buildInitialNodeFromSchema(context),
    ui: {
        localCapable: true,
        serverOnly: false
    },
    execute: createNodeModuleWorkerExecute('loop-over-items')
};

export default loopOverItemsNodeModule;
