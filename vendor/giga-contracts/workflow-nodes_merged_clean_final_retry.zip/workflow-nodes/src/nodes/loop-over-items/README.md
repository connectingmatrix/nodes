# Loop Over Items Node

## Runtime Ownership
Worker-first local node. No backend service is used.

## Usage
Set Loop Items to a variable token or path. Non-empty collections route to `loop`; empty collections route to `done`.

## Inputs
- `Control Port: Command`: Bi-directional control-state input from connected command peers.
- `Input Port: Input`: Incoming data edge payload for this port.
- `Loop Items`: Collection source path or variable token used for branch selection.
- `Failure Mitigation`: Failure Mitigation value for this node.
- `Retry Count`: Retries value for this node.

## Outputs
- `Control Port: Command`: Publishes this node control state for connected command peers.
- `Output Port: Done`: Outgoing payload emitted after node execution.
- `Output Port: Loop`: Outgoing payload emitted after node execution.

## Backend Mapping
- No backend service is used.

## Failure Cases
- Fails when workflow runtime validation fails before execution.
