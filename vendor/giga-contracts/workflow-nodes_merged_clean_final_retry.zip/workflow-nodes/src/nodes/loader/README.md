# Loader

Load files, APIs, databases, and artifacts through backend command routing.

This node is command-capable and routes backend operations through `executeBackend`. It does not access Supabase or Neo4j directly.
