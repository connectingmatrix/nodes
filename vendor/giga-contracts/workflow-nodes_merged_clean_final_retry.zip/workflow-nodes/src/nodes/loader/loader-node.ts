import rawSchema from './loader-schema.json';
import { createAgentBackendNodeModule } from '@workflow/nodes/nodes/_agent-backend-node-module';

export default createAgentBackendNodeModule({ id: 'loader', rawSchema, label: 'Loader', description: 'Load files, APIs, databases, and artifacts through backend command routing.', kind: 'database', order: 521 });
