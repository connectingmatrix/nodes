import rawSchema from '@workflow/nodes/nodes/mcp-capabilities/mcp-capabilities-schema.json';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';
import { MCP_LEGACY_FIELD_KEYS } from '@workflow/nodes/nodes/mcp/mcp-legacy-field-keys';
import { WorkflowNodeKindEnum } from '@workflow/nodes/types';

const schema = parseNodeSchema(rawSchema, 'mcp-capabilities');

const renderMcpCapabilitiesIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <rect x="8" y="8" width="32" height="22" rx="6" stroke="currentColor" stroke-width="2.4"/>
  <path d="M16 16h16M16 22h9M31 22h1" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>
  <circle cx="24" cy="36" r="4" stroke="currentColor" stroke-width="2.2"/>
</svg>`;

const mcpCapabilitiesNodeModule: WorkflowNodeModule = {
    id: 'mcp-capabilities',
    schema,
    library: {
        id: 'mcp-capabilities-node',
        label: 'MCP Capabilities',
        description: 'Run MCP initialize plus tools/list for a streamable HTTP server.',
        gigaId: 'McpCapabilitiesNode',
        modelId: 'mcp-capabilities',
        group: 'MCP Group',
        nodeType: 'workflowStep',
        defaultKind: WorkflowNodeKindEnum.Process,
        iconColor: '#1d4ed8',
        iconBackground: '#dbeafe',
        order: 41
    },
    renderIcon: renderMcpCapabilitiesIcon,
    buildInitialNode: (context) => buildInitialNodeFromSchema(context),
    ui: {
        localCapable: false,
        serverOnly: true,
        inspector: {
            hiddenFieldKeys: MCP_LEGACY_FIELD_KEYS
        }
    },
    execute: createNodeModuleWorkerExecute('mcp-capabilities')
};

export default mcpCapabilitiesNodeModule;
