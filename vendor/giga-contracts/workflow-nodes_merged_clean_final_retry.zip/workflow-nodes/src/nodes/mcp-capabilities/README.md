# MCP Capabilities Node

## Runtime Ownership
Worker-first node. The UI/runtime enters through `worker.ts`, and backend execution is delegated through `[backend handler key]#executeMcpCapabilitiesNode`.

## Usage
Use this node to run the real MCP handshake and list tools from the selected `MCP` credential.

## Inputs
- `MCP` credential selected in the inspector.

## Outputs
- `output`: Real MCP discovery payload with `tools`, `capabilities`, `serverInfo`, and `protocolVersion`.

## Backend Mapping
- Source: `/Users/abeer/dev/giga/giga-ai-backend/src/[backend handler key]`
- Handler: `executeMcpCapabilitiesNode`

## Failure Cases
- Validation fails when no MCP credential is selected.
- Validation fails when the selected MCP credential is malformed or unsupported.
