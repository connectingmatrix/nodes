# RCM Feature Builder

Worker-owned backend tool node that builds compact PHI-safe RCM feature artifacts.

- Uses `executeBackend` function `executeRcmFeatureBuilderNode`.
- Configure `sourceFile` with the workflow-scoped dataset reference.
- Configure `organizationId` through an inspector variable when publishing or reuse needs org scope.
- Emits JSON feature artifact references for model training and scoring.

