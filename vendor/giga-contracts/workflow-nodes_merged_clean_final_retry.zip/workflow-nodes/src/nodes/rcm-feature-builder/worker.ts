import { createBackendToolWorker } from '@workflow/nodes/nodes/server-only/backend-tool-worker';

const worker = createBackendToolWorker({
    functionName: 'executeRcmFeatureBuilderNode',
    description: 'Builds compact PHI-safe RCM feature artifacts.',
    toolName: 'RCM Feature Builder'
});

export const validate = worker.validate;
export const init = worker.init;
export const onUpdate = worker.onUpdate;
export const commandToolSpec = worker.commandToolSpec;
export const execute = worker.execute;
