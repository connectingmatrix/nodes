import { createBackendToolNodeModule } from '@workflow/nodes/nodes/server-only/backend-tool-node.module';

export default createBackendToolNodeModule({
    id: 'rcm-feature-builder',
    label: 'RCM Feature Builder',
    description: 'Builds compact UB, 835, payer, denial, payment, expected-net, and z-field feature profiles.',
    group: 'RCM Pipeline',
    order: 211,
    fields: {
        sourceFile: { type: 'string', editable: true, label: 'Source File', allowVariables: true },
        organizationId: { type: 'string', editable: true, label: 'Organization ID', allowVariables: true }
    }
});
