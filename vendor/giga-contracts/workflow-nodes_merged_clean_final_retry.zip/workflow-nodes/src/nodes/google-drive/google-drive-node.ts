import rawSchema from './google-drive-schema.json';
import { createAgentBackendNodeModule } from '@workflow/nodes/nodes/_agent-backend-node-module';

export default createAgentBackendNodeModule({ id: 'google-drive', rawSchema, label: 'Google Drive', description: 'Read/write Google Drive through centralized backend capabilities.', kind: 'file', order: 514 });
