import rawSchema from '@workflow/nodes/nodes/gemini/gemini-schema.json';
import { createServerOnlyNodeModule } from '@workflow/nodes/nodes/server-only/server-node.module.factory';

const renderIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <rect x="9" y="8" width="30" height="20" rx="4" stroke="currentColor" stroke-width="2.4"/>
  <path d="M15 32h18M20 38h8" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>
</svg>`;

const nodeModule = createServerOnlyNodeModule({
    id: 'gemini',
    rawSchema,
    library: {
        id: 'gemini-node',
        label: 'Gemini',
        description: 'Execute Google Gemini model on server.',
        gigaId: 'GeminiNode',
        modelId: 'gemini',
        group: 'AI Models',
        order: 126,
        iconColor: '#4338ca',
        iconBackground: '#eef2ff'
    },
    iconSvg: renderIcon
});

export default nodeModule;
