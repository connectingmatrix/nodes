import { createBackendToolNodeModule } from '@workflow/nodes/nodes/server-only/backend-tool-node.module';

export default createBackendToolNodeModule({
    id: 'workflow-artifact-publish',
    label: 'Workflow Artifact Publish',
    description: 'Uploads compact derived JSON artifacts to Supabase storage.',
    group: 'Workflow Files',
    order: 118,
    fields: {
        bucket: { type: 'string', editable: true, defaultValue: 'storage', label: 'Bucket', allowVariables: true },
        basePath: { type: 'string', editable: true, label: 'Base Path', allowVariables: true },
        phiSafe: { type: 'boolean', editable: true, defaultValue: true, label: 'PHI Safe' }
    }
});
