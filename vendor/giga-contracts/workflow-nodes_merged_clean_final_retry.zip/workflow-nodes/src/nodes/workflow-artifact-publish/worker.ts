import { createBackendToolWorker } from '@workflow/nodes/nodes/server-only/backend-tool-worker';

const worker = createBackendToolWorker({
    functionName: 'executeWorkflowArtifactPublishNode',
    description: 'Publishes compact JSON artifacts to Supabase storage.',
    toolName: 'Workflow Artifact Publish'
});

export const validate = worker.validate;
export const init = worker.init;
export const onUpdate = worker.onUpdate;
export const commandToolSpec = worker.commandToolSpec;
export const execute = worker.execute;
