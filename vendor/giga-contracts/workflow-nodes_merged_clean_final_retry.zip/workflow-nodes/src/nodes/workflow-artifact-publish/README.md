# Workflow Artifact Publish

Worker-owned backend tool node that publishes compact workflow artifacts to storage.

- Uses `executeBackend` function `executeWorkflowArtifactPublishNode`.
- Configure `bucket`, `basePath`, and `phiSafe` through inspector fields.
- Connect upstream JSON artifacts through variables rather than hidden input reads.
- Emits JSON storage references for later workflow steps.

