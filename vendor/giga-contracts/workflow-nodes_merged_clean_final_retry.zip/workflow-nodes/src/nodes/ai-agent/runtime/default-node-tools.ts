import type { AgentCapability, AgentToolKind } from './capability-types';

const kind = (id: string): AgentToolKind => {
  const text = id.toLowerCase();
  if (/excel|csv|spreadsheet/.test(text)) return 'excel';
  if (/chart|map|plot/.test(text)) return 'chart';
  if (/ai-agent|agent|swarm/.test(text)) return 'agent';
  if (/code|execute|script/.test(text)) return 'code';
  if (/if|else|loop|merge|wait|stop|start|respond|output/.test(text)) return 'control';
  if (/workflow|cypher/.test(text)) return 'workflow';
  if (/tree|channel|category|subject|post/.test(text)) return 'tree';
  if (/chat|message|current-chat/.test(text)) return 'chat';
  if (/openai|claude|gemini|groq|deepseek|perplexity|mistral|llm|model/.test(text)) return 'llm';
  if (/file|drive|attachment|zip|pdf|artifact/.test(text)) return 'file';
  if (/database|postgres|mysql|sqlite|mssql|mongodb|redis|snowflake|bigquery|duckdb|loader|trainer|evaluator|neural|sentiment|churn|feature/.test(text)) return 'database';
  return 'node';
};

const capability = (id: string, description: string, extra: Partial<AgentCapability> = {}): AgentCapability => ({
  id,
  name: id.split(/[-_]/g).map((part) => part ? part[0].toUpperCase() + part.slice(1) : '').join(' '),
  description,
  kind: kind(id),
  source: 'node',
  modelId: id,
  surfaces: ['chat', 'workflow'],
  capabilities: [`node.${id}`, `${kind(id)}.use`, ...(extra.capabilities || [])],
  aliases: extra.aliases || [],
  examples: extra.examples || [],
  mutates: extra.mutates || /create|update|delete|write|publish|attach|link|unlink|execute|run|send|install|train|fix|driver/.test(id),
  mutationPolicy: extra.mutationPolicy || (extra.mutates || /create|update|delete|write|publish|attach|link|unlink|execute|run|send|install|train|fix|driver/.test(id) ? 'confirmation-required' : 'never'),
  risk: extra.risk || (extra.mutates ? 'write' : 'none'),
  ...extra,
});

export const DEFAULT_AGENT_NODE_TOOLS: AgentCapability[] = [
  capability('excel', 'Read, summarize, stream, query, write, and transform Excel/CSV data through the Excel node.', { capabilities: ['excel.read', 'excel.write', 'file.stream', 'duckdb.inline_sql'], examples: [{ user: 'Analyze this 3GB Excel and make a report', args: { operation: 'stream_to_sql' } }] }),
  capability('chart', 'Generate labeled chart outputs, chart groups, and map charts.', { capabilities: ['chart.render', 'chart.group', 'chart.map', 'chart.label'], examples: [{ user: 'Generate a Pakistan population map in blue shades', args: { operation: 'render_map' } }] }),
  capability('ai-agent', 'Launch nested thought loops, delegation, and swarm workers through connected agent nodes.', { capabilities: ['agent.delegate', 'agent.swarm', 'agent.multi_pass'], mutates: true, risk: 'swarm', examples: [{ user: 'Launch a verifier swarm to inspect these workflows', args: { operation: 'swarm' } }] }),
  capability('code', 'Run code snippets in the executor sandbox using approved tools and dependency rules.', { capabilities: ['code.run', 'sandbox.tools', 'node.dynamic'], mutates: true, risk: 'write' }),
  capability('if-else', 'Branch execution based on structured conditions.', { capabilities: ['control.branch'] }),
  capability('response', 'Build rich user-facing responses.', { capabilities: ['response.emit', 'viewer.output'] }),
  capability('output', 'Emit workflow outputs and downloadable artifacts.', { capabilities: ['output.emit', 'file.output'] }),
  capability('workflow', 'Create, execute, debug, fix, publish, attach, and cleanup workflows through backend workflow operations.', { capabilities: ['workflow.create', 'workflow.execute', 'workflow.debug', 'workflow.fix', 'workflow.logs', 'workflow.publish', 'workflow.attach'], mutates: true, examples: [{ user: 'Create a workflow that creates another workflow', args: { operation: 'compile' } }] }),
  capability('tree', 'Create/read/update/delete/link/unlink tree nodes through backend entities only.', { capabilities: ['entity.tree.read', 'entity.tree.write', 'entity.tree.link', 'entity.tree.unlink', 'tree.realtime.refetch'], mutates: true }),
  capability('chat', 'Read/write chat messages, query chat, and process chat attachments via backend entities.', { capabilities: ['entity.chat.read', 'entity.chat.write', 'chat.query', 'attachment.process'], mutates: true }),
  capability('llm', 'Call configured language models through LLM nodes.', { capabilities: ['llm.call', 'prompt.run'] }),
  capability('file', 'Read, chunk, ingest, archive, stream, and publish files through backend/executor file tools.', { capabilities: ['file.read', 'file.chunk', 'file.ingest', 'file.publish', 'zip.tree'], mutates: true }),
  capability('database-driver', 'Create/query sandboxed database driver nodes with allowlisted package installation and cached modules.', { capabilities: ['database.driver', 'database.query', 'database.loader', 'database.pool'], mutates: true, risk: 'package-install' }),
  capability('neural-net-trainer', 'Create/train/evaluate neural-net trainer nodes under sandbox and dependency policy.', { capabilities: ['ml.train', 'ml.evaluate', 'node.dynamic'], mutates: true, risk: 'package-install' }),
  capability('loader', 'Create loader nodes for files, databases, APIs, and artifacts.', { capabilities: ['data.load', 'file.stream', 'database.query'], mutates: true }),
  capability('evaluator', 'Create evaluator nodes for model/workflow outputs.', { capabilities: ['ml.evaluate', 'workflow.verify'], mutates: true }),
  capability('sentiment-analysis', 'Create sentiment analysis nodes for text/chat/file datasets.', { capabilities: ['nlp.sentiment', 'node.dynamic'], mutates: true }),
  capability('churn-analysis', 'Create churn analysis nodes from customer/account datasets.', { capabilities: ['analytics.churn', 'node.dynamic'], mutates: true }),
  capability('feature-analysis', 'Create feature analysis nodes for tabular/product datasets.', { capabilities: ['analytics.feature', 'node.dynamic'], mutates: true }),
  capability('gmail', 'Use Gmail capabilities through credentialed backend tools or connected nodes.', { capabilities: ['email.read', 'email.send', 'gmail.use'], mutates: true, risk: 'external-network' }),
  capability('email', 'Generic email read/send node using credentialed backend tools.', { capabilities: ['email.read', 'email.send'], mutates: true, risk: 'external-network' }),
  capability('airtable', 'Read/write Airtable records through credentialed backend tools or connected nodes.', { capabilities: ['airtable.read', 'airtable.write'], mutates: true, risk: 'external-network' }),
  capability('google-sheets', 'Read/write Google Sheets through credentialed backend tools or connected nodes.', { capabilities: ['sheets.read', 'sheets.write'], mutates: true, risk: 'external-network' }),
  capability('google-drive', 'Read/write Google Drive files through credentialed backend tools or connected nodes.', { capabilities: ['drive.read', 'drive.write'], mutates: true, risk: 'external-network' }),
  capability('slack', 'Read/send Slack messages through credentialed backend tools or connected nodes.', { capabilities: ['slack.read', 'slack.send'], mutates: true, risk: 'external-network' }),
  capability('agent-file-ingest', 'Ingest files and attachments using size-aware backend file rules.', { capabilities: ['file.ingest', 'attachment.process'], mutates: true }),
  capability('artifact-publish', 'Publish files, workflows, charts, and generated nodes to user/org artifact channels.', { capabilities: ['artifact.publish', 'tree.artifacts'], mutates: true }),
  capability('mcp-capabilities', 'List centralized MCP capabilities available to the current caller and scope.', { capabilities: ['mcp.capabilities'] }),
  capability('mcp-runtime', 'Execute centralized MCP actions through backend capability routing.', { capabilities: ['mcp.execute'], mutates: true }),
];
