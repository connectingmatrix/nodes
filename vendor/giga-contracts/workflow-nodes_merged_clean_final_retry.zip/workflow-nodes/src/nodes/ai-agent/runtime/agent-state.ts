import type { AgentCarryContext, AgentFileOutput, AgentRecord, AgentTodoItem, AgentToolExecution } from './capability-types';

const record = (value: unknown): AgentRecord => value && typeof value === 'object' && !Array.isArray(value) ? value as AgentRecord : {};
const text = (value: unknown): string => String(value ?? '').trim();
const stableId = (value: unknown) =>
  text(value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 80) || `todo-${Date.now()}`;

export const emptyCarryContext = (): AgentCarryContext => ({ facts: {}, todos: [], artifacts: [], decisions: [], warnings: [] });

export const mergeCarryContext = (base: AgentCarryContext, patch?: Partial<AgentCarryContext> | null): AgentCarryContext => ({
  facts: { ...base.facts, ...record(patch?.facts) },
  todos: mergeTodos(base.todos, patch?.todos || []),
  artifacts: mergeArtifacts(base.artifacts, patch?.artifacts || []),
  decisions: [...base.decisions, ...(patch?.decisions || []).map(record)],
  warnings: [...base.warnings, ...(patch?.warnings || []).map(String)].slice(-80),
});

const mergeTodos = (left: AgentTodoItem[], right: AgentTodoItem[]): AgentTodoItem[] => {
  const map = new Map<string, AgentTodoItem>();
  for (const item of [...left, ...right]) {
    const id = text(item.id) || stableId(item.title);
    map.set(id, { ...map.get(id), ...item, id });
  }
  return Array.from(map.values()).slice(-200);
};

const mergeArtifacts = (left: AgentFileOutput[], right: AgentFileOutput[]): AgentFileOutput[] => {
  const map = new Map<string, AgentFileOutput>();
  for (const item of [...left, ...right]) {
    const id = text(item.id || item.url || item.path || item.filename);
    if (id) map.set(id, { ...map.get(id), ...item });
  }
  return Array.from(map.values()).slice(-200);
};

export const todoFromUserMessage = (message: string): AgentTodoItem[] => {
  const trimmed = text(message);
  if (!trimmed) return [];
  return [{ id: stableId(trimmed), title: trimmed.slice(0, 180), status: 'pending' }];
};

export const updateCarryContextFromToolResult = (carry: AgentCarryContext, execution: AgentToolExecution): AgentCarryContext => {
  const output = record(execution.output);
  const patch: Partial<AgentCarryContext> = {};
  if (Array.isArray(output.todos)) patch.todos = output.todos.map((item) => record(item) as AgentTodoItem);
  if (Array.isArray(output.artifacts)) patch.artifacts = output.artifacts.map((item) => record(item) as AgentFileOutput);
  if (Array.isArray(execution.files) && execution.files.length) patch.artifacts = [...(patch.artifacts || []), ...execution.files];
  if (output.facts && typeof output.facts === 'object') patch.facts = output.facts as AgentRecord;
  if (output.decision) patch.decisions = [record(output.decision)];
  if (execution.error) patch.warnings = [execution.error];
  const merged = mergeCarryContext(carry, patch);
  if (execution.status === 'completed') {
    merged.todos = merged.todos.map((todo) => todo.status === 'running' ? { ...todo, status: 'completed', resultRef: execution.action.id } : todo);
  }
  return merged;
};

export const compactCarryContextForPrompt = (carry: AgentCarryContext): string => JSON.stringify({
  facts: carry.facts,
  todos: carry.todos.slice(-40),
  artifacts: carry.artifacts.slice(-20).map((file) => ({ filename: file.filename, url: file.url, path: file.path, type: file.contentType })),
  decisions: carry.decisions.slice(-20),
  warnings: carry.warnings.slice(-20),
}, null, 2);
