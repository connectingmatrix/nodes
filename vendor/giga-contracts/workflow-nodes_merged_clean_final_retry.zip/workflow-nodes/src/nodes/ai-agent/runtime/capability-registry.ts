import type { AgentCapability, AgentCapabilityGraph, AgentExecutionSurface, AgentToolSpec, CapabilityProvider, CapabilityProviderInput, ConnectedNodeCommand } from './capability-types';
import { DEFAULT_AGENT_NODE_TOOLS } from './default-node-tools';
import { r20AdvancedAgentTools } from './r20-capabilities';

const text = (value: unknown): string => String(value ?? '').trim();
const lower = (value: unknown): string => text(value).toLowerCase();
const record = (value: unknown): Record<string, unknown> => value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {};
const unique = <T>(items: T[]): T[] => Array.from(new Set(items.filter(Boolean as unknown as (value: T) => boolean)));

export const SYSTEM_AGENT_TOOLS: AgentCapability[] = [
  { id: 'agent.capabilities', name: 'Agent Capabilities', description: 'List saved/reusable AI Agent capabilities, stored agent actions, sessions, memory, runs, and swarm tools.', kind: 'agent', source: 'system', surfaces: ['chat', 'workflow'], mutates: false, mutationPolicy: 'never', risk: 'none', capabilities: ['agent.capabilities', 'agent.catalog'] },
  { id: 'agent.operation', name: 'Agent Operation', description: 'Create, update, delete, list, attach, and manage saved AI Agents through backend entities.', kind: 'agent', source: 'system', surfaces: ['chat', 'workflow'], mutates: true, mutationPolicy: 'confirmation-required', risk: 'write', capabilities: ['agent.create', 'agent.update', 'agent.delete', 'agent.attach', 'agent.sessions'] },
  { id: 'agent.run', name: 'Run Saved AI Agent', description: 'Run a stored AI Agent using OpenAI Agents SDK, persisted sessions, memory, tools, and node rules.', kind: 'agent', source: 'system', surfaces: ['chat', 'workflow'], mutates: true, mutationPolicy: 'confirmation-required', risk: 'write', capabilities: ['agent.run', 'openai.agents.sdk', 'agent.sessions'] },
  { id: 'agent.swarm', name: 'Launch Agent Swarm', description: 'Launch a confirmed multi-agent swarm with temporary specialist agents/workflows, collect results, and clean up.', kind: 'agent', source: 'system', surfaces: ['chat', 'workflow'], mutates: true, mutationPolicy: 'confirmation-required', risk: 'admin', capabilities: ['agent.swarm', 'agent.delegate', 'workflow.swarm'] },
  { id: 'entity.capabilities', name: 'Entity Capabilities', description: 'List every entity/relation operation the current caller can request. Permission engine still decides whether it is allowed.', kind: 'entity', source: 'system', surfaces: ['chat', 'workflow'], mutates: false, mutationPolicy: 'never', risk: 'none', capabilities: ['entity.capabilities', 'permission.matrix'], examples: [{ user: 'What entity operations can I perform?', args: { operation: 'list' } }] },
  { id: 'entity.operation', name: 'Entity Operation', description: 'Create/read/update/delete/link/unlink/attach/detach/list/search tree, chat, workflow, credential, user, root-user, and super-admin entities through executeBackend -> Entities. Auth operations are excluded.', kind: 'entity', source: 'system', surfaces: ['chat', 'workflow'], mutates: true, mutationPolicy: 'confirmation-required', risk: 'write', capabilities: ['entity.create', 'entity.read', 'entity.update', 'entity.delete', 'entity.link', 'entity.unlink', 'entity.attach', 'entity.detach', 'permission.enforced', 'tree.realtime.refetch'], examples: [{ user: 'Create a channel named Politics', args: { entity: 'Channel', operation: 'create', data: { name: 'Politics' } } }, { user: 'Link Subject with XYZ Channel', args: { entity: 'Channel', relation: 'subjects', operation: 'attach' } }] },

  { id: 'entity.batch', name: 'Entity Batch Operation', description: 'Run a validated batch of entity operations through executeBackend -> Entities. Use for larger tree/content structures after planning and confirmation.', kind: 'entity', source: 'system', surfaces: ['chat', 'workflow'], mutates: true, mutationPolicy: 'confirmation-required', risk: 'write', capabilities: ['entity.batch', 'tree.structure', 'content.structure', 'bulk.operation'], examples: [{ user: 'Create a linked world politics tree', args: { items: [{ entity: 'User', relation: 'channels', operation: 'create', payload: { name: 'World Politics' } }] } }] },
  { id: 'tree.operation', name: 'Tree Operation', description: 'Create/read/update/delete/link/unlink Channel, Category, Subject, and Post nodes through entity relation managers. Use this for user/org/global tree edits and realtime tree refetch effects.', kind: 'tree', source: 'system', surfaces: ['chat', 'workflow'], mutates: true, mutationPolicy: 'confirmation-required', risk: 'write', capabilities: ['tree.create', 'tree.update', 'tree.delete', 'tree.link', 'tree.unlink', 'tree.refetch', 'channel.operation', 'category.operation', 'subject.operation', 'post.operation'], examples: [{ user: 'Link Subject with XYZ Channel', args: { parentEntity: 'Channel', parentId: '<channel-id>', childEntity: 'Subject', id: '<subject-id>', operation: 'link' } }] },
  { id: 'workflow.logs', name: 'Workflow Logs', description: 'Fetch workflow execution logs through WorkflowExecution.logs and WorkflowLog entities.', kind: 'workflow', source: 'system', surfaces: ['chat', 'workflow'], mutates: false, mutationPolicy: 'never', risk: 'none', capabilities: ['workflow.logs', 'workflow.debug', 'workflow.execution.logs'] },
  { id: 'workflow.events', name: 'Workflow Events', description: 'Fetch workflow execution events through WorkflowExecution.events entities.', kind: 'workflow', source: 'system', surfaces: ['chat', 'workflow'], mutates: false, mutationPolicy: 'never', risk: 'none', capabilities: ['workflow.events', 'workflow.execution.events'] },
  { id: 'workflow.live_logs', name: 'Workflow Live Logs', description: 'Prepare a live workflow log/event subscription and return the current snapshot and GraphQL subscription payload.', kind: 'workflow', source: 'system', surfaces: ['chat', 'workflow'], mutates: false, mutationPolicy: 'never', risk: 'none', capabilities: ['workflow.live_logs', 'workflow.listen_logs', 'workflow.events.live'] },
  { id: 'workflow.running', name: 'Workflow Running Catalog', description: 'Fetch currently queued/running workflow executions for the current caller/scope or selected workflow ids.', kind: 'workflow', source: 'system', surfaces: ['chat', 'workflow'], mutates: false, mutationPolicy: 'never', risk: 'none', capabilities: ['workflow.running', 'workflow.catalog.running', 'workflow.status'] },
  { id: 'workflow.catalog', name: 'Workflow Catalog', description: 'Fetch accessible workflow catalog rows for the current user/organisation/root scope.', kind: 'workflow', source: 'system', surfaces: ['chat', 'workflow'], mutates: false, mutationPolicy: 'never', risk: 'none', capabilities: ['workflow.catalog', 'workflow.list', 'workflow.accessible'] },
  { id: 'workflow.compile', name: 'Workflow Compiler', description: 'Compile a natural-language task into a validated workflow draft using node manifests and capability schemas.', kind: 'workflow', source: 'system', surfaces: ['chat', 'workflow'], mutates: false, mutationPolicy: 'never', risk: 'none', capabilities: ['workflow.compile', 'workflow.validate', 'node.manifest'] },
  { id: 'workflow.operation', name: 'Workflow Operation', description: 'Create, execute, publish, attach, debug, fix, listen to logs, delegate, swarm, and cleanup workflows through backend entities.', kind: 'workflow', source: 'system', surfaces: ['chat', 'workflow'], mutates: true, mutationPolicy: 'confirmation-required', risk: 'write', capabilities: ['workflow.create', 'workflow.execute', 'workflow.debug', 'workflow.fix', 'workflow.logs', 'workflow.swarm', 'workflow.cleanup', 'workflow.publish'] },
  { id: 'knowledge.chunk', name: 'Knowledge Chunk', description: 'Break large knowledge, PDFs, markdown, text, chat history, and file contents into smaller chunks.', kind: 'knowledge', source: 'system', surfaces: ['chat', 'workflow'], mutates: false, mutationPolicy: 'never', risk: 'none', capabilities: ['knowledge.chunk', 'knowledge.summarize', 'giga.knowledge'] },
  { id: 'knowledge.giga.search', name: 'Giga Knowledge Search', description: 'Search backend KNOWLEDGE.md / Giga knowledge files whenever the user asks about Giga or Giga Chat.', kind: 'knowledge', source: 'system', surfaces: ['chat', 'workflow'], mutates: false, mutationPolicy: 'never', risk: 'none', capabilities: ['knowledge.giga', 'knowledge.search', 'giga.chat'] },
  { id: 'knowledge.giga.answer', name: 'Giga Knowledge Answer', description: 'Prepare grounded Giga knowledge context for final answers and Giga workflows.', kind: 'knowledge', source: 'system', surfaces: ['chat', 'workflow'], mutates: false, mutationPolicy: 'never', risk: 'none', capabilities: ['knowledge.giga.answer', 'giga.workflow'] },
  { id: 'file.ingest', name: 'File Ingest', description: 'Process chat attachments, PDFs, images, zips, CSV, Excel, and large files using stream/chunk metadata.', kind: 'file', source: 'system', surfaces: ['chat', 'workflow'], mutates: true, mutationPolicy: 'confirmation-required', risk: 'large-cost', capabilities: ['file.upload', 'file.ingest', 'file.stream', 'file.zip_tree', 'file.inline_sql', 'duckdb.query'] },
  { id: 'file.output', name: 'File Output', description: 'Create downloadable files and viewer cards for the chat response.', kind: 'file', source: 'system', surfaces: ['chat', 'workflow'], mutates: true, mutationPolicy: 'confirmation-required', risk: 'write', capabilities: ['file.output', 'viewer.file'] },
  { id: 'artifact.publish', name: 'Artifact Publisher', description: 'Publish generated files, charts, workflows, and .node packages into user or organisation artifact channels and return download links.', kind: 'file', source: 'system', surfaces: ['chat', 'workflow'], mutates: true, mutationPolicy: 'confirmation-required', risk: 'write', capabilities: ['artifact.publish', 'storage.upload', 'tree.artifacts'] },
  { id: 'dynamic-node.operation', name: 'Dynamic Node Operation', description: 'Validate, package as .node, cache dependencies for, register, and execute dynamic nodes under node rules.', kind: 'node', source: 'system', surfaces: ['chat', 'workflow'], mutates: true, mutationPolicy: 'confirmation-required', risk: 'package-install', capabilities: ['node.dynamic', 'node.package', 'dependency.cache', 'sandbox.execute'] },
  { id: 'database.driver', name: 'Database Driver Node Builder', description: 'Create database driver nodes using allowlisted package installation in the executor sandbox.', kind: 'database', source: 'system', surfaces: ['chat', 'workflow'], mutates: true, mutationPolicy: 'confirmation-required', risk: 'package-install', capabilities: ['database.driver', 'database.query', 'dependency.cache'] },
  { id: 'slash.hints', name: 'Slash Command Hints', description: 'Return UI slash command completions from the capability registry.', kind: 'chat', source: 'system', surfaces: ['chat'], mutates: false, mutationPolicy: 'never', risk: 'none', capabilities: ['slash.hints'] },
  { id: 'slash.execute', name: 'Slash Command Execute', description: 'Execute slash commands through capabilities and backend entities.', kind: 'chat', source: 'system', surfaces: ['chat'], mutates: true, mutationPolicy: 'confirmation-required', risk: 'write', capabilities: ['slash.execute'] },
  { id: 'mcp.capabilities', name: 'MCP Capabilities', description: 'Fetch centralized MCP tools/resources/prompts for the current caller and scope.', kind: 'node', source: 'system', surfaces: ['chat', 'workflow'], mutates: false, mutationPolicy: 'never', risk: 'none', capabilities: ['mcp.capabilities', 'mcp.tools', 'mcp.resources', 'mcp.prompts'] },
  { id: 'mcp.execute', name: 'MCP Execute', description: 'Execute a centralized MCP action after permission and node-rule validation.', kind: 'node', source: 'system', surfaces: ['chat', 'workflow'], mutates: true, mutationPolicy: 'confirmation-required', risk: 'external-network', capabilities: ['mcp.execute'] },
];

for (const tool of r20AdvancedAgentTools) {
  SYSTEM_AGENT_TOOLS.push({
    ...tool,
    source: 'system',
    surfaces: ['chat', 'workflow'],
    mutates: true,
    mutationPolicy: 'confirmation-required',
    risk: 'write',
    capabilities: unique([...(tool.capabilities || []), tool.id, 'agent.r20']),
  });
}

export const kindFromText = (input: unknown): AgentToolSpec['kind'] => {
  const value = lower(input);
  if (/agent|swarm/.test(value)) return 'agent';
  if (/chart|plot|map|visual/.test(value)) return 'chart';
  if (/chat|message/.test(value)) return 'chat';
  if (/code|script|execute/.test(value)) return 'code';
  if (/if|else|control|branch|response|output|start|stop|loop|wait|merge/.test(value)) return 'control';
  if (/database|postgres|mysql|sqlite|mongo|redis|snowflake|bigquery|duckdb|loader|trainer|evaluator/.test(value)) return 'database';
  if (/entity|orm/.test(value)) return 'entity';
  if (/excel|sheet|csv|xlsx/.test(value)) return 'excel';
  if (/file|drive|artifact|attachment|zip|pdf/.test(value)) return 'file';
  if (/knowledge|chunk|ingest/.test(value)) return 'knowledge';
  if (/llm|openai|claude|gemini|groq|deepseek|perplexity|mistral|model/.test(value)) return 'llm';
  if (/tree|channel|category|subject|post/.test(value)) return 'tree';
  if (/workflow|run|publish|debug|fix/.test(value)) return 'workflow';
  return 'node';
};

export const capabilityFromConnectedCommand = (command: ConnectedNodeCommand): AgentCapability => {
  const id = text(command.nodeId || command.toolName || command.modelId);
  const modelId = text(command.modelId || command.toolName || id);
  const metadata = record(command.metadata);
  const kind = kindFromText([modelId, command.toolName, command.toolDescription, JSON.stringify(metadata)].join(' '));
  const explicitMutating = metadata.mutating === true ? true : metadata.mutating === false ? false : null;
  const mutatesByKeyword = /create|update|delete|write|publish|attach|link|unlink|execute|run|send|install|train|fix/.test(
    lower(`${modelId} ${command.toolName} ${command.toolDescription}`),
  );
  const mutates = explicitMutating === null ? mutatesByKeyword : explicitMutating;
  return {
    id,
    name: text(command.toolName || modelId || id),
    description: text(command.toolDescription || `Connected ${modelId} tool.`),
    kind,
    source: 'connected-node',
    modelId,
    nodeId: command.nodeId,
    surfaces: ['workflow'],
    requiresConnectedNode: true,
    mutates,
    risk: mutates ? 'write' : 'none',
    mutationPolicy: mutates ? 'confirmation-required' : 'never',
    inputContract: command.inputContract,
    outputContract: command.outputContract,
    metadata,
    capabilities: unique([`connected.${kind}`, `node.${modelId}`, ...Object.values(metadata).filter((value): value is string => typeof value === 'string')]),
  };
};

export class AgentCapabilityRegistry {
  private readonly providers: CapabilityProvider[] = [];
  private readonly staticCapabilities = new Map<string, AgentCapability>();

  public register(capability: AgentCapability): this {
    const id = text(capability.id || capability.name);
    if (!id) throw new Error('Agent capability requires id.');
    const existing = this.staticCapabilities.get(id);
    this.staticCapabilities.set(id, existing ? mergeCapability(existing, { ...capability, id }) : { ...capability, id });
    return this;
  }

  public registerMany(capabilities: AgentCapability[]): this {
    for (const capability of capabilities) this.register(capability);
    return this;
  }

  public registerProvider(provider: CapabilityProvider): this {
    this.providers.push(provider);
    return this;
  }

  public async list(input: CapabilityProviderInput): Promise<AgentCapability[]> {
    const capabilities = new Map<string, AgentCapability>();
    const add = (capability: AgentCapability) => {
      if (capability.enabled === false) return;
      const id = text(capability.id || capability.name);
      if (!id) return;
      const surfaces = capability.surfaces || ['chat', 'workflow'];
      if (!surfaces.includes(input.surface) && !surfaces.includes('system')) return;
      if (input.surface === 'workflow' && capability.source === 'node' && capability.requiresConnectedNode !== true && input.includeDefaultNodeTools === false) return;
      capabilities.set(id, capabilities.has(id) ? mergeCapability(capabilities.get(id) as AgentCapability, { ...capability, id }) : { ...capability, id });
    };

    if (input.includeSystemTools !== false) SYSTEM_AGENT_TOOLS.forEach(add);
    if (input.includeDefaultNodeTools !== false && input.surface === 'chat') DEFAULT_AGENT_NODE_TOOLS.forEach(add);
    if (input.surface === 'workflow') (input.connectedCommands || []).map(capabilityFromConnectedCommand).forEach(add);
    for (const capability of input.entityCapabilities || []) add({ ...capability, source: 'backend', surfaces: ['chat', 'workflow'] });
    for (const capability of this.staticCapabilities.values()) add(capability);
    for (const provider of this.providers) (await provider(input)).forEach(add);
    for (const mcpCapability of input.mcpCapabilities || []) add({ ...mcpCapability, source: 'mcp', surfaces: ['chat', 'workflow'] });
    return Array.from(capabilities.values()).sort((left, right) => left.name.localeCompare(right.name));
  }

  public async graph(input: CapabilityProviderInput): Promise<AgentCapabilityGraph> {
    const tools = (await this.list(input)).map(toToolSpec);
    const byKind: AgentCapabilityGraph['byKind'] = {};
    const byId: Record<string, AgentToolSpec> = {};
    for (const tool of tools) {
      byId[tool.id] = tool;
      byKind[tool.kind] = [...(byKind[tool.kind] || []), tool];
    }
    return { generatedAt: new Date().toISOString(), surface: input.surface, tools, byKind, byId };
  }
}

export const createDefaultAgentCapabilityRegistry = (): AgentCapabilityRegistry => new AgentCapabilityRegistry().registerMany(SYSTEM_AGENT_TOOLS).registerMany(DEFAULT_AGENT_NODE_TOOLS);

export const mergeCapability = (left: AgentCapability, right: AgentCapability): AgentCapability => ({
  ...left,
  ...right,
  capabilities: unique([...(left.capabilities || []), ...(right.capabilities || [])]),
  aliases: unique([...(left.aliases || []), ...(right.aliases || [])]),
  examples: [...(left.examples || []), ...(right.examples || [])],
  permissions: unique([...(left.permissions || []), ...(right.permissions || [])]),
  metadata: { ...(left.metadata || {}), ...(right.metadata || {}) },
});

export const toToolSpec = (capability: AgentCapability): AgentToolSpec => ({
  id: capability.id,
  name: capability.name,
  description: capability.description,
  kind: capability.kind,
  source: capability.source,
  modelId: capability.modelId,
  nodeId: capability.nodeId,
  capabilities: capability.capabilities,
  aliases: capability.aliases,
  examples: capability.examples,
  permissions: capability.permissions,
  risk: capability.risk,
  mutates: capability.mutates,
  mutationPolicy: capability.mutationPolicy,
  inputContract: capability.inputContract,
  outputContract: capability.outputContract,
  metadata: capability.metadata,
});

export const buildAgentTools = async (input: CapabilityProviderInput & { registry?: AgentCapabilityRegistry }): Promise<AgentToolSpec[]> => {
  const registry = input.registry || createDefaultAgentCapabilityRegistry();
  return (await registry.list(input)).map(toToolSpec);
};

export const buildAgentCapabilityGraph = async (input: CapabilityProviderInput & { registry?: AgentCapabilityRegistry }): Promise<AgentCapabilityGraph> => {
  const registry = input.registry || createDefaultAgentCapabilityRegistry();
  return registry.graph(input);
};


export const buildAgentToolCatalogForSurface = (input: {
  surface?: AgentExecutionSurface;
  connectedTools?: AgentToolSpec[];
  connectedCommands?: ConnectedNodeCommand[];
  includeDefaultNodeTools?: boolean;
  includeSystemTools?: boolean;
  entityCapabilities?: AgentCapability[];
  mcpCapabilities?: AgentCapability[];
}): AgentToolSpec[] => {
  const surface = input.surface || 'chat';
  const capabilities = new Map<string, AgentToolSpec>();
  const add = (tool: AgentToolSpec) => { if (tool?.id) capabilities.set(tool.id, tool); };
  if (input.includeSystemTools !== false) SYSTEM_AGENT_TOOLS.map(toToolSpec).forEach(add);
  if (surface === 'chat' && input.includeDefaultNodeTools !== false) DEFAULT_AGENT_NODE_TOOLS.map(toToolSpec).forEach(add);
  if (surface === 'workflow') (input.connectedTools || []).forEach(add);
  if (surface === 'workflow') (input.connectedCommands || []).map(capabilityFromConnectedCommand).map(toToolSpec).forEach(add);
  (input.entityCapabilities || []).map(toToolSpec).forEach(add);
  (input.mcpCapabilities || []).map(toToolSpec).forEach(add);
  return Array.from(capabilities.values()).sort((left, right) => left.name.localeCompare(right.name));
};

export const createAgentToolCatalog = buildAgentToolCatalogForSurface;
