import { describe, expect, it } from 'vitest';
import { buildAgentToolCatalogForSurface } from '../capability-registry';

describe('R17 agent tool catalog', () => {
  it('gives chat agents system and default node tools', () => {
    const tools = buildAgentToolCatalogForSurface({ surface: 'chat' });
    expect(tools.some((tool) => tool.id === 'agent.run')).toBe(true);
    expect(tools.some((tool) => tool.id === 'entity.operation')).toBe(true);
  });

  it('limits workflow agents to system plus connected tools', () => {
    const tools = buildAgentToolCatalogForSurface({ surface: 'workflow', connectedTools: [{ id: 'connected-chart', name: 'Connected Chart', kind: 'chart', description: 'connected chart node', source: 'connected-node' } as never], includeDefaultNodeTools: false });
    expect(tools.some((tool) => tool.id === 'connected-chart')).toBe(true);
    expect(tools.some((tool) => tool.source === 'node')).toBe(false);
  });
});
