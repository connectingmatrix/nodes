import { describe, expect, it } from 'vitest';
import { buildCapabilityRoutedFallbackPlan } from '../semantic-router';
import type { AgentToolSpec } from '../capability-types';

const tools: AgentToolSpec[] = [
  { id: 'entity.operation', name: 'Entity Operation', description: 'Create update delete link unlink Channel Category Subject Post tree nodes', kind: 'entity', capabilities: ['channel.create', 'tree.link'], source: 'system' },
  { id: 'workflow.operation', name: 'Workflow Operation', description: 'Create execute publish debug fix workflows and listen logs', kind: 'workflow', capabilities: ['workflow.create'], source: 'system' },
  { id: 'chart', name: 'Chart', description: 'Render charts maps plots', kind: 'chart', source: 'node' },
];

describe('semantic router', () => {
  it('routes by capability manifest, not hardcoded cases', () => {
    const plan = buildCapabilityRoutedFallbackPlan('Please create a channel and link a subject', tools);
    expect(plan.actions.some((action) => action.tool === 'entity.operation')).toBe(true);
  });

  it('responds to common messages without tools', () => {
    const plan = buildCapabilityRoutedFallbackPlan('hello', tools);
    expect(plan.actions.length).toBe(0);
  });
});
