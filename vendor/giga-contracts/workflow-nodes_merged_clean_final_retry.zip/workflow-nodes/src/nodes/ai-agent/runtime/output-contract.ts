import type { AgentFileOutput, AgentRecord } from './capability-types';

export type AgentOutputBlock =
  | { type: 'markdown'; markdown: string }
  | { type: 'excel'; path: string; label?: string | null; metadata?: AgentRecord }
  | { type: 'chart'; id?: string | null; columnSize?: string | null; spec?: unknown; markdown?: string | null; metadata?: AgentRecord }
  | { type: 'chart-group'; charts: AgentOutputBlock[]; metadata?: AgentRecord }
  | { type: 'banner'; title: string; subtitle?: string | null; tone?: string | null; metadata?: AgentRecord }
  | { type: 'artifact-card'; file: AgentFileOutput; metadata?: AgentRecord }
  | { type: 'terminal'; text: string; metadata?: AgentRecord };

export const AGENT_OUTPUT_FORMAT_SYSTEM_PROMPT = `
Output contract for Giga Chat:
- Use normal Markdown for explanation.
- Downloadable Excel or CSV files may be emitted as [EXCEL]path-or-url[/EXCEL].
- Multiple charts may be emitted as [chart-group][chart 1/3]{json-or-id}[/chart][chart 2/3]{json-or-id}[/chart][/chart-group].
- Chart column widths are fractions like 1/3, 1/2, 2/3, or 1/1.
- Inline viewer cards may be emitted as [banner tone="info" title="..."]body[/banner].
- Terminal style output may be emitted as [terminal]...[/terminal].
- Return files through file.output or artifact.publish; do not fake download URLs.
`.trim();

const record = (value: unknown): AgentRecord => value && typeof value === 'object' && !Array.isArray(value) ? value as AgentRecord : {};
const text = (value: unknown): string => String(value ?? '').trim();

export const parseAgentOutputBlocks = (markdown: string): AgentOutputBlock[] => {
  const blocks: AgentOutputBlock[] = [];
  const consumed: Array<[number, number]> = [];
  const mark = (start: number, end: number) => consumed.push([start, end]);

  for (const match of markdown.matchAll(/\[EXCEL\]([\s\S]*?)\[\/EXCEL\]/gi)) {
    blocks.push({ type: 'excel', path: text(match[1]) });
    mark(match.index || 0, (match.index || 0) + match[0].length);
  }

  for (const group of markdown.matchAll(/\[chart-group\]([\s\S]*?)\[\/chart-group\]/gi)) {
    const charts: AgentOutputBlock[] = [];
    const body = group[1] || '';
    for (const chart of body.matchAll(/\[chart\s+([^\]]+)\]([\s\S]*?)\[\/chart\]/gi)) {
      const columnSize = text(chart[1]);
      const raw = text(chart[2]);
      let spec: unknown = raw;
      try { spec = JSON.parse(raw); } catch { /* keep as text */ }
      charts.push({ type: 'chart', columnSize, spec, markdown: raw });
    }
    blocks.push({ type: 'chart-group', charts });
    mark(group.index || 0, (group.index || 0) + group[0].length);
  }

  for (const banner of markdown.matchAll(/\[banner([^\]]*)\]([\s\S]*?)\[\/banner\]/gi)) {
    const attrs = banner[1] || '';
    const title = attrs.match(/title="([^"]+)"/)?.[1] || 'Notice';
    const tone = attrs.match(/tone="([^"]+)"/)?.[1] || 'info';
    blocks.push({ type: 'banner', title, tone, subtitle: text(banner[2]) });
    mark(banner.index || 0, (banner.index || 0) + banner[0].length);
  }

  for (const terminal of markdown.matchAll(/\[terminal\]([\s\S]*?)\[\/terminal\]/gi)) {
    blocks.push({ type: 'terminal', text: terminal[1] || '' });
    mark(terminal.index || 0, (terminal.index || 0) + terminal[0].length);
  }

  const remaining = markdown
    .split('')
    .map((char, index) => consumed.some(([start, end]) => index >= start && index < end) ? '' : char)
    .join('')
    .trim();
  if (remaining) blocks.unshift({ type: 'markdown', markdown: remaining });
  return blocks;
};

export const renderAgentOutputBlocks = (blocks: AgentOutputBlock[]): string => blocks.map((block) => {
  if (block.type === 'markdown') return block.markdown;
  if (block.type === 'excel') return `[EXCEL]${block.path}[/EXCEL]`;
  if (block.type === 'terminal') return `[terminal]${block.text}[/terminal]`;
  if (block.type === 'banner') return `[banner tone="${block.tone || 'info'}" title="${block.title}"]${block.subtitle || ''}[/banner]`;
  if (block.type === 'artifact-card') return block.file.url ? `[${block.file.filename}](${block.file.url})` : block.file.filename;
  if (block.type === 'chart') return `[chart ${block.columnSize || '1/1'}]${typeof block.spec === 'string' ? block.spec : JSON.stringify(block.spec || record(block.metadata))}[/chart]`;
  if (block.type === 'chart-group') return `[chart-group]${renderAgentOutputBlocks(block.charts)}[/chart-group]`;
  return '';
}).filter(Boolean).join('\n\n');
