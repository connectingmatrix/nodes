import type { AgentRecord, AgentToolSpec } from './types';

export type AgentRuleViolation = {
  code: string;
  message: string;
  severity: 'error' | 'warning';
  path?: string;
};

const text = (value: unknown): string => String(value ?? '').trim();
const record = (value: unknown): AgentRecord =>
  value && typeof value === 'object' && !Array.isArray(value) ? (value as AgentRecord) : {};

const deniedSourcePatterns: Array<{ code: string; pattern: RegExp; message: string }> = [
  { code: 'node.child_process', pattern: /\bchild_process\b|\bexecSync\b|\bspawnSync\b|\bspawn\s*\(/i, message: 'Dynamic nodes cannot use process spawning APIs.' },
  { code: 'node.eval', pattern: /\beval\s*\(|\bnew\s+Function\s*\(/i, message: 'Dynamic nodes cannot evaluate generated source using eval or Function.' },
  { code: 'node.env.raw', pattern: /\bprocess\.env\b/i, message: 'Dynamic nodes must request credentials through the workflow credential host, not process.env.' },
  { code: 'node.install', pattern: /\bnpm\s+i\b|\byarn\s+add\b|\bpnpm\s+add\b|\bbun\s+add\b/i, message: 'Dynamic nodes cannot install packages during execution.' },
  { code: 'node.fs.absolute', pattern: /from\s+['"]node:fs['"]|require\(['"]fs['"]\)|require\(['"]node:fs['"]\)/i, message: 'Dynamic nodes cannot use raw filesystem access.' },
  { code: 'node.net.raw', pattern: /from\s+['"]node:(net|tls|http|https|dgram)['"]|require\(['"](net|tls|http|https|dgram)['"]\)/i, message: 'Dynamic nodes cannot open raw network sockets.' },
  { code: 'node.vm', pattern: /from\s+['"]node:vm['"]|require\(['"]vm['"]\)|require\(['"]node:vm['"]\)/i, message: 'Dynamic nodes cannot create nested vm sandboxes.' },
  { code: 'node.supabase.raw', pattern: /@supabase\/supabase-js|createClient\s*\(|\.from\s*\(/i, message: 'Dynamic nodes and agents cannot access Supabase directly. Use executeBackend -> Entities.' },
  { code: 'node.neo4j.raw', pattern: /neo4j|neogma|\bMATCH\s*\(|\bMERGE\s*\(|\bCREATE\s*\(/i, message: 'Dynamic nodes and agents cannot access Neo4j directly. Use executeBackend -> Entities.' },
];

export const chunkKnowledge = (input: unknown, options: { chunkSize?: number; overlap?: number } = {}) => {
  const chunkSize = Math.max(800, Number(options.chunkSize || 3500));
  const overlap = Math.max(0, Math.min(Number(options.overlap || 250), Math.floor(chunkSize / 3)));
  const values = Array.isArray(input) ? input : [input];
  const texts = values
    .flatMap((value) => {
      if (typeof value === 'string') return [value];
      const row = record(value);
      return [text(row.text || row.content || row.markdown || row.body || row.value)];
    })
    .map((value) => value.replace(/\r\n/g, '\n').trim())
    .filter(Boolean);

  const chunks: Array<{ id: string; index: number; text: string; size: number }> = [];
  for (const source of texts) {
    let start = 0;
    while (start < source.length) {
      const end = Math.min(source.length, start + chunkSize);
      const raw = source.slice(start, end);
      const lastBreak = raw.length === chunkSize ? Math.max(raw.lastIndexOf('\n\n'), raw.lastIndexOf('. '), raw.lastIndexOf('\n')) : -1;
      const textChunk = (lastBreak > chunkSize * 0.55 ? raw.slice(0, lastBreak + 1) : raw).trim();
      if (textChunk) chunks.push({ id: `knowledge_${chunks.length + 1}`, index: chunks.length, text: textChunk, size: textChunk.length });
      start += Math.max(1, textChunk.length - overlap);
    }
  }
  return chunks;
};

export const validateToolCatalog = (tools: AgentToolSpec[]): AgentRuleViolation[] => {
  const violations: AgentRuleViolation[] = [];
  const ids = new Set<string>();
  for (const tool of tools) {
    const id = text(tool.id || tool.name);
    if (!id) violations.push({ code: 'tool.id.required', message: 'Every agent tool must have an id.', severity: 'error' });
    if (ids.has(id)) violations.push({ code: 'tool.id.duplicate', message: `Duplicate agent tool id: ${id}`, severity: 'error' });
    ids.add(id);
    if (tool.mutates && tool.mutationPolicy === 'never') {
      violations.push({ code: 'tool.mutation.policy', message: `${id} mutates data but has mutationPolicy=never.`, severity: 'error' });
    }
  }
  return violations;
};

export const validateDynamicNodeSource = (sourceFiles: Record<string, string>): AgentRuleViolation[] => {
  const violations: AgentRuleViolation[] = [];
  for (const [path, source] of Object.entries(sourceFiles)) {
    const normalizedPath = text(path);
    if (!normalizedPath || normalizedPath.includes('..')) {
      violations.push({ code: 'node.path.invalid', message: `Invalid dynamic node source path: ${path}`, severity: 'error', path });
    }
    for (const denied of deniedSourcePatterns) {
      if (denied.pattern.test(source)) violations.push({ code: denied.code, message: denied.message, severity: 'error', path });
    }
  }
  return violations;
};

export const assertNoRuleErrors = (violations: AgentRuleViolation[]) => {
  const firstError = violations.find((violation) => violation.severity === 'error');
  if (firstError) throw new Error(firstError.message);
};

export const isMutatingTool = (tool: AgentToolSpec): boolean =>
  tool.mutates === true || tool.mutationPolicy === 'confirmation-required' || /create|update|delete|publish|attach|detach|link|unlink|execute|install|train|ingest|write|fix|debug/i.test(`${tool.id} ${tool.name} ${tool.description}`);
