import type { AgentToolSpec, CapabilityProviderInput, ConnectedNodeCommand } from './capability-types';
import { buildAgentTools, capabilityFromConnectedCommand, createDefaultAgentCapabilityRegistry, kindFromText, SYSTEM_AGENT_TOOLS, toToolSpec } from './capability-registry';
import { DEFAULT_AGENT_NODE_TOOLS } from './default-node-tools';

const record = (value: unknown): Record<string, unknown> => value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {};
const text = (value: unknown): string => String(value ?? '').trim();
const uniqueById = (items: AgentToolSpec[]): AgentToolSpec[] => Array.from(new Map(items.filter((item) => text(item.id)).map((item) => [item.id, item])).values());

export const kindFromModel = (modelId: string, schema?: { id?: string; name?: string; group?: string; documentation?: unknown } | null) => kindFromText([modelId, schema?.id, schema?.name, schema?.group, JSON.stringify(schema?.documentation || {})].join(' '));

export const toolSpecFromCommand = (input: { nodeId?: string | null; modelId?: string | null; spec: { toolName: string; toolDescription?: string | null; inputContract?: unknown; outputContract?: unknown; metadata?: Record<string, unknown> }; source?: AgentToolSpec['source'] }): AgentToolSpec => toToolSpec(capabilityFromConnectedCommand({ nodeId: input.nodeId || text(input.spec.metadata?.nodeId), modelId: input.modelId || text(input.spec.metadata?.modelId), toolName: input.spec.toolName, toolDescription: input.spec.toolDescription, inputContract: input.spec.inputContract, outputContract: input.spec.outputContract, metadata: input.spec.metadata }));

export const toolSpecFromSchema = (schema: { id?: string; name?: string; group?: string; documentation?: unknown; instruction?: unknown; fields?: unknown; inputs?: unknown; outputs?: unknown }): AgentToolSpec => {
  const metadata = { documentation: record(schema.documentation), instruction: record(schema.instruction), fields: schema.fields || {}, inputs: schema.inputs || {}, outputs: schema.outputs || {} };
  return toToolSpec({
    id: text(schema.id || schema.name || 'node'),
    name: text(schema.name || schema.id || 'Node'),
    description: text(record(schema.documentation).summary || record(schema.instruction).description || schema.name || schema.id || 'Workflow node.'),
    kind: kindFromModel(text(schema.id || schema.name), schema),
    source: 'catalog',
    modelId: text(schema.id || schema.name),
    capabilities: [`node.${text(schema.id || schema.name)}`],
    metadata,
    surfaces: ['chat'],
    mutates: /create|update|delete|write|publish|attach|link|unlink|execute|run|send|install|train|fix/i.test(JSON.stringify(metadata)),
    mutationPolicy: /create|update|delete|write|publish|attach|link|unlink|execute|run|send|install|train|fix/i.test(JSON.stringify(metadata)) ? 'confirmation-required' : 'never',
  });
};

export const mergeAgentToolCatalog = (...groups: AgentToolSpec[][]): AgentToolSpec[] => uniqueById(groups.flat()).sort((left, right) => left.name.localeCompare(right.name));

export const createDeclaredBackendAgentTools = (): AgentToolSpec[] => SYSTEM_AGENT_TOOLS.map(toToolSpec);

export const createAgentToolCatalog = (input: {
  surface?: CapabilityProviderInput['surface'];
  backendTools?: AgentToolSpec[];
  connectedCommands?: ConnectedNodeCommand[];
  mcpCapabilities?: AgentToolSpec[];
  includeBackendTools?: boolean;
  includeDefaultNodeTools?: boolean;
} = {}): AgentToolSpec[] => {
  const surface = input.surface || 'chat';
  const connected = (input.connectedCommands || []).map((command) => toToolSpec(capabilityFromConnectedCommand(command)));
  const system = input.includeBackendTools === false ? [] : SYSTEM_AGENT_TOOLS.map(toToolSpec).filter((tool) => surface === 'chat' || tool.id !== 'slash.execute' && tool.id !== 'slash.hints');
  const defaultNodes = input.includeDefaultNodeTools === false || surface !== 'chat' ? [] : DEFAULT_AGENT_NODE_TOOLS.map(toToolSpec);
  const explicit = input.backendTools || [];
  const mcp = input.mcpCapabilities || [];
  return mergeAgentToolCatalog(system, defaultNodes, connected, explicit, mcp);
};

export { buildAgentTools, createDefaultAgentCapabilityRegistry, DEFAULT_AGENT_NODE_TOOLS, SYSTEM_AGENT_TOOLS };
