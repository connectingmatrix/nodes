import type { AgentToolSpec } from './capability-types';

export const R20_AGENT_TOOL_KINDS = [
  'agent','chart','chat','code','control','database','entity','excel','file','knowledge','llm','node','tree','workflow'
] as const;

export const r20AdvancedAgentTools: AgentToolSpec[] = [
  { id: 'agent.gaps', name: 'Agent Gap Scanner', kind: 'agent', description: 'Identify remaining implementation gaps and convert them to tasks.' },
  { id: 'agent.task_graph', name: 'Task Graph Planner', kind: 'agent', description: 'Create a durable task graph with todos, risks, dependencies, and artifacts.' },
  { id: 'agent.memory.search.v2', name: 'Search Agent Memory', kind: 'knowledge', description: 'Retrieve persistent lessons, preferences, and domain facts.' },
  { id: 'agent.memory.write.v2', name: 'Write Agent Memory', kind: 'knowledge', description: 'Persist useful facts or user preferences after a run.' },
  { id: 'agent.memory.feedback', name: 'Record Agent Feedback', kind: 'agent', description: 'Store feedback so the agent can improve future behavior.' },
  { id: 'agent.swarm.plan.v2', name: 'Plan Agent Swarm', kind: 'agent', description: 'Plan a bounded specialist swarm and require confirmation before launch.' },
  { id: 'agent.swarm.v2', name: 'Launch Agent Swarm', kind: 'agent', description: 'Launch a confirmed specialist swarm with durable worker tracking.' },
  { id: 'agent.software.create.v2', name: 'Create Software System', kind: 'code', description: 'Generate a React/Electron/ThreeJS/Node system with SQLite manifest and files.' },
  { id: 'agent.software.run.v2', name: 'Run Software System', kind: 'code', description: 'Queue a sandbox or local runner build/run job for generated software.' },
  { id: 'agent.software.host.v2', name: 'Host Software System', kind: 'code', description: 'Create a hosted deployment record for generated software.' },
  { id: 'agent.local_runner.pair.v2', name: 'Pair Local Giga Runner', kind: 'control', description: 'Pair a local runner on port 10000 with user approval.' },
  { id: 'agent.local_runner.job.v2', name: 'Queue Local Runner Job', kind: 'control', description: 'Send an approved job to the local runner.' },
  { id: 'gis.world', name: 'World GIS Map', kind: 'chart', description: 'Create all-country world or country map specs with labels and legends.' },
  { id: 'gis.coordinates', name: 'Coordinate Plotter', kind: 'chart', description: 'Plot geocoordinates, routes, heatmaps, or point data.' },
  { id: 'gis.operation.v2', name: 'GIS Operation', kind: 'chart', description: 'Prepare GIS operations such as join, route, heatmap, buffer, or choropleth.' },
  { id: 'image.operation.v2', name: 'Image Operation', kind: 'file', description: 'Plan image editing, masking, resizing, annotation, composition, or upscaling.' },
  { id: 'image.sprite_sheet.v2', name: 'Sprite Sheet Generator', kind: 'file', description: 'Create sprite-sheet operation specs and artifacts.' },
  { id: 'platform.fix.plan.v2', name: 'Platform Fix Planner', kind: 'code', description: 'Plan safe fixes for the Giga platform with confirmation and runner gates.' },
];
