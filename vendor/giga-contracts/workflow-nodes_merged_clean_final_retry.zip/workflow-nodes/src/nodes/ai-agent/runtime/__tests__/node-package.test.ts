import { describe, expect, it } from 'vitest';
import { computeNodePackageChecksums, encodeNodePackage, validateNodePackage, NodePackage } from '../node-package';

describe('node package validation', () => {
  it('requires full v2 package shape', () => {
    const pkg: NodePackage = {
      filename: 'test-node.node',
      manifest: {
        packageFormat: 'giga.node.package/v2',
        id: 'pkg1', name: 'Test', version: '0.0.1', kind: 'node', modelId: 'test-node',
        schemaPath: 'schema.json', nodePath: 'node.ts', workerPath: 'worker.ts', readmePath: 'README.md', testsPath: 'tests/worker.test.ts', packageJsonPath: 'package.json', checksumsPath: 'checksums.json',
        dependencies: [], permissions: [], backendCommands: ['executeBackend'], rules: { allowNetwork: false, allowPackageInstall: false, requiresBackend: true }, createdAt: new Date().toISOString(),
      },
      files: [
        { path: 'schema.json', content: '{}' },
        { path: 'node.ts', content: 'export default {};' },
        { path: 'worker.ts', content: 'export const execute = async (_input, context) => context.executeBackend({ tool: "entity.operation", input: {} });' },
        { path: 'README.md', content: 'readme' },
        { path: 'tests/worker.test.ts', content: 'test("x", () => {})' },
        { path: 'package.json', content: '{"type":"module"}' },
        { path: 'checksums.json', content: '{}' },
      ],
    };
    pkg.files = pkg.files.map((file) => file.path === 'checksums.json' ? { ...file, content: JSON.stringify(computeNodePackageChecksums(pkg), null, 2) } : file);
    expect(validateNodePackage(pkg).ok).toBe(true);
    expect(encodeNodePackage(pkg)).toContain('giga.node.package/v2');
  });
});
