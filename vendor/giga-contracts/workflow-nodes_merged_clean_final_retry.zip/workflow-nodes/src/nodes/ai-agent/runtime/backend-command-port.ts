import type { AgentActionPlan, AgentRecord, AgentToolExecution, AgentToolSpec, BackendCommandPort } from './capability-types';

const started = () => Date.now();
const done = (action: AgentActionPlan, output: unknown, startedAt: number, logs: string[] = [], files: unknown[] = []): AgentToolExecution => ({ action, status: 'completed', output, logs, files: files as never, durationMs: Date.now() - startedAt });
const failed = (action: AgentActionPlan, error: unknown, startedAt: number): AgentToolExecution => ({ action, status: 'failed', error: error instanceof Error ? error.message : String(error || 'Backend command failed.'), durationMs: Date.now() - startedAt });
const record = (value: unknown): AgentRecord => value && typeof value === 'object' && !Array.isArray(value) ? value as AgentRecord : {};

export const executeBackendToolViaPort = async (input: {
  action: AgentActionPlan;
  tool: AgentToolSpec;
  port: BackendCommandPort;
  context?: AgentRecord;
}): Promise<AgentToolExecution> => {
  const startedAt = started();
  try {
    const result = await input.port.executeBackend({ tool: input.tool.id, operation: String(input.action.input.operation || input.action.input.action || ''), input: input.action.input, context: input.context });
    if (result.status === 'confirmation_required') return { action: input.action, status: 'confirmation_required', output: result.output, logs: result.logs, files: result.files, durationMs: Date.now() - startedAt };
    if (result.status === 'failed') return { action: input.action, status: 'failed', error: result.error || 'Backend command failed.', output: result.output, logs: result.logs, durationMs: Date.now() - startedAt };
    return done(input.action, result.output ?? record(result), startedAt, result.logs || [], result.files || []);
  } catch (error) {
    return failed(input.action, error, startedAt);
  }
};
