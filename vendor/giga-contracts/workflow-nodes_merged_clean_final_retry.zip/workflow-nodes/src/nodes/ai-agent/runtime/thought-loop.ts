import type { AgentActionPlan, AgentCarryContext, AgentLoopHooks, AgentPlan, AgentRecord, AgentThoughtLoopInput, AgentThoughtLoopOutput, AgentThoughtLoopPass, AgentToolExecution, AgentToolSpec } from './capability-types';
import { emptyCarryContext, mergeCarryContext, compactCarryContextForPrompt, todoFromUserMessage, updateCarryContextFromToolResult } from './agent-state';
import { AGENT_OUTPUT_FORMAT_SYSTEM_PROMPT, parseAgentOutputBlocks } from './output-contract';
import { buildCapabilityRoutedFallbackPlan } from './semantic-router';

const text = (value: unknown): string => String(value ?? '').trim();
const record = (value: unknown): AgentRecord => value && typeof value === 'object' && !Array.isArray(value) ? value as AgentRecord : {};
const safeJson = (value: unknown): string => {
  try {
    const json = JSON.stringify(value, null, 2);
    return typeof json === 'string' ? json : String(value ?? '');
  } catch {
    return String(value ?? '');
  }
};
const firstJsonObject = (input: string): unknown => {
  const trimmed = text(input);
  try { return JSON.parse(trimmed); } catch { /* scan */ }
  const start = trimmed.indexOf('{');
  const end = trimmed.lastIndexOf('}');
  if (start >= 0 && end > start) {
    try { return JSON.parse(trimmed.slice(start, end + 1)); } catch { /* fallback */ }
  }
  return {};
};

export const chunkKnowledge = (knowledge: unknown, options: { chunkSize?: number; overlap?: number } = {}) => {
  const size = Math.max(500, Number(options.chunkSize || 3500));
  const overlap = Math.max(0, Math.min(Number(options.overlap || 250), Math.floor(size / 2)));
  const values = Array.isArray(knowledge) ? knowledge : knowledge ? [knowledge] : [];
  const chunks: Array<{ id: string; index: number; text: string; metadata: AgentRecord }> = [];
  let sourceIndex = 0;
  for (const value of values) {
    const metadata = record(value);
    const source = typeof value === 'string' ? value : text(metadata.text || metadata.content || metadata.markdown || safeJson(value));
    for (let offset = 0; offset < source.length; offset += Math.max(1, size - overlap)) {
      const slice = source.slice(offset, offset + size);
      if (!slice.trim()) continue;
      chunks.push({ id: `knowledge_${sourceIndex}_${chunks.length}`, index: chunks.length, text: slice, metadata });
      if (offset + size >= source.length) break;
    }
    sourceIndex += 1;
  }
  return chunks;
};

export const validateToolCatalog = (tools: AgentToolSpec[]) => {
  const seen = new Set<string>();
  const violations: Array<{ severity: 'error' | 'warning'; message: string }> = [];
  for (const tool of tools) {
    if (!tool.id) violations.push({ severity: 'error', message: 'Tool is missing id.' });
    if (seen.has(tool.id)) violations.push({ severity: 'warning', message: `Duplicate tool ${tool.id}; last definition wins.` });
    seen.add(tool.id);
    if (!tool.kind) violations.push({ severity: 'error', message: `Tool ${tool.id} is missing kind.` });
    if (tool.mutationPolicy === 'always-allowed' && tool.risk && ['destructive', 'admin', 'swarm', 'package-install', 'external-network'].includes(tool.risk)) {
      violations.push({ severity: 'error', message: `Tool ${tool.id} is risky and cannot be always-allowed.` });
    }
  }
  return violations;
};

const normalizePlan = (raw: unknown, fallbackIntent: string): AgentPlan => {
  const data = record(raw);
  const actions = Array.isArray(data.actions) ? data.actions.map((item, index) => {
    const row = record(item);
    return {
      id: text(row.id || `action_${index + 1}`),
      tool: text(row.tool || row.toolId || row.name),
      reason: text(row.reason || row.description || row.intent || 'Run tool.'),
      input: record(row.input || row.args || row.payload),
      depends_on: Array.isArray(row.depends_on) ? row.depends_on.map(String) : undefined,
    } as AgentActionPlan;
  }).filter((action) => action.tool) : [];
  return {
    intent: text(data.intent || fallbackIntent || 'agent_work'),
    requiresConfirmation: data.requiresConfirmation === true || data.requires_confirmation === true,
    actions,
    finalResponseInstruction: text(data.finalResponseInstruction || data.final_response_instruction || data.final || ''),
    todo: Array.isArray(data.todo) ? data.todo.map((item) => record(item) as never) : undefined,
    ambiguity: Array.isArray(data.ambiguity) ? data.ambiguity.map(String) : undefined,
  };
};

const findTool = (tools: AgentToolSpec[], id: string) => tools.find((tool) => tool.id === id || tool.name === id || tool.modelId === id || (tool.aliases || []).includes(id));
const isMutatingTool = (tool: AgentToolSpec) => tool.mutates === true || tool.mutationPolicy === 'confirmation-required';
const hasMutatingActions = (plan: AgentPlan, tools: AgentToolSpec[]) => plan.actions.some((action) => {
  const tool = findTool(tools, action.tool);
  return !tool || isMutatingTool(tool);
});
const invalidPlannedAction = (plan: AgentPlan, tools: AgentToolSpec[], message: string): string => {
  const messageText = text(message).toLowerCase();
  const workflowRequested = /\b(workflow|cypher|graph|node)\b/.test(messageText);
  const treeRequested = /\b(channel|category|subject|post|tree)\b/.test(messageText);
  const linkRequested = /\b(link|unlink|attach|detach)\b/.test(messageText);
  const unlinkRequested = /\b(unlink|detach)\b/.test(messageText);
  for (const action of plan.actions) {
    const tool = findTool(tools, action.tool);
    if (!tool) return `unknown tool ${action.tool}`;
    if (treeRequested && !workflowRequested && tool.kind === 'workflow') return 'workflow tool does not match tree/entity request';
    if ((tool.id === 'entity.operation' || tool.id === 'tree.operation') && !text(record(action.input).entity)) {
      return `${tool.id} requires entity`;
    }
    if (tool.id === 'entity.operation' || tool.id === 'tree.operation') {
      const input = record(action.input);
      const entity = text(input.entity);
      const entityName = entity ? `${entity[0].toUpperCase()}${entity.slice(1).toLowerCase()}` : '';
      const operation = text(input.operation || input.action).toLowerCase();
      const payload = record(input.payload || input.data || input.values);
      if (operation === 'create' && (entityName === 'Channel' || entityName === 'Category') && !text(payload.slug)) {
        return `${tool.id} create ${entityName} requires data.slug`;
      }
      if (linkRequested) {
        const linkOps = unlinkRequested ? ['unlink', 'detach'] : ['link', 'attach', 'unlink', 'detach'];
        if (!linkOps.includes(operation)) return `${tool.id} must use link/attach operation for requested relation change`;
      }
    }
    if (tool.id === 'workflow.operation' && !text(record(action.input).operation)) {
      return 'workflow.operation requires operation';
    }
  }
  return '';
};

const planPrompt = (input: AgentThoughtLoopInput, passIndex: number, previousResults: AgentToolExecution[], carry: AgentCarryContext, knowledgeChunks: ReturnType<typeof chunkKnowledge>) => {
  const toolLines = input.tools.map((tool) => `- ${tool.id}: kind=${tool.kind} source=${tool.source || 'unknown'} risk=${tool.risk || 'none'} mutates=${tool.mutates === true} permissions=${(tool.permissions || []).join(',')} capabilities=${(tool.capabilities || []).join(', ')} examples=${(tool.examples || []).map((example) => example.user).join(' | ')} :: ${tool.description}`).join('\n');
  const results = previousResults.slice(-25).map((result) => `- ${result.action.id} ${result.action.tool} ${result.status}${result.error ? ` error=${result.error}` : ''} output=${safeJson(result.output).slice(0, 1800)}`).join('\n');
  const knowledge = knowledgeChunks.slice(0, 10).map((chunk) => `### ${chunk.id}\n${chunk.text.slice(0, 1800)}`).join('\n\n');
  const outputContract = input.surface === 'chat' ? AGENT_OUTPUT_FORMAT_SYSTEM_PROMPT : '';
  return `${input.systemPrompt || ''}\n\nYou are the Giga AI Agent. Produce only JSON with shape {"intent":"...","requiresConfirmation":false,"ambiguity":[],"todo":[],"actions":[{"id":"action_1","tool":"entity.operation","reason":"...","input":{}}],"finalResponseInstruction":"..."}.\n\nNon-negotiable rules:\n- Use only declared tools from the capability manifest.\n- Do not hardcode business cases; infer operations from capability names, schemas, permissions, examples, and current context.\n- Agents and workflow nodes cannot access Supabase, Neo4j, or raw databases. Database work must go through executeBackend -> Entities.\n- In workflow surface, use connected-node tools plus system tools only; do not invent disconnected node tools.\n- In chat surface, you may use system tools and default node tools.\n- Confirm before destructive actions, swarm launches, package installation, root/admin operations, external network/database connection, large-cost work, and ambiguous mutations.\n- Post entities can be created/read/updated/deleted but cannot be linked or unlinked.\n- Break large infrastructure requests into smaller workflows, nodes, and delegated agents.\n- Keep and update a todo list. Carry important facts across passes.\n- For large files: upload first, ingest small files inline, stream large CSV/Excel into inline SQL, extract zip file trees, and process images/PDFs through file tools.\n- For artifacts: publish through artifact.publish so user/org artifact channel posts are updated once at final response time.\n- If the user mentions Giga, use knowledge tools and Giga knowledge before answering.\n- Match planned actions directly to the user task scope; for channel tasks use channel tools, not workflow or agent tools.\n${outputContract ? '- Use the output contract below from the first response.\n- Treat the output contract as response-format guidance only; never convert it into a workflow/agent creation task.\n\n' + outputContract + '\n\n' : ''}Surface: ${input.surface || 'chat'}\nConfirmed: ${input.confirmed === true}\nAllow swarm: ${input.allowSwarm === true}\nAllow dynamic nodes: ${input.allowDynamicNodes !== false}\n\nUser task:\n${input.message}\n\nDeclared tools:\n${toolLines}\n\nPrevious results:\n${results || 'none'}\n\nCarry context:\n${compactCarryContextForPrompt(carry)}\n\nKnowledge chunks:\n${knowledge || 'none'}\n\nPass index: ${passIndex}`;
};

const markdownFromResults = (input: AgentThoughtLoopInput, plan: AgentPlan, results: AgentToolExecution[], files: unknown[], carry: AgentCarryContext) => {
  if (!results.length) return plan.finalResponseInstruction || 'I can help with that.';
  const lines = results.map((result) => {
    const output = record(result.output);
    const summary = text(output.summary || output.message || output.markdown || output.text || output.name || output.id) || safeJson(result.output).slice(0, 400);
    return result.status === 'failed' ? `- ${result.action.reason}: failed — ${result.error || 'unknown error'}` : `- ${result.action.reason}: ${summary}`;
  });
  const fileLines = [...files, ...carry.artifacts].map(record).filter((file) => file.filename || file.url || file.path).map((file) => `- ${text(file.filename || file.name || 'file')}${file.url ? `: ${text(file.url)}` : file.path ? `: ${text(file.path)}` : ''}`);
  const todoLines = carry.todos.length ? ['\nTodo status:', ...carry.todos.slice(-12).map((todo) => `- ${todo.status}: ${todo.title}`)] : [];
  return [`Completed ${results.length} action${results.length === 1 ? '' : 's'}:`, ...lines, ...(fileLines.length ? ['\nFiles:', ...fileLines] : []), ...todoLines].join('\n');
};

export const runAgentThoughtLoop = async (input: AgentThoughtLoopInput, hooks: AgentLoopHooks): Promise<AgentThoughtLoopOutput> => {
  const errors = validateToolCatalog(input.tools).filter((item) => item.severity === 'error');
  if (errors.length) throw new Error(errors[0].message);
  const maxPasses = input.surface === 'workflow' ? 1 : Math.max(1, Math.min(Number(input.maxPasses || 10), 30));
  const maxActionsPerPass = Math.max(1, Math.min(Number(input.maxActionsPerPass || 10), 40));
  const confirmationPolicy = input.confirmationPolicy || 'mutations-only';
  const outputFormatPrompt = input.surface === 'workflow' ? 'Return valid JSON only.' : input.outputFormatSeed || AGENT_OUTPUT_FORMAT_SYSTEM_PROMPT;
  const knowledgeChunks = chunkKnowledge(input.knowledge || [], { chunkSize: 3500, overlap: 250 });
  const logs: string[] = [];
  const files: unknown[] = [];
  const passes: AgentThoughtLoopPass[] = [];
  const allResults: AgentToolExecution[] = [];
  let carry = mergeCarryContext(emptyCarryContext(), { todos: todoFromUserMessage(input.message) });
  if (Array.isArray(input.attachments) && input.attachments.length) carry = mergeCarryContext(carry, { facts: { attachments: input.attachments } });
  let currentPlan = input.pendingPlan || buildCapabilityRoutedFallbackPlan(input.message, input.tools);
  if (!input.pendingPlan && !input.confirmed && !currentPlan.actions.length && (currentPlan.intent === 'common_chat' || currentPlan.intent === 'general_chat')) {
    const markdown = currentPlan.finalResponseInstruction || 'I can help with that.';
    return {
      status: 'completed',
      message: markdown,
      markdown,
      plan: currentPlan,
      passes,
      actionResults: [],
      files: files as never,
      logs,
      carryContext: carry,
    };
  }
  if (input.pendingPlan && !input.confirmed && hasMutatingActions(input.pendingPlan, input.tools)) {
    return { status: 'confirmation_required', message: 'Please confirm the pending mutating actions.', markdown: 'Please confirm before I run the pending mutating actions.', plan: input.pendingPlan, passes, actionResults: [], files: [], logs, carryContext: carry, pendingPlan: input.pendingPlan };
  }

  for (let passIndex = 0; passIndex < maxPasses; passIndex += 1) {
    const prompt = planPrompt(input, passIndex, allResults, carry, knowledgeChunks);
    if (input.surface !== 'workflow') {
      try {
        const raw = await hooks.callLLM({ messages: [...(input.messages || []), { role: 'system', content: outputFormatPrompt }, { role: 'user', content: prompt }], tools: input.tools, context: { ...(input.context || {}), requestId: input.requestId || null }, passIndex, previousResults: allResults, carryContext: carry });
        const llmPlan = normalizePlan(firstJsonObject(raw), currentPlan.intent);
        const invalid = invalidPlannedAction(llmPlan, input.tools, input.message);
        if (invalid) {
          logs.push(`planner produced invalid plan (${invalid}); using capability router.`);
          currentPlan = buildCapabilityRoutedFallbackPlan(input.message, input.tools);
        } else if (llmPlan.actions.length || llmPlan.finalResponseInstruction || llmPlan.ambiguity?.length) {
          currentPlan = llmPlan;
        }
      } catch (error) {
        logs.push(`planner failed; using manifest router: ${error instanceof Error ? error.message : 'unknown planner error'}`);
      }
    }
    currentPlan.actions = currentPlan.actions.slice(0, maxActionsPerPass);
    if (currentPlan.todo?.length) carry = mergeCarryContext(carry, { todos: currentPlan.todo });

    const needsConfirmation = currentPlan.requiresConfirmation === true || (confirmationPolicy !== 'never' && !input.confirmed && (confirmationPolicy === 'always' || hasMutatingActions(currentPlan, input.tools)));
    const launchingSwarm = currentPlan.actions.some((action) => /swarm|delegate/i.test(`${action.tool} ${safeJson(action.input)}`));
    const installingPackage = currentPlan.actions.some((action) => /install|package|dependency/i.test(`${action.tool} ${safeJson(action.input)}`));
    const rootAdmin = currentPlan.actions.some((action) => /root|super.?admin|admin|deactivate|reset.?login/i.test(`${action.tool} ${safeJson(action.input)}`));
    if (needsConfirmation || (launchingSwarm && !input.confirmed) || (installingPackage && !input.confirmed) || (rootAdmin && !input.confirmed)) {
      return {
        status: 'confirmation_required',
        message: 'Please confirm before I execute the planned actions.',
        markdown: `I prepared ${currentPlan.actions.length} action(s). Please confirm to run them.${launchingSwarm ? '\n\nThis includes swarm/delegation.' : ''}${installingPackage ? '\n\nThis may install allowlisted packages in the executor sandbox.' : ''}${rootAdmin ? '\n\nThis includes root/admin-sensitive work.' : ''}`,
        plan: currentPlan,
        passes,
        actionResults: allResults,
        files: files as never,
        logs,
        carryContext: carry,
        pendingPlan: currentPlan,
      };
    }

    const passResults: AgentToolExecution[] = [];
    for (const action of currentPlan.actions) {
      const tool = findTool(input.tools, action.tool);
      if (!tool) {
        passResults.push({ action, status: 'failed', error: `Unknown or undeclared tool: ${action.tool}` });
        continue;
      }
      const started = Date.now();
      const result = await hooks.executeTool({
        action,
        tool,
        context: { ...(input.context || {}), surface: input.surface || 'chat' },
        previousResults: [...allResults, ...passResults],
        carryContext: carry,
      });
      passResults.push({ ...result, durationMs: result.durationMs ?? Date.now() - started });
      carry = updateCarryContextFromToolResult(carry, result);
      if (result.logs?.length) logs.push(...result.logs);
      if (result.files?.length) files.push(...result.files);
    }
    allResults.push(...passResults);
    const observations = passResults.map((result) => `${result.action.id}: ${result.status}${result.error ? ` - ${result.error}` : ''}`);
    const pass: AgentThoughtLoopPass = { index: passIndex, prompt, plan: currentPlan, toolResults: passResults, observations, carryContext: carry };
    passes.push(pass);
    await hooks.onPass?.(pass);
    if (hooks.listenWorkflowLogs) {
      const workflowAction = currentPlan.actions.find((action) => action.tool === 'workflow.operation');
      const inputRow = record(workflowAction?.input);
      const live = await hooks.listenWorkflowLogs({ workflowId: text(inputRow.workflowId || inputRow.workflow_id), runId: text(inputRow.runId || inputRow.run_id) });
      if (live.length) logs.push(...live);
    }
    if (!currentPlan.actions.length || passResults.some((result) => result.status === 'failed' || result.status === 'confirmation_required')) break;
    currentPlan = { intent: 'continue', actions: [], finalResponseInstruction: 'Create the final answer from accumulated results.', todo: carry.todos };
  }

  let markdown = markdownFromResults(input, currentPlan, allResults, files, carry);
  parseAgentOutputBlocks(markdown);
  const status = allResults.some((result) => result.status === 'failed') ? 'failed' : allResults.some((result) => result.status === 'confirmation_required') ? 'confirmation_required' : 'completed';
  return { status, message: markdown, markdown, plan: currentPlan, passes, actionResults: allResults, files: files as never, logs, carryContext: carry };
};
