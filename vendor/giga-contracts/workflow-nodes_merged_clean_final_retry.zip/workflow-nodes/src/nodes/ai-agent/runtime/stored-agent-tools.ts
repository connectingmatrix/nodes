import type { AgentToolSpec } from './types';

export const storedAgentToolSpecs: AgentToolSpec[] = [
  { id: 'agent.capabilities', kind: 'agent', name: 'List stored AI agent capabilities', description: 'List available persisted AI-agent operations.', inputSchema: { type: 'object' } },
  { id: 'agent.operation', kind: 'agent', name: 'Manage stored AI agents', description: 'Create, update, delete, list, or read reusable AI agents.', inputSchema: { type: 'object' } },
  { id: 'agent.run', kind: 'agent', name: 'Run stored AI agent', description: 'Run a reusable AI agent through the OpenAI Agents SDK compatible runtime.', inputSchema: { type: 'object', required: ['agentId','message'] } },
  { id: 'agent.attach', kind: 'agent', name: 'Attach AI agent', description: 'Attach a reusable AI agent to chat/workflow attachment table.', inputSchema: { type: 'object', required: ['chatId','agentId'] } },
];
