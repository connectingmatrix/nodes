import type { AgentActionPlan, AgentPlan, AgentRecord, AgentToolSpec } from './capability-types';

const text = (value: unknown): string => String(value ?? '').trim();
const normalize = (value: unknown): string => text(value).toLowerCase().replace(/[_./:-]+/g, ' ');
const words = (value: unknown): string[] => normalize(value).split(/[^a-z0-9]+/).filter((word) => word.length > 1);
const unique = <T>(values: T[]): T[] => Array.from(new Set(values));
const safeJson = (value: unknown): string => { try { return JSON.stringify(value); } catch { return ''; } };

export type CapabilityScore = {
  tool: AgentToolSpec;
  score: number;
  reasons: string[];
};

export const tokenizeCapability = (tool: AgentToolSpec): string[] => {
  const exampleText = (tool.examples || []).map((example) => `${example.user} ${safeJson(example.args)} ${example.expected || ''}`).join(' ');
  return unique(words([
    tool.id,
    tool.name,
    tool.description,
    tool.kind,
    tool.source,
    ...(tool.aliases || []),
    ...(tool.capabilities || []),
    ...(tool.permissions || []),
    exampleText,
    safeJson(tool.inputContract),
    safeJson(tool.metadata),
  ].join(' ')));
};

export const rankCapabilitiesForMessage = (message: string, tools: AgentToolSpec[], limit = 8): CapabilityScore[] => {
  const messageTokens = new Set(words(message));
  if (!messageTokens.size) return [];
  const messageText = normalize(message);
  const workflowRequested = /\bworkflow|cypher|node|graph\b/.test(messageText);
  const scored = tools.map((tool) => {
    const tokens = tokenizeCapability(tool);
    const signature = normalize([tool.id, tool.name, tool.description, (tool.capabilities || []).join(' ')].join(' '));
    const reasons: string[] = [];
    let score = 0;
    for (const token of tokens) {
      if (messageTokens.has(token)) {
        score += token.length > 5 ? 2 : 1;
        reasons.push(token);
      }
    }
    for (const example of tool.examples || []) {
      const exampleTokens = new Set(words(example.user));
      let overlap = 0;
      for (const token of messageTokens) if (exampleTokens.has(token)) overlap += 1;
      if (overlap >= 2) {
        score += overlap * 2;
        reasons.push(`example:${example.user.slice(0, 40)}`);
      }
    }
    if (tool.kind === 'entity' && /create|delete|update|read|link|unlink|attach|detach|channel|category|subject|post|user|organisation|organization|tree/.test(messageText)) score += 1;
    if (tool.kind === 'workflow' && /workflow|run|execute|publish|debug|fix|logs|delegate|swarm/.test(messageText)) score += 1;
    if (tool.kind === 'chart' && /chart|plot|map|visual|graph/.test(messageText)) score += 1;
    if (tool.kind === 'file' && /file|csv|excel|pdf|zip|attachment|download/.test(messageText)) score += 1;
    if (workflowRequested) score += /workflow|execute workflow|cypher|graph/.test(signature) ? 14 : -3;
    if (!workflowRequested && /channel/.test(messageText)) score += signature.includes('channel') ? 8 : -2;
    if (!workflowRequested && /category/.test(messageText)) score += signature.includes('category') ? 8 : -2;
    if (!workflowRequested && /subject/.test(messageText)) score += signature.includes('subject') ? 8 : -2;
    if (!workflowRequested && /post/.test(messageText)) score += signature.includes('post') ? 8 : -2;
    if (/\bdelete|remove\b/.test(messageText) && /delete/.test(signature)) score += 4;
    if (/name prefix|name_prefix|prefix/.test(messageText) && /name prefix|name_prefix|prefix/.test(signature)) score += 3;
    return { tool, score, reasons: unique(reasons) };
  }).filter((item) => item.score > 0);
  return scored.sort((left, right) => right.score - left.score || left.tool.id.localeCompare(right.tool.id)).slice(0, limit);
};

const commonMessagePattern = /^\s*(hi|hello|hey|thanks|thank you|good morning|good afternoon|good evening|ok|okay)\s*[.!?]*\s*$/i;
const generalChatPattern = /\b(what can you do|what can you help|quick intro|how are you|how does|explain|best practices|summarize|when should)\b/i;
const chartPattern = /\b(chart|plot|bar chart|line chart|pie chart|donut|scatter|bubble|radar|heatmap|histogram|map)\b/i;
const mutationPattern = /\b(create|add|new|update|edit|rename|delete|remove|link|unlink|attach|detach|move|publish|execute|run|clean)\b/i;
const unsupportedPostLinkPattern = /\b(post)\b.*\b(link|unlink)\b.*\b(unsupported|not supported)\b/i;
const treeIntentPattern = /\b(channel|category|subject|post|user tree|tree)\b/i;
const workflowCreatePattern = /\b(create|build|generate|new)\b/i;
const quotePattern = /"([^"]+)"/g;

const slug = (value: string): string =>
  value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);

const quoted = (message: string): string[] => {
  const values: string[] = [];
  for (const match of message.matchAll(quotePattern)) {
    const value = text(match[1]);
    if (value) values.push(value);
  }
  return values;
};

const routerActionName = (keyword: string, operation: string): string => `${operation}_${keyword === 'tree' ? 'channel' : keyword}`;
const entityNameForKeyword = (keyword: string): string =>
  keyword === 'channel' || keyword === 'tree'
    ? 'Channel'
    : keyword === 'category'
    ? 'Category'
    : keyword === 'subject'
    ? 'Subject'
    : 'Post';

const entityOperationInput = (keyword: string, operation: string, first: string, second: string): AgentRecord => {
  const entity = entityNameForKeyword(keyword);
  if (operation === 'create') {
    if (entity === 'Channel' || entity === 'Category') return { entity, operation: 'create', data: { name: first, slug: slug(first) } };
    if (entity === 'Subject') return { entity, operation: 'create', data: { name: first } };
    return { entity, operation: 'create', data: { title: first } };
  }
  if (operation === 'update') {
    if (entity === 'Post') return { entity, operation: 'update', id: first, data: { title: second || first } };
    return { entity, operation: 'update', id: first, data: { name: second || first } };
  }
  if (operation === 'delete') return { entity, operation: 'delete', id: first };
  if (operation === 'read') return { entity, operation: 'read', where: entity === 'Post' ? { title: first } : { name: first } };
  return { entity, operation: 'read', where: entity === 'Post' ? { title: first } : { name: first } };
};

const treeRelationInput = (messageText: string, operation: string, first: string, second: string): AgentRecord | null => {
  if (operation !== 'link' && operation !== 'unlink') return null;
  if (/subject/.test(messageText) && /channel/.test(messageText)) {
    return {
      entity: 'Channel',
      operation,
      parentEntity: 'Channel',
      childEntity: 'Subject',
      relation: 'subjects',
      parentName: second,
      childName: first,
    };
  }
  if (/category/.test(messageText) && /channel/.test(messageText)) {
    return {
      entity: 'Channel',
      operation,
      parentEntity: 'Channel',
      childEntity: 'Category',
      relation: 'categories',
      parentName: second,
      childName: first,
    };
  }
  if (/subject/.test(messageText) && /category/.test(messageText)) {
    return {
      entity: 'Category',
      operation,
      parentEntity: 'Category',
      childEntity: 'Subject',
      relation: 'subjects',
      parentName: second,
      childName: first,
    };
  }
  if (/channel/.test(messageText)) {
    return {
      entity: 'Channel',
      operation,
      parentEntity: 'Channel',
      childEntity: 'Channel',
      relation: 'children',
      parentName: first,
      childName: second,
    };
  }
  return null;
};

const routerActionParameters = (keyword: string, action: string, first: string, second: string): AgentRecord => {
  if (action === 'create_channel') return { channel: { name: first, slug: slug(first) } };
  if (action === 'update_channel') return { channel_name: first, name: second || first };
  if (action === 'delete_channel' || action === 'read_channel') return { name: first };
  if (action === 'link_channel' || action === 'unlink_channel') return { parent_channel_name: first, channel_name: second };
  if (action === 'create_category') return { category: { name: first, slug: slug(first) } };
  if (action === 'update_category') return { category_name: first, name: second || first };
  if (action === 'delete_category' || action === 'read_category') return { category_name: first };
  if (action === 'link_category' || action === 'unlink_category') return { channel_name: first, category_name: second };
  if (action === 'create_subject') return { name: first };
  if (action === 'update_subject') return { subject_name: first, name: second || first };
  if (action === 'delete_subject' || action === 'read_subject') return { subject_name: first };
  if (action === 'link_subject' || action === 'unlink_subject') return { category_name: first, subject_name: second };
  if (action === 'create_post') return { title: first };
  if (action === 'update_post') return { post_title: first, title: second || first };
  if (action === 'delete_post' || action === 'read_post') return { post_title: first };
  return {};
};

export const buildCapabilityRoutedFallbackPlan = (message: string, tools: AgentToolSpec[]): AgentPlan => {
  const messageText = normalize(message);
  const mutationRequested = mutationPattern.test(messageText);
  const chartRequested = chartPattern.test(messageText);
  if (unsupportedPostLinkPattern.test(messageText)) {
    return {
      intent: 'general_chat',
      actions: [],
      finalResponseInstruction:
        'Post linking and unlinking are unsupported in Giga. You can create, read, update, and delete posts under subjects.',
    };
  }
  if (commonMessagePattern.test(message)) {
    return {
      intent: 'common_chat',
      actions: [],
      finalResponseInstruction:
        'In Giga, I can help with channels, categories, subjects, posts, workflows, charts, and knowledge tasks.',
    };
  }
  if (generalChatPattern.test(message) && !mutationRequested && !chartRequested) {
    return {
      intent: 'general_chat',
      actions: [],
      finalResponseInstruction:
        'Giga supports channels, categories, subjects, posts, workflows, charts, and knowledge operations. Tell me the exact task and I will execute it.',
    };
  }
  const workflowRequested = /\b(workflow|cypher|node|graph)\b/i.test(message);
  const executionRequested = /\b(run|execute|start)\b/i.test(message);
  if (workflowRequested) {
    const workflowTool =
      tools.find((tool) => normalize(tool.id) === 'workflow operation') ||
      tools.find((tool) => /workflow operation/.test(normalize(tool.name))) ||
      tools.find((tool) => /\bworkflow\b/.test(normalize([tool.id, tool.name, tool.description].join(' '))));
    if (workflowTool) {
      const values = quoted(message);
      const workflowName = values[0] || 'Giga Workflow';
      const operation = /\b(delete|remove|cleanup)\b/.test(messageText)
        ? 'delete'
        : /\b(publish)\b/.test(messageText)
        ? 'publish'
        : /\b(debug|fix)\b/.test(messageText)
        ? 'debug'
        : /\b(list|show|get|read|find|search)\b/.test(messageText)
        ? 'list'
        : 'create';
      const actions: AgentActionPlan[] = [
        {
          id: 'capability_1',
          tool: workflowTool.id,
          reason: `Selected workflow operation tool for message: ${message}`,
          input: {
            operation,
            prompt: message,
            workflowPrompt: message,
            workflowName,
            saveMode: 'create',
          } as AgentRecord,
        },
      ];
      if (executionRequested && operation === 'create') {
        actions.push({
          id: 'capability_2',
          tool: workflowTool.id,
          reason: 'Execute the workflow created in the previous step.',
          input: {
            operation: 'run',
            workflowActionId: 'capability_1',
            prompt: message,
          } as AgentRecord,
          depends_on: ['capability_1'],
        });
      }
      return {
        intent: 'capability_routed',
        requiresConfirmation: mutationRequested,
        actions,
        finalResponseInstruction: 'Use the workflow operation result to answer clearly.',
      };
    }
  }
  if (!workflowRequested && treeIntentPattern.test(messageText)) {
    const routeKeyword = /channel/.test(messageText)
      ? 'channel'
      : /category/.test(messageText)
      ? 'category'
      : /subject/.test(messageText)
      ? 'subject'
      : /post/.test(messageText)
      ? 'post'
      : 'tree';
    const preferredRouter =
      tools.find((tool) => /action-router/.test(normalize(tool.id)) && new RegExp(routeKeyword).test(normalize(tool.name))) ||
      tools.find((tool) => /action-router/.test(normalize(tool.id)) && /tree/.test(normalize(tool.name))) ||
      null;
    if (preferredRouter) {
      const values = quoted(message);
      const first = values[0] || 'giga-auto';
      const second = values[1] || `${first}-updated`;
      const actions: AgentActionPlan[] = [];
      const pushAction = (operation: string, position: number, primary = first, secondary = second) => {
        const name = routerActionName(routeKeyword, operation);
        actions.push({
          id: `capability_${position}`,
          tool: preferredRouter.id,
          reason: `Selected tree action router for message: ${message}`,
          input: {
            prompt: message,
            action: name,
            parameters: routerActionParameters(routeKeyword, name, primary, secondary),
            selectedCapability: preferredRouter.id,
          } as AgentRecord,
        });
      };
      const multiCreate = /\bparent\b/.test(messageText) && /\bchild\b/.test(messageText) && values.length >= 2;
      const hasCreate = /\b(create|add|new)\b/.test(messageText);
      const hasUpdate = /\b(update|edit|rename|change)\b/.test(messageText);
      const hasLink = /\b(link|attach)\b/.test(messageText);
      const hasUnlink = /\b(unlink|detach)\b/.test(messageText);
      const hasDelete = /\b(delete|remove)\b/.test(messageText);
      const hasRead = /\b(read|list|show|get|fetch|find|search)\b/.test(messageText);
      let index = 1;
      if (hasCreate && multiCreate) {
        pushAction('create', index, first);
        index += 1;
        pushAction('create', index, second);
        index += 1;
      } else if (hasCreate) {
        pushAction('create', index, first);
        index += 1;
      }
      if (hasUpdate) {
        pushAction('update', index, first, second);
        index += 1;
      }
      if (hasLink) {
        pushAction('link', index, first, second);
        index += 1;
      }
      if (hasUnlink) {
        pushAction('unlink', index, first, second);
        index += 1;
      }
      if (hasDelete) {
        pushAction('delete', index, second || first);
        index += 1;
      }
      if (hasRead && !hasCreate && !hasUpdate && !hasLink && !hasUnlink && !hasDelete) {
        pushAction('read', index, first);
      }
      if (!actions.length) {
        actions.push({
          id: 'capability_1',
          tool: preferredRouter.id,
          reason: `Selected tree action router for message: ${message}`,
          input: { prompt: message, operation: 'auto', selectedCapability: preferredRouter.id } as AgentRecord,
        });
      }
      return {
        intent: 'capability_routed',
        requiresConfirmation: mutationRequested,
        actions,
        finalResponseInstruction: 'Use the action-router result to answer clearly.',
      };
    }
    const entityTool = tools.find((tool) => normalize(tool.id) === 'entity operation' || normalize(tool.name) === 'entity operation') || null;
    if (entityTool) {
      const values = quoted(message);
      const first = values[0] || 'giga-auto';
      const second = values[1] || `${first}-updated`;
      const hasCreate = /\b(create|add|new)\b/.test(messageText);
      const hasUpdate = /\b(update|edit|rename|change)\b/.test(messageText);
      const hasLink = /\b(link|attach)\b/.test(messageText);
      const hasUnlink = /\b(unlink|detach)\b/.test(messageText);
      const hasDelete = /\b(delete|remove)\b/.test(messageText);
      const hasRead = /\b(read|list|show|get|fetch|find|search)\b/.test(messageText);
      const operation = hasCreate
        ? 'create'
        : hasUpdate
        ? 'update'
        : hasLink
        ? 'link'
        : hasUnlink
        ? 'unlink'
        : hasDelete
        ? 'delete'
        : hasRead
        ? 'read'
        : 'read';
      const relationInput = treeRelationInput(messageText, operation, first, second);
      return {
        intent: 'capability_routed',
        requiresConfirmation: mutationRequested,
        actions: [
          {
            id: 'capability_1',
            tool: entityTool.id,
            reason: `Selected entity operation for tree intent in message: ${message}`,
            input: relationInput || entityOperationInput(routeKeyword, operation, first, second),
          },
        ],
        finalResponseInstruction: 'Use the entity operation result to answer clearly.',
      };
    }
  }
  const ranked = rankCapabilitiesForMessage(message, tools, 1);
  const actions: AgentActionPlan[] = ranked.map((score, index) => ({
    id: `capability_${index + 1}`,
    tool: score.tool.id,
    reason: `Selected from capability manifest: ${score.reasons.slice(0, 6).join(', ') || score.tool.description}`,
    input: {
      prompt: message,
      operation: 'auto',
      selectedCapability: score.tool.id,
      selectedKind: score.tool.kind,
      matchedTerms: score.reasons,
    } as AgentRecord,
  }));
  const primary = ranked[0];
  const isWorkflowPrimary =
    Boolean(primary) &&
    /workflow/.test(normalize([primary.tool.id, primary.tool.name, primary.tool.modelId || '', primary.tool.description].join(' ')));
  if (workflowRequested && executionRequested && workflowCreatePattern.test(messageText) && isWorkflowPrimary && actions.length === 1) {
    const executeTool =
      tools.find((tool) =>
        /execute workflow|execute-workflow/.test(normalize([tool.id, tool.name, tool.modelId || '', tool.description].join(' '))),
      ) || null;
    if (executeTool) {
      actions.push({
        id: 'capability_2',
        tool: executeTool.id,
        reason: 'Run the workflow that was created in the previous action.',
        input: { executionSource: 'input-workflow-id', workflowActionId: actions[0].id } as AgentRecord,
        depends_on: [actions[0].id],
      });
    }
  }
  if (!actions.length) {
    return {
      intent: 'general_chat',
      actions: [],
      finalResponseInstruction:
        'Giga supports channels, categories, subjects, posts, workflows, charts, and knowledge operations.',
    };
  }
  return {
    intent: 'capability_routed',
    requiresConfirmation: mutationRequested,
    actions,
    finalResponseInstruction: 'Use the capability results to answer. If an operation stayed in auto/planned mode, produce the next structured plan or ask for the one missing clarification.',
  };
};
