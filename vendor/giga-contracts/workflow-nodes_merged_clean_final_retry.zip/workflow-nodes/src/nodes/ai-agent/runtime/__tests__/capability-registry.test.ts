import { describe, expect, it } from 'vitest';
import { createAgentToolCatalog } from '../tool-catalog';

describe('agent tool catalog', () => {
  it('gives chat all default node tools plus system tools', () => {
    const tools = createAgentToolCatalog({ surface: 'chat' });
    expect(tools.some((tool) => tool.id === 'entity.operation')).toBe(true);
    expect(tools.some((tool) => tool.id === 'chart')).toBe(true);
    expect(tools.some((tool) => tool.id === 'database-driver')).toBe(true);
  });

  it('limits workflow to connected tools plus system tools', () => {
    const tools = createAgentToolCatalog({ surface: 'workflow', backendTools: [{ id: 'node-a', name: 'Node A', description: 'Connected tool', kind: 'node', source: 'connected-node' }] });
    expect(tools.some((tool) => tool.id === 'entity.operation')).toBe(true);
    expect(tools.some((tool) => tool.id === 'node-a')).toBe(true);
    expect(tools.some((tool) => tool.id === 'chart')).toBe(false);
  });
});
