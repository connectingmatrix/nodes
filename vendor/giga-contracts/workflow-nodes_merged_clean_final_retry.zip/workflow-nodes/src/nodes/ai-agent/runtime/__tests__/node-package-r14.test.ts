import { validateNodePackage, NodePackage } from '../node-package';

describe('R14 .node package validation', () => {
  const basePackage = (worker: string): NodePackage => ({
    filename: 'safe.node',
    manifest: {
      packageFormat: 'giga.node.package/v2',
      id: 'node_safe',
      name: 'Safe',
      version: '0.0.1',
      kind: 'node',
      modelId: 'safe',
      schemaPath: 'schema.json',
      nodePath: 'node.ts',
      workerPath: 'worker.ts',
      readmePath: 'README.md',
      testsPath: 'tests/worker.test.ts',
      packageJsonPath: 'package.json',
      checksumsPath: 'checksums.json',
      dependencies: [],
      permissions: [],
      backendCommands: ['executeBackend'],
      rules: { allowNetwork: false, allowPackageInstall: false, requiresBackend: true },
      createdAt: new Date().toISOString(),
    },
    files: [
      { path: 'schema.json', content: '{}' },
      { path: 'node.ts', content: 'export const node = {};' },
      { path: 'worker.ts', content: worker },
      { path: 'README.md', content: 'readme' },
      { path: 'tests/worker.test.ts', content: 'test("x", () => {})' },
      { path: 'package.json', content: '{"type":"module"}' },
      { path: 'checksums.json', content: '{}' },
    ],
  });

  it('rejects unsafe imports', () => {
    expect(validateNodePackage(basePackage('import fs from "fs"; export async function execute() {}')).ok).toBe(false);
  });

  it('accepts executeBackend-only workers', () => {
    expect(validateNodePackage(basePackage('export async function execute(input, context) { return context.executeBackend({ tool: "entity.operation", input }); }')).ok).toBe(true);
  });
});
