import type {
  WorkflowCommandToolSpec,
  WorkerControlNodeFacade,
  WorkerExecuteResult,
  WorkerPayload,
  WorkerScope,
  WorkerUpdateResult,
  WorkerValidateResult,
} from '@workflow/executor';
import { WorkflowNodeStatusEnum } from '@workflow/executor';
import { executeBackend } from '@workflow/nodes/workflow-execute';
import { runAgentThoughtLoop } from './thought-loop';
import { createAgentToolCatalog, toolSpecFromCommand } from './tool-catalog';
import { assertNoRuleErrors, validateDynamicNodeSource, validateToolCatalog } from './node-rules';
import { workflowAuthoringName } from '../workflow-authoring';
import type { AgentActionPlan, AgentRecord, AgentRuntimeMessage, AgentToolExecution, AgentToolSpec } from './capability-types';

const NODE_SCOPE: WorkerScope = {};
const text = (value: unknown): string => String(value ?? '').trim();
const record = (value: unknown): AgentRecord => value && typeof value === 'object' && !Array.isArray(value) ? value as AgentRecord : {};
const bool = (value: unknown): boolean => value === true || text(value).toLowerCase() === 'true';
const workflowIntentPattern = /\b(workflow|cypher|webhook|queue|node|graph)\b/i;
const channelIntentPattern = /\bchannel|channels\b/i;
const categoryIntentPattern = /\bcategory|categories\b/i;
const subjectIntentPattern = /\bsubject|subjects\b/i;
const postIntentPattern = /\bpost|posts\b/i;
const chatIntentPattern = /\bchat|message|conversation\b/i;
const treeIntentPattern = /\buser tree|tree\b/i;
const relationIntentPattern = /\b(link|unlink|attach|detach)\b/i;
const confirmIntentPattern = /\bconfirm|confirmed|approve|approved|yes|proceed|continue|go ahead|run it|do it\b/i;
const findTool = (tools: AgentToolSpec[], id: string) => tools.find((tool) => tool.id === id || tool.name === id || tool.modelId === id);
const currentNode = (payload: WorkerPayload): AgentRecord => record((payload as unknown as AgentRecord).self);
const normalizeWorkerResult = (value: unknown): { status: string; output: unknown; logs: string[] } => {
  const item = record(value);
  const status = text(item.status || WorkflowNodeStatusEnum.Passed) || WorkflowNodeStatusEnum.Passed;
  const output = item.output ?? null;
  const logs = Array.isArray(item.logs) ? item.logs.map((entry) => text(entry)).filter(Boolean) : [];
  return { status, output, logs };
};

const nodeRuntime = (payload: WorkerPayload): AgentRecord => record(currentNode(payload).runtime);
const nodeInput = (payload: WorkerPayload): AgentRecord => {
  const payloadRecord = record(payload as unknown as AgentRecord);
  const rawInput = record(payloadRecord.input);
  return record(rawInput.input || rawInput[text(currentNode(payload).id)] || rawInput);
};
const controlGroups = (payload: WorkerPayload): Record<string, Record<string, WorkerControlNodeFacade>> => record(record((payload as { NODE?: unknown }).NODE).CONTROL_NODES) as Record<string, Record<string, WorkerControlNodeFacade>>;

const readCommandTools = async (payload: WorkerPayload): Promise<Array<{ facade: WorkerControlNodeFacade; tool: AgentToolSpec }>> => {
  const peers: Array<{ facade: WorkerControlNodeFacade; tool: AgentToolSpec }> = [];
  for (const [groupId, group] of Object.entries(controlGroups(payload))) {
    if (groupId === 'llm') continue;
    for (const facade of Object.values(group || {})) {
      if (typeof facade?.get !== 'function' || typeof facade?.commandToolSpec !== 'function') continue;
      const [snapshot, spec] = await Promise.all([facade.get(), facade.commandToolSpec()]);
      if (!spec) continue;
      peers.push({ facade, tool: toolSpecFromCommand({ nodeId: snapshot.nodeId, modelId: snapshot.modelId, spec, source: 'connected-node' }) });
    }
  }
  return peers;
};

const readLlmPeers = async (payload: WorkerPayload): Promise<WorkerControlNodeFacade[]> => {
  const candidates = Object.values(controlGroups(payload).llm || {});
  const valid: WorkerControlNodeFacade[] = [];
  for (const facade of candidates) if (typeof facade?.get === 'function' && typeof facade?.execute === 'function') valid.push(facade);
  return valid;
};

const executeLlm = async (payload: WorkerPayload, prompt: string): Promise<string> => {
  const peers = await readLlmPeers(payload);
  const peer = peers[0];
  if (!peer) throw new Error('AI Agent requires a connected LLM node or backend LLM capability.');
  const patch = { runtime: { prompt }, properties: { prompt } };
  const prepared = await peer.executeInputs({ patch });
  const input = { ...prepared.input, input: { ...record(prepared.input?.input), [text(currentNode(payload).id)]: { prompt } } };
  const validation = await peer.validate({ input, patch });
  if (!validation.ok) throw new Error(validation.errors[0] || 'Connected LLM validation failed.');
  const executed = await peer.execute({ input, patch });
  const output = record(executed.result.output);
  return text(output.text || output.markdown || output.output || output.result || executed.result.output);
};

const executeConnectedTool = async (payload: WorkerPayload, peer: { facade: WorkerControlNodeFacade; tool: AgentToolSpec }, action: AgentActionPlan): Promise<AgentToolExecution> => {
  const patch = { runtime: action.input, properties: action.input };
  const prepared = await peer.facade.executeInputs({ patch });
  const input = { ...prepared.input, input: { ...record(prepared.input?.input), [text(currentNode(payload).id)]: action.input } };
  const validation = await peer.facade.validate({ input, patch });
  if (!validation.ok) throw new Error(validation.errors[0] || `${peer.tool.name} validation failed.`);
  const startedAt = Date.now();
  const executed = await peer.facade.execute({ input, patch });
  const status = text(executed.result.status || WorkflowNodeStatusEnum.Passed).toLowerCase();
  return { action, status: status === 'failed' ? 'failed' : 'completed', output: executed.result.output, error: status === 'failed' ? text(record(executed.result.output).error || 'Tool execution failed.') : null, logs: executed.result.logs || [], durationMs: Date.now() - startedAt };
};

const executeBackendTool = async (payload: WorkerPayload, tool: AgentToolSpec, action: AgentActionPlan): Promise<AgentToolExecution> => {
  if (tool.id === 'dynamic-node.operation' || tool.id === 'database.driver') {
    const sourceFiles = record(action.input.sourceFiles || action.input.source_files) as Record<string, string>;
    if (Object.keys(sourceFiles).length) assertNoRuleErrors(validateDynamicNodeSource(sourceFiles));
  }
  const startedAt = Date.now();
  const result = await executeBackend({ key: 'executeAgentRuntimeTool', service: 'services/workflow/nodes/agent-runtime-tool-handler.ts', function: 'executeAgentRuntimeTool', description: tool.description }, { tool, action, NODE: currentNode(payload), payload: payload as unknown as AgentRecord, NODE_SCOPE });
  const normalized = normalizeWorkerResult(result);
  const output = record(normalized.output);
  const status = text(normalized.status).toLowerCase();
  return { action, status: status === 'failed' ? 'failed' : status === 'warning' ? 'confirmation_required' : 'completed', output: normalized.output, error: text(output.error) || null, logs: normalized.logs || [], files: Array.isArray(output.files) ? output.files as never : [], durationMs: Date.now() - startedAt };
};

const executeSandboxLlm = async (payload: WorkerPayload, prompt: string, tools: AgentToolSpec[]): Promise<string> => {
  const skills: AgentRecord[] = [];
  for (const tool of tools) {
    skills.push({
      id: `workflow-node.${tool.id}`,
      name: tool.name,
      description: tool.description,
      instructions: `Plan with ${tool.name}. Execute it only through the workflow tool bridge when an action is selected.`,
      permissions: tool.permissions || [],
      capabilities: tool.capabilities || [tool.id],
    });
  }
  const execution = await executeBackendTool(
    payload,
    { id: 'agent.run_manifest', name: 'Run Inline Sandbox Agent', description: 'Runs the workflow AI agent through OpenAI SandboxAgent.', kind: 'agent', source: 'system', capabilities: ['openai.agents.sdk.sandbox'], mutates: false, mutationPolicy: 'never', risk: 'none' },
    { id: 'sandbox-agent-run', tool: 'agent.run_manifest', reason: 'Use OpenAI Agents SDK SandboxAgent for workflow agent planning.', input: { message: prompt, instructions: 'You are the workflow AI Agent planner. Return a concise action plan or direct answer.', skills, shape: { output: { text: 'string' } } } },
  );
  const outer = record(execution.output);
  const output = record(outer.output);
  return text(output.text || outer.text || execution.output);
};

const agentMessages = (runtime: AgentRecord, input: AgentRecord): AgentRuntimeMessage[] => {
  const raw = Array.isArray(runtime.messages) ? runtime.messages : Array.isArray(input.messages) ? input.messages : [];
  return raw.map((entry) => {
    const item = record(entry);
    const role = ['system', 'user', 'assistant', 'tool'].includes(text(item.role)) ? text(item.role) as AgentRuntimeMessage['role'] : 'user';
    return { role, content: text(item.content || item.text || item.message), metadata: record(item.metadata) };
  }).filter((entry) => entry.content);
};

const normalizeKnowledge = (value: unknown): string | string[] | AgentRecord[] | null => {
  if (typeof value === 'string') return value;
  if (Array.isArray(value)) {
    if (value.every((entry) => typeof entry === 'string')) return value as string[];
    return value.map((entry) => record(entry));
  }
  if (value && typeof value === 'object') return [record(value)];
  return null;
};

const workflowMeta = (payload: WorkerPayload): AgentRecord => {
  const workflow = record((payload as unknown as AgentRecord).workflow);
  return record(workflow.metadata);
};

const workflowInput = (payload: WorkerPayload): AgentRecord => {
  const workflow = record((payload as unknown as AgentRecord).workflow);
  return record(workflow.input);
};

const messageForToolScope = (payload: WorkerPayload): string => {
  const runtime = nodeRuntime(payload);
  const input = nodeInput(payload);
  const flowInput = workflowInput(payload);
  const forwarded = forwardedInput(input);
  return text(
    runtime.message ||
      input.message ||
      flowInput.message ||
      forwarded.message ||
      record(runtime.context).message ||
      record(input.context).message ||
      record(flowInput.context).message ||
      record(forwarded.context).message ||
      runtime.prompt ||
      input.prompt ||
      flowInput.prompt ||
      forwarded.prompt,
  );
};

const forwardedInput = (input: AgentRecord): AgentRecord => {
  for (const value of Object.values(input)) {
    const candidate = record(value);
    if (!Object.keys(candidate).length) continue;
    if (text(candidate.message || candidate.prompt || record(candidate.context).message || candidate.analysisSummary)) return candidate;
    if (candidate.confirmed === true || record(candidate.pendingPlan).actions || record(candidate.context).chat_agent_state) return candidate;
  }
  return {};
};

const scopedCommandPeers = (
  peers: Array<{ facade: WorkerControlNodeFacade; tool: AgentToolSpec }>,
  message: string,
): Array<{ facade: WorkerControlNodeFacade; tool: AgentToolSpec }> => {
  const scoped = workflowIntentPattern.test(message) || confirmIntentPattern.test(message)
    ? peers
    : peers.filter((peer) => {
        const signature = `${peer.tool.id} ${peer.tool.name} ${peer.tool.modelId || ''} ${peer.tool.description}`.toLowerCase();
        return !signature.includes('workflow');
      });
  const messageText = message.toLowerCase();
  const relationIntent = relationIntentPattern.test(messageText);
  const byIntent = scoped.filter((peer) => {
    const signature = `${peer.tool.id} ${peer.tool.name} ${peer.tool.modelId || ''} ${peer.tool.description}`.toLowerCase();
    if (relationIntent && subjectIntentPattern.test(messageText) && channelIntentPattern.test(messageText)) return signature.includes('subject');
    if (relationIntent && categoryIntentPattern.test(messageText) && channelIntentPattern.test(messageText)) return signature.includes('category');
    if (relationIntent && subjectIntentPattern.test(messageText) && categoryIntentPattern.test(messageText)) return signature.includes('subject');
    if (channelIntentPattern.test(messageText)) return signature.includes('channel');
    if (categoryIntentPattern.test(messageText)) return signature.includes('category');
    if (subjectIntentPattern.test(messageText)) return signature.includes('subject');
    if (postIntentPattern.test(messageText)) return signature.includes('post');
    if (chatIntentPattern.test(messageText)) return signature.includes('chat');
    if (treeIntentPattern.test(messageText)) return signature.includes('tree');
    return true;
  });
  return byIntent.length ? byIntent : scoped;
};

const inferActionName = (message: string, allowedActions: string[]): string => {
  const lower = message.toLowerCase();
  if (!allowedActions.length) return '';
  if (/\bunlink|detach\b/.test(lower)) return allowedActions.find((action) => action.startsWith('unlink_') || action.startsWith('detach_')) || '';
  if (/\blink|attach\b/.test(lower)) return allowedActions.find((action) => action.startsWith('link_') || action.startsWith('attach_')) || '';
  if (/\bdelete|remove\b/.test(lower)) return allowedActions.find((action) => action.startsWith('delete_')) || '';
  if (/\bupdate|edit|rename|change\b/.test(lower)) return allowedActions.find((action) => action.startsWith('update_')) || '';
  if (/\bcreate|add|new\b/.test(lower)) return allowedActions.find((action) => action.startsWith('create_')) || '';
  if (/\bread|list|show|get|fetch|find|search\b/.test(lower)) return allowedActions.find((action) => action.startsWith('read_')) || '';
  return allowedActions.length === 1 ? allowedActions[0] : '';
};

const quotedMessageValues = (message: string): string[] => {
  const matches = message.matchAll(/"([^"]+)"/g);
  const values: string[] = [];
  for (const match of matches) {
    const value = text(match[1]);
    if (value) values.push(value);
  }
  return values;
};

const slugValue = (value: string): string =>
  value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);

const fallbackName = (message: string): string => {
  const ignore = new Set([
    'create',
    'update',
    'delete',
    'remove',
    'link',
    'unlink',
    'attach',
    'detach',
    'read',
    'list',
    'show',
    'get',
    'fetch',
    'find',
    'search',
    'channel',
    'category',
    'subject',
    'post',
    'workflow',
    'with',
    'from',
    'then',
    'under',
    'into',
    'that',
    'this',
    'your',
    'my',
    'and',
    'for',
    'the',
    'are',
    'you',
  ]);
  const parts = message
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .split(' ')
    .map((entry) => text(entry))
    .filter((entry) => entry.length > 2 && !ignore.has(entry));
  return parts.slice(0, 5).join('-') || 'giga-auto';
};

const readActionName = (action: string, allowedActions: string[]): string =>
  allowedActions.find((entry) => entry.startsWith('read_')) || allowedActions[0] || action;

const inferredTreeParameters = (action: string, values: string[], message: string): AgentRecord => {
  const autoName = fallbackName(message);
  const first = values[0] || autoName;
  const second = values[1] || `${autoName}-linked`;
  const lower = message.toLowerCase();
  if (!first) return {};
  if (/\b(prefix|start from|starts with)\b/.test(lower)) return { name_prefix: first };
  if (action === 'create_channel') return { channel: { name: first, slug: slugValue(first) } };
  if (action === 'create_category') return { category: { name: first, slug: slugValue(first) } };
  if (action === 'create_subject') return { name: first };
  if (action === 'create_post') return { title: first };
  if (action === 'read_channel' || action === 'delete_channel') return { name: first };
  if (action === 'read_category' || action === 'delete_category') return { category_name: first };
  if (action === 'read_subject' || action === 'delete_subject') return { subject_name: first };
  if (action === 'read_post' || action === 'delete_post') return { post_title: first };
  if (action === 'update_channel') return { channel_name: first, name: second || first };
  if (action === 'update_category') return { category_name: first, name: second || first };
  if (action === 'update_subject') return { subject_name: first, name: second || first };
  if (action === 'update_post') return { post_title: first, title: second || first };
  if (action === 'link_channel' || action === 'unlink_channel') return second ? { parent_channel_name: first, channel_name: second } : {};
  if (action === 'link_category' || action === 'unlink_category') return second ? { channel_name: second, category_name: first } : {};
  if (action === 'link_subject' || action === 'unlink_subject') return second ? { category_name: second, subject_name: first } : {};
  return {};
};

const withRouterActionInput = (tool: AgentToolSpec, action: AgentActionPlan, message: string): AgentActionPlan => {
  if (!tool.id.startsWith('action-router-')) return action;
  const input = { ...record(action.input) };
  const metadata = record(tool.metadata);
  const allowedActions = Array.isArray(metadata.allowedActions) ? metadata.allowedActions.map((entry) => text(entry)).filter(Boolean) : [];
  if (!text(input.message) && message) input.message = message;
  const selectedAction = text(input.action);
  const invalidSelectedAction =
    (selectedAction && allowedActions.length > 0 && !allowedActions.includes(selectedAction)) || selectedAction === tool.id || selectedAction === tool.name;
  if (!selectedAction || invalidSelectedAction) {
    const inferred = inferActionName(text(input.message || input.prompt || message), allowedActions);
    if (inferred) input.action = inferred;
  }
  const parameters = record(input.parameters);
  if (!text(input.action)) {
    input.action = readActionName(text(input.action), allowedActions);
  }
  if (!Object.keys(parameters).length && text(input.action)) {
    const values = quotedMessageValues(text(input.message || input.prompt || message));
    const inferredParameters = inferredTreeParameters(text(input.action), values, text(input.message || input.prompt || message));
    if (Object.keys(inferredParameters).length) input.parameters = inferredParameters;
    const likelyMutating = /^(create|update|delete|link|unlink)_/.test(text(input.action));
    if (likelyMutating && !Object.keys(record(input.parameters)).length) input.action = readActionName(text(input.action), allowedActions);
  }
  return { ...action, input };
};

const withWorkflowActionInput = (tool: AgentToolSpec, action: AgentActionPlan, message: string): AgentActionPlan => {
  const signature = `${tool.id} ${tool.name} ${tool.modelId || ''}`.toLowerCase();
  if (!signature.includes('workflow')) return action;
  if (/execute workflow|execute-workflow/.test(signature)) return action;
  const input = { ...record(action.input) };
  const operation = text(input.operation).toLowerCase();
  if (operation && operation !== 'auto') return action;
  const actionMessage = text(input.workflowPrompt || input.prompt || message);
  const lower = actionMessage.toLowerCase();
  if (/\bdelete|remove\b/.test(lower)) input.operation = 'delete';
  else if (/\bpublish\b/.test(lower)) input.operation = 'publish';
  else if (/\battach|link\b/.test(lower)) input.operation = 'attach';
  else if (/\blist|show|get|read|find|search\b/.test(lower)) input.operation = 'list';
  else input.operation = 'save';
  if (text(input.operation) === 'save') {
    if (!text(input.saveMode)) input.saveMode = /\bupdate|edit|change|rename\b/.test(lower) ? 'update' : 'create';
    if (!text(input.definitionSource)) input.definitionSource = 'ai';
    if (!text(input.workflowPrompt)) input.workflowPrompt = actionMessage;
    if (!text(input.workflowName) && !text(input.name)) input.workflowName = workflowAuthoringName(actionMessage);
    if (!text(input.workflowDescription) && !text(input.description)) input.workflowDescription = actionMessage;
    if (input.publishAfterSave !== true && /\b(run|execute)\b/.test(lower)) input.publishAfterSave = true;
  }
  return { ...action, input };
};

const workflowIdFromToolResult = (result: AgentToolExecution): string => {
  const output = record(result.output);
  const primary = record(output.output || output.result || output.data || output);
  const actionResult = record(primary.action_result || output.action_result);
  const data = record(actionResult.data || primary.data);
  const workflow = record(data.workflow || primary.workflow || output.workflow);
  return text(
    data.workflow_id ||
      data.workflowId ||
      workflow.workflow_id ||
      workflow.workflowId ||
      workflow.id ||
      primary.workflow_id ||
      primary.workflowId ||
      output.workflow_id ||
      output.workflowId,
  );
};

const workflowDependencyFromToolResult = (result: AgentToolExecution): AgentRecord => {
  const output = record(result.output);
  const primary = record(output.output || output.result || output.data || output);
  const actionResult = record(primary.action_result || output.action_result);
  const data = record(actionResult.data || primary.data);
  const workflow = record(data.workflow || primary.workflow || output.workflow);
  const workflowId = workflowIdFromToolResult(result);
  const workflowName = text(
    data.workflow_name ||
      data.workflowName ||
      workflow.name ||
      primary.workflow_name ||
      primary.workflowName ||
      output.workflow_name ||
      output.workflowName,
  );
  const payload: AgentRecord = {
    ...output,
    ...primary,
    ...actionResult,
    ...data,
    data: {
      ...data,
      workflow: { ...workflow },
    },
  };
  if (workflowId) {
    payload.workflow_id = workflowId;
    payload.workflowId = workflowId;
    record(payload.data).workflow_id = workflowId;
    record(payload.data).workflowId = workflowId;
    const workflowData = record(record(payload.data).workflow);
    if (!text(workflowData.id)) workflowData.id = workflowId;
    if (!text(workflowData.workflowId)) workflowData.workflowId = workflowId;
    record(payload.data).workflow = workflowData;
  }
  if (workflowName) {
    payload.workflow_name = workflowName;
    payload.workflowName = workflowName;
    record(payload.data).workflow_name = workflowName;
    record(payload.data).workflowName = workflowName;
    const workflowData = record(record(payload.data).workflow);
    if (!text(workflowData.name)) workflowData.name = workflowName;
    record(payload.data).workflow = workflowData;
  }
  return payload;
};

const withExecuteWorkflowInput = (
  tool: AgentToolSpec,
  action: AgentActionPlan,
  previousResults: AgentToolExecution[],
): AgentActionPlan => {
  const signature = `${tool.id} ${tool.name} ${tool.modelId || ''}`.toLowerCase();
  if (!/execute workflow|execute-workflow/.test(signature)) return action;
  const input = { ...record(action.input) };
  if (text(input.workflowId || input.workflow_id)) return action;
  const workflowActionId = text(input.workflowActionId || input.workflow_action_id) || text((action.depends_on || [])[0]);
  const dependency =
    (workflowActionId ? previousResults.find((entry) => entry.action.id === workflowActionId) : null) ||
    [...previousResults].reverse().find((entry) => Boolean(workflowIdFromToolResult(entry))) ||
    null;
  if (!dependency) return action;
  const dependencyKey = text(dependency.action.id);
  const dependencyResults = { ...record(input.dependencyResults) };
  if (dependencyKey) dependencyResults[dependencyKey] = workflowDependencyFromToolResult(dependency);
  const workflowId = workflowIdFromToolResult(dependency);
  if (Object.keys(dependencyResults).length) input.dependencyResults = dependencyResults;
  if (workflowId) input.workflowId = workflowId;
  if (dependencyKey) input.workflowActionId = dependencyKey;
  return { ...action, input };
};

const preferredRouterTool = (tools: AgentToolSpec[], message: string): AgentToolSpec | null => {
  const lower = message.toLowerCase();
  const pick = (keyword: string) => tools.find((tool) => tool.id.startsWith('action-router-') && `${tool.name} ${tool.description}`.toLowerCase().includes(keyword)) || null;
  if (relationIntentPattern.test(lower) && subjectIntentPattern.test(lower) && channelIntentPattern.test(lower)) return pick('subject');
  if (relationIntentPattern.test(lower) && categoryIntentPattern.test(lower) && channelIntentPattern.test(lower)) return pick('category');
  if (relationIntentPattern.test(lower) && subjectIntentPattern.test(lower) && categoryIntentPattern.test(lower)) return pick('subject');
  if (channelIntentPattern.test(lower)) return pick('channel');
  if (categoryIntentPattern.test(lower)) return pick('category');
  if (subjectIntentPattern.test(lower)) return pick('subject');
  if (postIntentPattern.test(lower)) return pick('post');
  if (treeIntentPattern.test(lower)) return pick('tree');
  if (chatIntentPattern.test(lower)) return pick('chat');
  return null;
};

const buildAgentInput = (payload: WorkerPayload, tools: AgentToolSpec[]) => {
  const runtime = nodeRuntime(payload);
  const input = nodeInput(payload);
  const flowInput = workflowInput(payload);
  const forwarded = forwardedInput(input);
  const message = text(
    runtime.message ||
      input.message ||
      flowInput.message ||
      forwarded.message ||
      record(runtime.context).message ||
      record(input.context).message ||
      record(flowInput.context).message ||
      record(forwarded.context).message ||
      runtime.prompt ||
      input.prompt ||
      flowInput.prompt ||
      forwarded.prompt,
  );
  const pendingPlan = record(runtime.pendingPlan || input.pendingPlan || flowInput.pendingPlan || forwarded.pendingPlan);
  return {
    message,
    systemPrompt: text(runtime.systemPrompt || runtime.selectionPromptMd || runtime.instructions) || null,
    tools,
    messages: agentMessages(runtime, input),
    knowledge: normalizeKnowledge(runtime.knowledge || input.knowledge || flowInput.knowledge || forwarded.knowledge || runtime.knowledgeText || input.knowledgeText || null),
    attachments: Array.isArray(input.attachments) ? (input.attachments as never) : Array.isArray(flowInput.attachments) ? (flowInput.attachments as never) : [],
    context: {
      ...record(runtime.context),
      ...record(input.context),
      ...record(flowInput.context),
      ...record(forwarded.context),
      chatId: text(runtime.chatId || input.chatId || flowInput.chatId || forwarded.chatId),
      workflowId: text(workflowMeta(payload).id),
      runId: text(workflowMeta(payload).runId || workflowMeta(payload).executionId),
    },
    confirmed: bool(runtime.confirmed || input.confirmed || flowInput.confirmed || forwarded.confirmed),
    pendingPlan: pendingPlan.actions ? (pendingPlan as never) : null,
    maxPasses: Number(runtime.maxPasses || 10),
    maxActionsPerPass: Number(runtime.maxActionsPerPass || 12),
    confirmationPolicy: text(runtime.confirmationPolicy || 'mutations-only') as never,
    allowDynamicNodes: runtime.allowDynamicNodes !== false,
    allowSwarm: runtime.allowSwarm === true,
    allowWorkflowMutation: runtime.allowWorkflowMutation !== false,
    requestId: text(workflowMeta(payload).requestId || runtime.requestId || input.requestId || flowInput.requestId || forwarded.requestId) || null,
    surface: 'workflow' as const,
    outputFormatSeed: text(runtime.outputFormatSeed || input.outputFormatSeed || flowInput.outputFormatSeed) || null,
  };
};

export const validate = async (payload: WorkerPayload): Promise<WorkerValidateResult> => {
  const runtime = nodeRuntime(payload);
  const errors: string[] = [];
  const warnings: string[] = [];
  const commandPeers = scopedCommandPeers(await readCommandTools(payload), messageForToolScope(payload));
  const tools = createAgentToolCatalog({
    surface: 'workflow',
    backendTools: commandPeers.map((peer) => peer.tool),
    includeBackendTools: true,
    includeDefaultNodeTools: false,
  });
  for (const violation of validateToolCatalog(tools)) (violation.severity === 'error' ? errors : warnings).push(violation.message);
  const mode = text(runtime.executionMode || 'plan-and-run');
  if (!['plan-and-run', 'plan-only', 'execute-plan', 'quick-reply'].includes(mode)) errors.push('Execution mode must be plan-and-run, plan-only, execute-plan, or quick-reply.');
  if (!text(runtime.message || runtime.prompt) && !record(runtime.context).message) warnings.push('AI Agent message will be read from workflow input at runtime.');
  return { ok: errors.length === 0, errors, warnings, normalizedRuntime: runtime };
};

export const init = async (payload: WorkerPayload): Promise<boolean> => { NODE_SCOPE.workflowId = text(workflowMeta(payload).id); NODE_SCOPE.initialized = true; return true; };
export const onUpdate = async (payload: WorkerPayload): Promise<WorkerUpdateResult> => { NODE_SCOPE.lastStatus = payload.self?.status || NODE_SCOPE.lastStatus; NODE_SCOPE.lastOutput = payload.self?.OUTPUT || NODE_SCOPE.lastOutput; return { ok: true, error: null }; };

export const commandToolSpec = async (payload: WorkerPayload): Promise<WorkflowCommandToolSpec> => ({
  toolName: text(currentNode(payload).name) || 'AI Agent',
  toolDescription: 'Runs the shared Giga AI Agent using connected node tools plus backend system tools. Workflow agents do not get default disconnected tools.',
  inputContract: { required: [{ key: 'message', label: 'Message', description: 'The task for the agent.', required: true }], optional: [{ key: 'knowledge', label: 'Knowledge' }, { key: 'attachments', label: 'Attachments' }, { key: 'confirmed', label: 'Confirmed' }, { key: 'pendingPlan', label: 'Pending Plan' }] },
  outputContract: [{ key: 'markdown', label: 'Markdown' }, { key: 'files', label: 'Files' }, { key: 'plan', label: 'Plan' }, { key: 'carryContext', label: 'Carry Context' }],
  metadata: { modelId: 'ai-agent', mutating: true, toolDomain: 'agent', workflowOutput: true },
  executionKind: 'tool',
});

export const execute = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => {
  try {
    const commandPeers = scopedCommandPeers(await readCommandTools(payload), messageForToolScope(payload));
    const tools = createAgentToolCatalog({
      surface: 'workflow',
      backendTools: commandPeers.map((peer) => peer.tool),
      includeBackendTools: true,
      includeDefaultNodeTools: false,
    });
    const peerByTool = new Map(commandPeers.flatMap((peer) => [[peer.tool.id, peer], [peer.tool.name, peer]]));
    const input = buildAgentInput(payload, tools);
    const result = await runAgentThoughtLoop(input, {
      callLLM: async ({ messages }) => {
        const lines: string[] = [];
        for (const message of messages) lines.push(`${message.role.toUpperCase()}: ${message.content}`);
        const prompt = lines.join('\n\n');
        return executeSandboxLlm(payload, prompt, tools);
      },
      executeTool: async ({ action, tool, previousResults }) => {
        const mappedTool = tool.id.startsWith('action-router-') ? preferredRouterTool(tools, input.message) || tool : tool;
        const routedAction = withRouterActionInput(mappedTool, action, input.message);
        const scopedAction = withWorkflowActionInput(mappedTool, routedAction, input.message);
        const resolvedAction = withExecuteWorkflowInput(mappedTool, scopedAction, previousResults);
        const peer = peerByTool.get(mappedTool.id) || peerByTool.get(mappedTool.name);
        return peer ? executeConnectedTool(payload, peer, resolvedAction) : executeBackendTool(payload, mappedTool, resolvedAction);
      },
      listenWorkflowLogs: async ({ workflowId, runId, since }) => {
        if (!workflowId && !runId) return [];
        const tool = findTool(tools, 'workflow.operation');
        if (!tool) return [];
        const execution = await executeBackendTool(payload, tool, { id: 'logs', tool: 'workflow.operation', reason: 'Listen to live workflow logs.', input: { operation: 'listen_logs', workflowId, runId, since } });
        return Array.isArray(record(execution.output).logs) ? record(execution.output).logs as string[] : execution.logs || [];
      },
    });
    const toolCatalogLog = `tool_catalog:${tools.map((tool) => `${tool.id}:${tool.name}:${tool.kind}`).join('|')}`;
    return {
      output: {
        markdown: result.markdown,
        text: result.message,
        status: result.status,
        plan: result.plan,
        action_results: result.actionResults,
        passes: result.passes,
        files: result.files,
        logs: [toolCatalogLog, ...result.logs],
        carryContext: result.carryContext,
        pendingPlan: result.pendingPlan || null,
      },
      status: result.status === 'failed' ? WorkflowNodeStatusEnum.Failed : result.status === 'confirmation_required' ? WorkflowNodeStatusEnum.Warning : WorkflowNodeStatusEnum.Passed,
      logs: [toolCatalogLog, ...result.logs],
      skipCommandPeerAutoRun: true,
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : 'AI Agent execution failed.';
    return { output: { error: message, markdown: message }, status: WorkflowNodeStatusEnum.Failed, logs: [message], skipCommandPeerAutoRun: true };
  }
};
