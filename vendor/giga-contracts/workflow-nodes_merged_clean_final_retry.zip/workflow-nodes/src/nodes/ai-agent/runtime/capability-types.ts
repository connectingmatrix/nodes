export type AgentRecord = Record<string, unknown>;

export type AgentToolKind =
  | 'agent'
  | 'chart'
  | 'chat'
  | 'code'
  | 'control'
  | 'database'
  | 'entity'
  | 'excel'
  | 'file'
  | 'knowledge'
  | 'llm'
  | 'node'
  | 'tree'
  | 'workflow';

export type AgentToolSource = 'backend' | 'catalog' | 'connected-node' | 'dynamic-node' | 'mcp' | 'node' | 'system' | 'workflow';
export type AgentMutationPolicy = 'never' | 'confirmation-required' | 'always-allowed';
export type AgentExecutionSurface = 'chat' | 'workflow' | 'system' | 'test';
export type AgentRisk = 'none' | 'low' | 'write' | 'destructive' | 'admin' | 'swarm' | 'package-install' | 'external-network' | 'large-cost';

export type AgentToolExample = {
  user: string;
  args: AgentRecord;
  expected?: string;
};

export type AgentToolSpec = {
  id: string;
  name: string;
  description: string;
  kind: AgentToolKind;
  source?: AgentToolSource;
  modelId?: string | null;
  nodeId?: string | null;
  capabilities?: string[];
  aliases?: string[];
  examples?: AgentToolExample[];
  permissions?: string[];
  risk?: AgentRisk;
  mutates?: boolean;
  mutationPolicy?: AgentMutationPolicy;
  inputContract?: unknown;
  outputContract?: unknown;
  metadata?: AgentRecord;
};

export type AgentCapability = AgentToolSpec & {
  enabled?: boolean;
  surfaces?: AgentExecutionSurface[];
  requiresConfirmation?: boolean;
  requiresRoot?: boolean;
  requiresSuperAdmin?: boolean;
  requiresConnectedNode?: boolean;
  supportsArtifacts?: boolean;
  supportsStreaming?: boolean;
  supportsRollback?: boolean;
};

export type AgentCapabilityGraph = {
  generatedAt: string;
  surface: AgentExecutionSurface;
  tools: AgentToolSpec[];
  byKind: Partial<Record<AgentToolKind, AgentToolSpec[]>>;
  byId: Record<string, AgentToolSpec>;
};

export type ConnectedNodeCommand = {
  nodeId: string;
  modelId?: string | null;
  toolName: string;
  toolDescription?: string | null;
  inputContract?: unknown;
  outputContract?: unknown;
  metadata?: AgentRecord;
};

export type CapabilityProviderInput = {
  surface: AgentExecutionSurface;
  connectedCommands?: ConnectedNodeCommand[];
  nodeSchemas?: unknown[];
  mcpCapabilities?: AgentToolSpec[];
  includeSystemTools?: boolean;
  includeDefaultNodeTools?: boolean;
  entityCapabilities?: AgentToolSpec[];
  callerRole?: 'user' | 'root-user' | 'super-admin' | string;
};

export type CapabilityProvider = (input: CapabilityProviderInput) => Promise<AgentCapability[]> | AgentCapability[];

export type BackendCommand = {
  tool: string;
  operation?: string;
  input?: AgentRecord;
  context?: AgentRecord;
};

export type BackendCommandResult = {
  status: 'completed' | 'failed' | 'confirmation_required';
  output?: unknown;
  error?: string | null;
  files?: AgentFileOutput[];
  logs?: string[];
  metadata?: AgentRecord;
  pendingPlan?: AgentPlan | null;
};

export type BackendCommandPort = {
  executeBackend(command: BackendCommand): Promise<BackendCommandResult>;
};

export type AgentFileOutput = {
  id?: string | null;
  filename: string;
  contentType?: string | null;
  path?: string | null;
  url?: string | null;
  bytes?: number | null;
  content?: string | null;
  base64?: string | null;
  metadata?: AgentRecord;
};

export type AgentRuntimeMessage = {
  role: 'system' | 'user' | 'assistant' | 'tool';
  content: string;
  metadata?: AgentRecord;
};

export type AgentActionPlan = {
  id: string;
  tool: string;
  reason: string;
  input: AgentRecord;
  depends_on?: string[];
};

export type AgentPlan = {
  intent: string;
  requiresConfirmation?: boolean;
  actions: AgentActionPlan[];
  finalResponseInstruction?: string | null;
  todo?: AgentTodoItem[];
  ambiguity?: string[];
};

export type AgentToolExecution = {
  action: AgentActionPlan;
  status: 'completed' | 'failed' | 'skipped' | 'confirmation_required';
  output?: unknown;
  error?: string | null;
  files?: AgentFileOutput[];
  logs?: string[];
  durationMs?: number;
};

export type AgentTodoItem = {
  id: string;
  title: string;
  status: 'pending' | 'running' | 'completed' | 'blocked' | 'cancelled';
  parentId?: string | null;
  notes?: string | null;
  resultRef?: string | null;
};

export type AgentCarryContext = {
  facts: AgentRecord;
  todos: AgentTodoItem[];
  artifacts: AgentFileOutput[];
  decisions: AgentRecord[];
  warnings: string[];
};

export type AgentThoughtLoopPass = {
  index: number;
  prompt: string;
  plan: AgentPlan;
  toolResults: AgentToolExecution[];
  observations: string[];
  carryContext: AgentCarryContext;
};

export type AgentThoughtLoopInput = {
  message: string;
  systemPrompt?: string | null;
  tools: AgentToolSpec[];
  messages?: AgentRuntimeMessage[];
  knowledge?: string | string[] | AgentRecord[] | null;
  attachments?: AgentRecord[];
  context?: AgentRecord;
  confirmed?: boolean;
  pendingPlan?: AgentPlan | null;
  maxPasses?: number;
  maxActionsPerPass?: number;
  confirmationPolicy?: 'never' | 'mutations-only' | 'always';
  allowDynamicNodes?: boolean;
  allowSwarm?: boolean;
  allowWorkflowMutation?: boolean;
  requestId?: string | null;
  surface?: AgentExecutionSurface;
  outputFormatSeed?: string | null;
};

export type AgentThoughtLoopOutput = {
  status: 'completed' | 'confirmation_required' | 'failed';
  message: string;
  markdown: string;
  plan: AgentPlan;
  passes: AgentThoughtLoopPass[];
  actionResults: AgentToolExecution[];
  files: AgentFileOutput[];
  logs: string[];
  carryContext: AgentCarryContext;
  pendingPlan?: AgentPlan | null;
};

export type AgentPlannerCall = (input: {
  messages: AgentRuntimeMessage[];
  tools: AgentToolSpec[];
  context: AgentRecord;
  passIndex: number;
  previousResults: AgentToolExecution[];
  carryContext: AgentCarryContext;
}) => Promise<string>;

export type AgentToolRunner = (input: {
  action: AgentActionPlan;
  tool: AgentToolSpec;
  context: AgentRecord;
  previousResults: AgentToolExecution[];
  carryContext: AgentCarryContext;
}) => Promise<AgentToolExecution>;

export type AgentLoopHooks = {
  callLLM: AgentPlannerCall;
  executeTool: AgentToolRunner;
  listenWorkflowLogs?: (input: { workflowId?: string | null; runId?: string | null; since?: string | null }) => Promise<string[]>;
  onPass?: (pass: AgentThoughtLoopPass) => Promise<void> | void;
};
