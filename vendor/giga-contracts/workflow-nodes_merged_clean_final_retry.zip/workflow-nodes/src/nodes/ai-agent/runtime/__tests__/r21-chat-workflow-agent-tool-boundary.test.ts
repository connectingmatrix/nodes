import { describe, expect, it } from 'vitest';
import { createAgentToolCatalog } from '../index';

describe('R21 chat/workflow agent tool boundary', () => {
  it('chat agents can see default node tools and backend system tools', () => {
    const catalog = createAgentToolCatalog({ surface: 'chat', includeBackendTools: true, includeDefaultNodeTools: true, backendTools: [] });
    const ids = catalog.map((tool: any) => tool.id || tool.name);
    expect(ids.some((id: string) => String(id).includes('entity') || String(id).includes('backend'))).toBe(true);
  });

  it('workflow agents do not receive unconnected default tools when connected-only mode is used', () => {
    const catalog = createAgentToolCatalog({ surface: 'workflow', includeBackendTools: true, includeDefaultNodeTools: false, backendTools: [] });
    expect(catalog.every((tool: any) => tool.connected !== false)).toBe(true);
  });
});
