import type { AgentRecord } from './capability-types';

export type AttachmentPlan = {
  path: string;
  filename: string;
  contentType?: string | null;
  bytes: number;
  strategy: 'inline-ingest' | 'compress-then-ingest' | 'zip-tree' | 'stream-to-sql' | 'upload-only';
  reason: string;
  metadata: AgentRecord;
};

const runtimeEnv = ((globalThis as { process?: { env?: Record<string, string | undefined> } }).process?.env) || {};
const SMALL_FILE_BYTES = Number(runtimeEnv.AGENT_SMALL_FILE_BYTES || 10 * 1024 * 1024);
const LARGE_TABLE_BYTES = Number(runtimeEnv.AGENT_LARGE_TABLE_BYTES || 128 * 1024 * 1024);
const text = (value: unknown) => String(value ?? '').trim();

export const planAttachmentIngestion = (input: { path: string; filename?: string | null; contentType?: string | null; bytes?: number | null; metadata?: AgentRecord }): AttachmentPlan => {
  const filename = text(input.filename || input.path.split('/').pop());
  const contentType = text(input.contentType).toLowerCase();
  const bytes = Number(input.bytes || 0);
  const lower = filename.toLowerCase();
  const base = { path: input.path, filename, contentType: input.contentType || null, bytes, metadata: input.metadata || {} };
  if (/\.zip$|application\/zip/.test(`${lower} ${contentType}`)) return { ...base, strategy: 'zip-tree', reason: 'Zip files should be extracted into a file tree before selective ingestion.' };
  if (/\.pdf$|application\/pdf/.test(`${lower} ${contentType}`)) return bytes <= SMALL_FILE_BYTES ? { ...base, strategy: 'compress-then-ingest', reason: 'PDF is small enough to compress/extract and ingest.' } : { ...base, strategy: 'upload-only', reason: 'Large PDF is uploaded and indexed by metadata first; content is extracted selectively.' };
  if (/\.csv$|\.tsv$|\.xlsx$|\.xls$|text\/csv|spreadsheet/.test(`${lower} ${contentType}`)) return bytes >= LARGE_TABLE_BYTES ? { ...base, strategy: 'stream-to-sql', reason: 'Large table files should be streamed into an inline SQL database.' } : { ...base, strategy: 'inline-ingest', reason: 'Table file is small enough to ingest directly.' };
  if (bytes > SMALL_FILE_BYTES) return { ...base, strategy: 'upload-only', reason: 'File is too large for direct ingestion; upload and process chunks on demand.' };
  return { ...base, strategy: 'inline-ingest', reason: 'File is small enough for direct ingestion.' };
};
