export * from './r20-capabilities';
