import rawSchema from '@workflow/nodes/nodes/ai-agent/ai-agent-schema.json';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';
import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { WorkflowNodeKindEnum, WorkflowNodeFieldMap } from '@workflow/nodes/types';

const schema = parseNodeSchema(rawSchema, 'ai-agent');

const workflowToolOptions = (workflow: Parameters<NonNullable<WorkflowNodeModule['resolveInspectorFields']>>[0]['workflow'], nodeId: string) => {
    const nodeById = new Map(workflow.nodes.map((node) => [node.id, node]));
    return workflow.connections
        .filter((connection) => connection.to === nodeId && connection.targetHandle === 'cmd:workflow')
        .map((connection) => nodeById.get(connection.from))
        .filter((node): node is NonNullable<typeof node> => Boolean(node))
        .reduce<Array<{ label: string; value: string }>>((acc, node) => {
            if (acc.some((entry) => entry.value === node.id)) return acc;
            acc.push({ label: `${node.name} (${node.modelId})`, value: node.id });
            return acc;
        }, []);
};

const aiAgentNodeModule: WorkflowNodeModule = {
    id: 'ai-agent',
    schema,
    library: {
        id: 'ai-agent-node',
        label: 'AI Agent',
        description: 'Plan, confirm, execute, and answer through connected workflow-native tools.',
        gigaId: 'AiAgentNode',
        modelId: 'ai-agent',
        group: 'Giga AI Nodes',
        nodeType: 'workflowStep',
        defaultKind: WorkflowNodeKindEnum.Process,
        iconColor: '#0f766e',
        iconBackground: '#ccfbf1',
        order: 124
    },
    renderIcon: (size) => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <circle cx="16" cy="16" r="8" stroke="currentColor" stroke-width="2.4"/>
  <circle cx="32" cy="16" r="8" stroke="currentColor" stroke-width="2.4"/>
  <path d="M14 31h20M18 38h12" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>
  <path d="M24 24v7" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>
</svg>`,
    buildInitialNode: (context) => buildInitialNodeFromSchema(context),
    ui: { localCapable: true, serverOnly: false, customInspector: 'ai-agent-editor', openEditorAction: 'open-ai-agent-editor' },
    resolveInspectorFields: ({ workflow, node, fields }) => {
        const nextFields: WorkflowNodeFieldMap = { ...fields };
        const options = workflowToolOptions(workflow, node.id);
        if (nextFields.workflowToolAllowlist) {
            nextFields.workflowToolAllowlist = {
                ...nextFields.workflowToolAllowlist,
                hidden: options.length === 0,
                options
            };
        }
        return nextFields;
    },
    execute: createNodeModuleWorkerExecute('ai-agent')
};

export default aiAgentNodeModule;
