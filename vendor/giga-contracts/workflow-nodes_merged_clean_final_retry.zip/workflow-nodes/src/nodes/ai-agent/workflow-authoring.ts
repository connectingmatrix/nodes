export type WorkflowAuthoringTool = {
    modelId?: string;
    name?: string;
    nodeId: string;
};

export type WorkflowAuthoringPlan = {
    actions: Array<{
        depends_on: string[];
        id: string;
        input: Record<string, unknown>;
        kind: 'tool';
        name: string;
        nodeId: string;
        reason: string;
    }>;
    final_action_id: string;
    intent: string;
};

export const hasWorkflowEditIntent = (message: string): boolean =>
    /\b(write|add|insert|change|modify|alter|replace|edit|code|script|function|fibonacci|fib|accept|retrain|format|template|attach|link|upload|return|generate|enforce)\b/i.test(message);

export const isWorkflowAuthoringMessage = (message: string): boolean =>
    (/\bworkflow\b/i.test(message) || /\bWF-[a-z0-9_-]+\b/i.test(message)) &&
    (/\b(create|build|make|update|execute|run|governor|cypher|publish|attach|link)\b/i.test(message) || hasWorkflowEditIntent(message));

const quotedName = (message: string): string => message.match(/"([^"]+)"/)?.[1]?.trim() || '';
const titleWord = (word: string): string => (word ? `${word.charAt(0).toUpperCase()}${word.slice(1).toLowerCase()}` : '');
const cleanWorkflowName = (message: string): string =>
    message
        .replace(/\b(create|build|make|generate|a|an|the|workflow|that|will|for|chart|charts|graph|graphs|plot|plots|visuali[sz]ation|dashboard|and|then|to|my)\b/gi, ' ')
        .replace(/[^a-z0-9]+/gi, ' ')
        .trim()
        .split(/\s+/)
        .filter(Boolean)
        .slice(0, 8)
        .map(titleWord)
        .join(' ');

export const workflowAuthoringName = (message: string): string => quotedName(message) || cleanWorkflowName(message) || 'Chat Workflow';

const nodeLine = (alias: string, modelId: string, name: string, runtime: Record<string, unknown>): string =>
    `(${alias}:${modelId} ${JSON.stringify({ name, runtime })})`;
const connectLine = (from: string, to: string): string =>
    `(${from})-[:CONNECT ${JSON.stringify({ source: 'out:output', target: 'in:input' })}]->(${to})`;
const escapedRuntimeCode = (text: string): string => `return ${JSON.stringify(text)};`;
const runtimeBindingNodeIds = new Set(['run-channel-action', 'run-category-action', 'run-subject-action', 'run-post-action', 'run-user-tree-action', 'run-chat-action']);

const chartWorkflowCypher = (message: string): string =>
    [
        nodeLine('start', 'start', 'Start', {}),
        nodeLine('chart', 'chart', 'Chart', { prompt: message, outputMode: 'both', libraryId: 'auto', chartTemplateId: 'auto' }),
        nodeLine('end', 'respond-end', 'Respond End', { response: '{{chart.markup}}' }),
        connectLine('start', 'chart'),
        connectLine('chart', 'end')
    ].join('\n');

const userTreeWorkflowCypher = (message: string): string =>
    [
        nodeLine('start', 'start', 'Start', {}),
        nodeLine('tree', 'run-user-tree-action', 'Fetch User Tree', { action: 'fetch_user_tree', chatId: '{{workflow.input.chatId}}', message: '{{workflow.input.message}}', reason: message }),
        nodeLine('end', 'respond-end', 'Respond End', { response: '{{tree.action.summary}}' }),
        connectLine('start', 'tree'),
        connectLine('tree', 'end')
    ].join('\n');

const literalWorkflowCypher = (message: string): string =>
    [
        nodeLine('start', 'start', 'Start', {}),
        nodeLine('code', 'code', 'Build Response', { code: escapedRuntimeCode(`Workflow prepared for: ${message}`) }),
        nodeLine('end', 'respond-end', 'Respond End', { response: '{{code.output}}' }),
        connectLine('start', 'code'),
        connectLine('code', 'end')
    ].join('\n');

export const workflowAuthoringCypher = (message: string): string => {
    if (/\b(chart|charts|graph|graphs|plot|plots|visuali[sz]ation|dashboard)\b/i.test(message)) return chartWorkflowCypher(message);
    if (/\buser tree|tree\b/i.test(message) && /\b(read|fetch|load|get)\b/i.test(message)) return userTreeWorkflowCypher(message);
    return literalWorkflowCypher(message);
};

export const workflowAuthoringRuntimeBindings = (cypher: string): string =>
    cypher.split('\n').map((line) => {
        const match = line.match(/^\(([^:()]+):([a-z0-9-]+)\s+(\{.*\})\)$/i);
        if (!match || !runtimeBindingNodeIds.has(match[2])) return line;
        try {
            const payload = JSON.parse(match[3]) as { name?: string; runtime?: Record<string, unknown> };
            return nodeLine(match[1], match[2], String(payload.name || match[2]), {
                ...(payload.runtime || {}),
                chatId: String((payload.runtime || {}).chatId || '{{workflow.input.chatId}}'),
                message: String((payload.runtime || {}).message || '{{workflow.input.message}}')
            });
        } catch {
            return line;
        }
    }).join('\n');

export const workflowAuthoringInput = (message: string): Record<string, unknown> => ({
    cypher: workflowAuthoringRuntimeBindings(workflowAuthoringCypher(message)),
    definitionSource: 'cypher',
    operation: 'save',
    publishAfterSave: true,
    saveMode: 'create',
    workflowDescription: message,
    workflowName: workflowAuthoringName(message)
});

export const createWorkflowAuthoringNodePlan = (message: string, tools: WorkflowAuthoringTool[]): WorkflowAuthoringPlan | null => {
    const workflowTool = tools.find((tool) => tool.modelId === 'workflow') || null;
    if (!workflowTool) return null;
    const executeTool = tools.find((tool) => tool.modelId === 'execute-workflow') || null;
    const actions: WorkflowAuthoringPlan['actions'] = [
        { id: 'a1', kind: 'tool', nodeId: workflowTool.nodeId, name: workflowTool.name || 'Workflow', reason: 'Create the requested workflow from valid Workflow Cypher.', input: workflowAuthoringInput(message), depends_on: [] }
    ];
    if (executeTool && /\b(execute|run)\b/i.test(message)) {
        actions.push({ id: 'a2', kind: 'tool', nodeId: executeTool.nodeId, name: executeTool.name || 'Execute Workflow', reason: 'Run the workflow that was just created.', input: { executionSource: 'input-workflow-id', workflowActionId: 'a1' }, depends_on: ['a1'] });
    }
    return { intent: 'Create a workflow from Workflow Cypher.', actions, final_action_id: actions[actions.length - 1].id };
};
