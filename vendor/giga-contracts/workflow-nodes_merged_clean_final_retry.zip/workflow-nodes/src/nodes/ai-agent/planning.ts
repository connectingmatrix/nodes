import { inferPlanActionDependencies } from './giga-plan-dependencies';

export type PlannedAction = {
  id: string;
  kind: string;
  nodeId: string;
  name: string;
  reason: string;
  input: Record<string, unknown>;
  depends_on: string[];
  metadata: Record<string, unknown>;
};

export type NormalizedPlan = {
  intent: string;
  actions: PlannedAction[];
  final_action_id: string;
  finalActionId: string;
};

type IntentRule = {
  intentInstruction: string;
  intentName: string;
  intentRegex: string;
  intentTool: string;
};

const textValue = (value: unknown): string => String(value || '').trim();
const listValue = (value: unknown): string[] => (Array.isArray(value) ? value.map((entry) => textValue(entry)).filter(Boolean) : []);
const recordValue = (value: unknown): Record<string, unknown> =>
  value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {};
const currentPlan = (value: unknown): Record<string, unknown> => {
  const source = recordValue(value);
  if (Array.isArray(source.actions)) return source;
  if (Array.isArray(recordValue(source.plan).actions)) return recordValue(source.plan);
  if (Array.isArray(recordValue(source.pendingPlan).actions)) return recordValue(source.pendingPlan);
  if (Array.isArray(recordValue(source.pending).actions)) return recordValue(source.pending);
  return {};
};

export const readPlannedActions = (value: unknown): { intent: string; actions: PlannedAction[]; finalActionId: string } => {
  const plan = currentPlan(value);
  const actions = (Array.isArray(plan.actions) ? plan.actions : [])
    .map((entry, index) => {
      const action = recordValue(entry);
      const metadata = { ...recordValue(action.metadata), modelId: textValue(action.modelId || action.toolModelId || recordValue(action.metadata).modelId) };
      return {
        id: textValue(action.id) || `a${index + 1}`,
        kind: textValue(action.kind || 'tool'),
        nodeId: textValue(action.nodeId || action.node_id || action.toolNodeId || action.toolId),
        name: textValue(action.name || action.toolName || action.tool || action.action),
        reason: textValue(action.reason || 'Workflow planned action.'),
        input: recordValue(action.input),
        depends_on: listValue(action.depends_on),
        metadata,
      };
    })
    .filter((entry) => entry.nodeId || entry.name || textValue(entry.metadata.modelId));
  return {
    intent: textValue(plan.intent),
    actions,
    finalActionId: textValue(plan.final_action_id || plan.finalActionId || actions[actions.length - 1]?.id),
  };
};

const stableActionInput = (value: unknown): string => {
  const input = recordValue(value);
  const keys = Object.keys(input).sort();
  const normalized: Record<string, unknown> = {};
  for (const key of keys) normalized[key] = input[key];
  return JSON.stringify(normalized);
};

export const normalizePlanActions = (plan: { intent: string; actions: PlannedAction[]; final_action_id: string; finalActionId: string }): NormalizedPlan => {
  const seen = new Map<string, PlannedAction>();
  const idRedirect = new Map<string, string>();
  for (const action of plan.actions) {
    const key = `${action.name}:${stableActionInput(action.input)}`;
    const existing = seen.get(key);
    if (existing) {
      idRedirect.set(action.id, existing.id);
      continue;
    }
    seen.set(key, action);
  }
  const actions = Array.from(seen.values());
  const ids = new Set(actions.map((action) => action.id));
  const normalizedActions = inferPlanActionDependencies(
    actions.map((action) => ({
      ...action,
      depends_on: (action.depends_on || [])
        .map((id) => idRedirect.get(id) || id)
        .filter((id, index, list) => id !== action.id && ids.has(id) && list.indexOf(id) === index),
    })),
  );
  return {
    ...plan,
    final_action_id: idRedirect.get(plan.final_action_id) || plan.final_action_id || actions[actions.length - 1]?.id || '',
    finalActionId: idRedirect.get(plan.finalActionId) || plan.finalActionId || actions[actions.length - 1]?.id || '',
    actions: normalizedActions,
  };
};

const actionInputText = (input: Record<string, unknown>, keys: string[]): string => {
  for (const key of keys) {
    const value = textValue(input[key]);
    if (value) return value;
  }
  return '';
};

const plannedActionTarget = (action: PlannedAction): string => {
  const input = { ...recordValue(action.input), ...recordValue(recordValue(action.input).actionInput), ...recordValue(recordValue(action.input).parameters) };
  const prefix = actionInputText(input, ['name_prefix', 'channel_name_prefix', 'category_name_prefix', 'subject_name_prefix', 'post_title_prefix']);
  if (prefix) return `starting with "${prefix}"`;
  const name = actionInputText(input, ['name', 'channel_name', 'category_name', 'subject_name', 'post_title', 'title', 'workflowName', 'workflow_name']);
  return name ? `"${name}"` : '';
};

export const plannedActionLabel = (action: PlannedAction): string => {
  const routedAction = textValue(recordValue(action.input).action);
  const label = textValue(routedAction || action.name).replace(/_/g, ' ');
  const target = plannedActionTarget(action);
  return target ? `${label} ${target}` : label;
};

export const confirmationMarkdown = (plan: { actions: PlannedAction[] }): string =>
  [
    'I can make these Giga changes after you confirm:',
    '',
    ...plan.actions.map((entry) => `- ${plannedActionLabel(entry)}: ${textValue(entry.reason) || 'Planned workflow action.'}`),
    '',
    'Reply with `confirm` to execute these actions or `cancel` to abort.',
  ].join('\n');

export const confirmationInteraction = (plan: { actions: PlannedAction[] }): Record<string, unknown> => ({
  kind: 'confirmation',
  title: 'Review and confirm',
  summary: `I need your approval before changing Giga. I will run ${plan.actions.length} planned action${plan.actions.length === 1 ? '' : 's'}.`,
  selection: {
    mode: 'multi',
    key: 'pending_actions',
    label: 'Pending actions',
    options: plan.actions.map((entry) => ({
      id: entry.id,
      label: plannedActionLabel(entry),
      description: textValue(entry.reason) || null,
      value: entry.id,
    })),
    value: plan.actions.map((entry) => entry.id),
  },
  options: [
    { id: 'confirm', label: 'Confirm', description: 'Execute the pending actions.', message: 'confirm', style: 'primary' },
    { id: 'cancel', label: 'Cancel', description: 'Discard the pending actions.', message: 'cancel', style: 'secondary' },
  ],
  free_text: null,
  sections: [
    {
      id: 'planned-actions',
      title: 'Planned actions',
      content_type: 'markdown',
      content: plan.actions.map((entry) => `- ${plannedActionLabel(entry)}: ${textValue(entry.reason) || 'No reason provided.'}`).join('\n'),
      default_collapsed: false,
    },
  ],
});

export const workflowCypherRules = [
  'Generated Workflow Cypher must use real node model ids only.',
  'Use model id chart for chart output; never use create_chart.',
  'For chart workflows, connect an LLM node to the chart node with source cmd:command and target cmd:llm.',
  'For chart workflows, set chart runtime.outputMode to "both" and preserve the returned [chart] markup verbatim in the final response.',
  'When generated workflows use run-channel-action, run-category-action, run-subject-action, run-post-action, run-user-tree-action, or run-chat-action, bind inspector fields through variables by setting runtime.chatId to "{{workflow.input.chatId}}" and runtime.message to "{{workflow.input.message}}"; do not write generated code that reads input.chatId or input.message directly.',
].join(' ');

const readIntentRules = (input: Record<string, unknown>): IntentRule[] =>
  (Array.isArray(input.intentRules) ? input.intentRules : [])
    .map((entry) => {
      const rule = recordValue(entry);
      return {
        intentInstruction: textValue(rule.intentInstruction),
        intentName: textValue(rule.intentName),
        intentRegex: textValue(rule.intentRegex),
        intentTool: textValue(rule.intentTool),
      };
    })
    .filter((rule) => rule.intentInstruction || rule.intentName || rule.intentRegex || rule.intentTool);

const readMatchedIntentGuidance = (input: Record<string, unknown>, onWarning?: (warning: string) => void): string[] => {
  const message = textValue(input.message);
  const guidance: string[] = [];
  for (const rule of readIntentRules(input)) {
    let matched = !rule.intentRegex;
    if (rule.intentRegex) {
      try {
        matched = new RegExp(rule.intentRegex, 'i').test(message);
      } catch {
        onWarning?.(`AI Agent intent regex is invalid and ignored: ${rule.intentRegex}`);
        continue;
      }
    }
    if (!matched) continue;
    guidance.push(
      [
        `Intent Name: ${rule.intentName || 'unnamed'}`,
        `Intent Tool: ${rule.intentTool || 'unspecified'}`,
        `Intent Instruction: ${rule.intentInstruction || 'none'}`,
      ].join(' | '),
    );
  }
  return guidance;
};

const intentGuidanceBlock = (input: Record<string, unknown>, onWarning?: (warning: string) => void): string => {
  const guidance = readMatchedIntentGuidance(input, onWarning);
  if (!guidance.length) return '';
  return `Matched Intent Rules:\n${guidance.map((entry, index) => `${index + 1}. ${entry}`).join('\n')}`;
};

const stripJsonFence = (value: string): string => value.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();

export const parsePlannerJson = (value: string): Record<string, unknown> => JSON.parse(stripJsonFence(value)) as Record<string, unknown>;

const plannerPrompt = (selectionPromptMd: string, catalog: Record<string, unknown>[], input: Record<string, unknown>, policy: string, onWarning?: (warning: string) => void) =>
  [
    'You are the workflow-native AI Agent planner.',
    'Return strict JSON only with {"intent":"string","actions":[{"id":"a1","nodeId":"connected_node_id","kind":"tool","reason":"why","input":{},"depends_on":[]}],"final_action_id":"a1"}.',
    'Use only connected tool nodes from the catalog.',
    'When selecting the Workflow tool, always set input.operation explicitly: save, publish, delete, attach, get, or list, based on the user request.',
    policy === 'tools-only' ? 'Do not plan model actions.' : '',
    input.workflowRequestIntent === true || input.workflowFollowupIntent === true ? `Workflow request intent is true. Workflow and Execute Workflow tools are allowed only when they match the user request. If a workflow save request has no explicit name, invent a concise workflowName from the user request. ${workflowCypherRules}` : '',
    intentGuidanceBlock(input, onWarning),
    `Connected tools: ${JSON.stringify({ actions: catalog })}`,
    `Current input: ${JSON.stringify(input)}`,
    `Selection Prompt: ${selectionPromptMd}`,
  ]
    .filter(Boolean)
    .join('\n\n');

export const groupedOnlyPlannerPrompt = (selectionPromptMd: string, catalog: Record<string, unknown>[], input: Record<string, unknown>, policy: string, onWarning?: (warning: string) => void) =>
  [
    plannerPrompt(selectionPromptMd, catalog, input, policy, onWarning),
    'Hard requirement: this request is not a workflow request.',
    'Do not select Workflow or Execute Workflow tools.',
    'Use grouped Action Router tools for channel/category/subject/post actions.',
  ].join('\n\n');

const requiredMutationPlannerPrompt = (selectionPromptMd: string, catalog: Record<string, unknown>[], input: Record<string, unknown>, policy: string, onWarning?: (warning: string) => void) =>
  [
    plannerPrompt(selectionPromptMd, catalog, input, policy, onWarning),
    'Hard requirement: this is a mutating user request.',
    'Return at least one executable action.',
    'Do not return an empty actions array.',
  ].join('\n\n');

const canRetryMutationPlan = (message: string): boolean =>
  message.includes('did not receive any executable actions') ||
  message.includes('missing required input') ||
  message.includes('Unexpected token') ||
  message.includes('JSON');

export const planUsesWorkflowTools = (plan: NormalizedPlan): boolean => {
  const workflowOnlyToolIds = new Set(['workflow', 'execute-workflow']);
  return plan.actions.some((entry) => workflowOnlyToolIds.has(String(entry.metadata.modelId || entry.nodeId || '').trim()));
};

export const selectPlanningPlan = async (params: {
  catalog: Record<string, unknown>[];
  initialPlan: NormalizedPlan | null;
  input: Record<string, unknown>;
  mutationIntent: boolean;
  parsePlan: (value: Record<string, unknown>) => NormalizedPlan;
  planningPolicy: string;
  runLlm: (prompt: string) => Promise<string>;
  selectionPrompt: string;
  onWarning?: (warning: string) => void;
  validatePlan: (plan: NormalizedPlan) => Promise<NormalizedPlan>;
  workflowFollowupIntent: boolean;
  workflowRequestIntent: boolean;
}): Promise<NormalizedPlan> => {
  let plan = params.initialPlan;
  if (!plan) {
    try {
      const raw = parsePlannerJson(await params.runLlm(plannerPrompt(params.selectionPrompt, params.catalog, params.input, params.planningPolicy, params.onWarning)));
      plan = params.parsePlan(raw);
    } catch (error) {
      if (!params.mutationIntent) throw error;
      const message = error instanceof Error ? error.message : String(error);
      if (!canRetryMutationPlan(message)) throw error;
      const prompt =
        params.workflowRequestIntent || params.workflowFollowupIntent
          ? requiredMutationPlannerPrompt(params.selectionPrompt, params.catalog, params.input, params.planningPolicy, params.onWarning)
          : groupedOnlyPlannerPrompt(params.selectionPrompt, params.catalog, params.input, params.planningPolicy, params.onWarning);
      plan = params.parsePlan(parsePlannerJson(await params.runLlm(prompt)));
    }
  }
  return params.validatePlan(plan || { intent: '', actions: [], final_action_id: '', finalActionId: '' });
};
