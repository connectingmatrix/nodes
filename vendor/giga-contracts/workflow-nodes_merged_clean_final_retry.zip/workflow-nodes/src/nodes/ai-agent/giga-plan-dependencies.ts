type PlanActionLike = {
  depends_on?: string[];
  id: string;
  input?: Record<string, unknown>;
  name: string;
};

const actionReferencePattern = /(?:^|[^a-zA-Z0-9_-])(?:to_be_filled_from_)?([a-zA-Z][a-zA-Z0-9_-]*\d+)(?:\.|}|$)/g;

type DependencyRule = {
  names: string[];
  referenceKeys: string[];
};

const channelKeys = ['id', 'channel_id', 'channelId', 'channel_name', 'channelName', 'name'];
const parentChannelKeys = ['parent_channel_id', 'parentChannelId', 'parent_channel_name', 'parentChannelName', 'parent_name'];
const categoryKeys = ['id', 'category_id', 'categoryId', 'category_name', 'categoryName', 'name'];
const parentCategoryKeys = ['parent_category_id', 'parentCategoryId', 'parent_category_name', 'parentCategoryName', 'parent_name'];
const subjectKeys = ['id', 'subject_id', 'subjectId', 'subject_name', 'subjectName', 'name'];
const parentSubjectKeys = ['parent_subject_id', 'parentSubjectId', 'parent_subject_name', 'parentSubjectName', 'parent_name'];
const postKeys = ['id', 'post_id', 'postId', 'post_title', 'postTitle', 'title', 'name'];
const workflowKeys = ['id', 'workflow_id', 'workflowId', 'workflow_name', 'workflowName', 'name'];
const actionDependencyRules: Record<string, DependencyRule[]> = {
  attach_workflow: [{ names: ['create_workflow_from_cypher', 'update_workflow', 'publish_workflow'], referenceKeys: workflowKeys }],
  create_category: [{ names: ['create_channel', 'create_category'], referenceKeys: [...parentChannelKeys, ...parentCategoryKeys, 'parent_id', 'parentId'] }],
  create_post: [{ names: ['create_subject'], referenceKeys: subjectKeys }],
  create_subject: [{ names: ['create_category', 'create_subject'], referenceKeys: [...categoryKeys, ...parentSubjectKeys, 'parent_id', 'parentId'] }],
  delete_category: [{ names: ['create_category'], referenceKeys: categoryKeys }],
  delete_channel: [{ names: ['create_channel'], referenceKeys: channelKeys }],
  delete_post: [{ names: ['create_post'], referenceKeys: postKeys }],
  delete_subject: [{ names: ['create_subject'], referenceKeys: subjectKeys }],
  delete_workflow: [{ names: ['create_workflow_from_cypher', 'update_workflow'], referenceKeys: workflowKeys }],
  execute_workflow: [{ names: ['create_workflow_from_cypher', 'update_workflow', 'publish_workflow'], referenceKeys: workflowKeys }],
  link_category: [
    { names: ['create_category'], referenceKeys: categoryKeys },
    { names: ['create_channel'], referenceKeys: ['channel_ids', 'channelIds', ...channelKeys] },
  ],
  link_channel: [
    { names: ['create_channel'], referenceKeys: channelKeys },
    { names: ['create_channel'], referenceKeys: parentChannelKeys },
  ],
  link_subject: [
    { names: ['create_subject'], referenceKeys: subjectKeys },
    { names: ['create_category'], referenceKeys: categoryKeys },
  ],
  publish_workflow: [{ names: ['create_workflow_from_cypher', 'update_workflow'], referenceKeys: workflowKeys }],
  read_category: [{ names: ['create_category'], referenceKeys: categoryKeys }],
  read_channel: [{ names: ['create_channel'], referenceKeys: channelKeys }],
  read_post: [{ names: ['create_post'], referenceKeys: postKeys }],
  read_subject: [{ names: ['create_subject'], referenceKeys: subjectKeys }],
  read_workflow: [{ names: ['create_workflow_from_cypher', 'update_workflow'], referenceKeys: workflowKeys }],
  unlink_category: [
    { names: ['link_category', 'create_category'], referenceKeys: categoryKeys },
    { names: ['link_category', 'create_channel'], referenceKeys: ['channel_ids', 'channelIds', ...channelKeys] },
  ],
  unlink_channel: [
    { names: ['link_channel', 'create_channel'], referenceKeys: channelKeys },
    { names: ['link_channel', 'create_channel'], referenceKeys: parentChannelKeys },
  ],
  unlink_subject: [
    { names: ['link_subject', 'create_subject'], referenceKeys: subjectKeys },
    { names: ['link_subject', 'create_category'], referenceKeys: categoryKeys },
  ],
  update_category: [{ names: ['create_category'], referenceKeys: categoryKeys }],
  update_channel: [{ names: ['create_channel'], referenceKeys: channelKeys }],
  update_post: [{ names: ['create_post'], referenceKeys: postKeys }],
  update_subject: [{ names: ['create_subject'], referenceKeys: subjectKeys }],
  update_workflow: [{ names: ['create_workflow_from_cypher'], referenceKeys: workflowKeys }],
};

const referencedActionIds = (value: unknown): string[] => {
  if (Array.isArray(value)) return value.flatMap(referencedActionIds);
  if (value && typeof value === 'object') return Object.values(value).flatMap(referencedActionIds);
  const text = String(value || '');
  return Array.from(text.matchAll(actionReferencePattern), (match) => String(match[1] || '').trim()).filter(Boolean);
};

const previousActionId = (actions: PlanActionLike[], index: number, names: string[]): string => {
  for (let cursor = index - 1; cursor >= 0; cursor -= 1) {
    if (names.includes(actions[cursor].name)) return actions[cursor].id;
  }
  return '';
};

const containsActionReference = (value: unknown): boolean => referencedActionIds(value).length > 0;
const hasConcreteReference = (input: Record<string, unknown>, keys: string[]): boolean =>
  keys.some((key) => {
    const value = input[key];
    if (Array.isArray(value)) return value.some((entry) => String(entry || '').trim() && !containsActionReference(entry));
    const text = String(value || '').trim();
    return Boolean(text) && !containsActionReference(text);
  });
const hasReferenceField = (input: Record<string, unknown>, keys: string[]): boolean => keys.some((key) => key in input);

const dependencyRuleNames = (action: PlanActionLike): string[][] =>
  (actionDependencyRules[action.name] || [])
    .filter((rule) => hasReferenceField(action.input || {}, rule.referenceKeys) && !hasConcreteReference(action.input || {}, rule.referenceKeys))
    .map((rule) => rule.names);

export const inferPlanActionDependencies = <Action extends PlanActionLike>(actions: Action[]): Action[] => {
  const ids = new Set(actions.map((action) => action.id));
  return actions.map((action, index) => {
    const explicit = action.depends_on || [];
    const references = referencedActionIds(action.input || {}).filter((id) => ids.has(id) && id !== action.id);
    const implicit = dependencyRuleNames(action).map((names) => previousActionId(actions, index, names));
    const dependsOn = [...explicit, ...references, ...implicit].filter((id, cursor, list) => id && id !== action.id && ids.has(id) && list.indexOf(id) === cursor);
    return { ...action, depends_on: dependsOn };
  });
};
