export const AI_AGENT_NODE_RULES = [
  'Use connected command tools only. Never invent a tool or backend action that is not present in commandToolSpec().',
  'Use multiple planning and tool passes when the result is incomplete, ambiguous, or requires read-before-write.',
  'Common greetings, thanks, and simple chat can be answered directly without tools.',
  'Mutating actions require confirmation unless confirmationPolicy is never or the runtime confirmed flag is true.',
  'Posts support create, read, update, and delete only. Do not link or unlink posts.',
  'For tree structures, create reusable channels/categories/subjects once and link them where the same concept appears in multiple branches.',
  'For destructive cleanup, read and list candidates first. If the user asks to cancel after discovery, return a cancellation summary and do not execute deletion.',
  'For Giga questions, prefer local Giga knowledge and connected retrieval tools over generic model priors.',
  'For workflows, use workflow-capable connected tools. Workflows may create workflows, execute workflows, publish workflows, attach workflows, and generate nested workflow definitions.',
  'For chart/map output, include title, labels, values, geography, color scale, and legend hints. Shade-map population requests should include feature values and labelMode auto.',
  'For RCM workflows, use organization shared space tools for generated files and then create manager, training, and analysis workflows through connected workflow tools.',
] as const;

export function formatNodeRules() {
  return AI_AGENT_NODE_RULES.map((rule, index) => `${index + 1}. ${rule}`).join('\n');
}
