export type QuickReplyRule = {
    intent?: string;
    pattern?: string;
    response?: string;
};

export type QuickReplyMatch = {
    intent: string;
    response: string;
};

export const defaultQuickReplyRules: QuickReplyRule[] = [
    {
        intent: 'Reply to a simple greeting.',
        pattern: '^(hello|hi|hey|howdy|good morning|good afternoon|good evening)[!. ]*$',
        response: "Hi! I'm here and ready to help with Giga, your content tree, workflows, posts, or anything else you want to work through."
    },
    {
        intent: 'Reply to a short capability question.',
        pattern: '^(how are you|can you help me|what can you do|give me a quick intro|what can you help me with(?: inside giga chat)?)[?!. ]*$',
        response: 'I can help with Giga chat, content trees, channels, categories, subjects, posts, workflows, charts, and safe cleanup plans.'
    },
    {
        intent: 'Explain chart options.',
        pattern: '^(what chart options are available|which chart options are available|what chart types are available|what charts can i create|show chart options)[?!. ]*$',
        response: 'Chart options live on the Chart node: use Auto for LLM-selected charts, pick a Library or Template when you want control, and fill Template Inputs for fixed chart data.'
    },
    {
        intent: 'Explain Giga content hierarchy.',
        pattern: '^(explain the difference between a subject and a post in giga|how can i structure my knowledge base for world politics|how does giga organize channels, categories, subjects, and posts)[?!. ]*$',
        response: 'In Giga, channels and categories organize the tree, subjects hold reusable knowledge areas, and posts hold the concrete notes or content inside a subject.'
    },
    {
        intent: 'Explain Giga linking.',
        pattern: '^(explain how this setup avoids duplicate nodes by linking|how does giga avoid duplicate nodes with linking|how do links prevent duplicate nodes in giga)[?!. ]*$',
        response: 'Giga avoids duplicate nodes by creating one reusable channel, category, or subject and linking it into other allowed branches instead of copying the same node again.'
    },
    {
        intent: 'Explain safe Giga cleanup.',
        pattern: '^what is the safest way to clean debug nodes in giga[?!. ]*$',
        response: 'The safest Giga cleanup flow is to find the debug nodes first, show the planned removals for confirmation, and only delete after the user confirms.'
    },
    {
        intent: 'Explain Giga workflow usage.',
        pattern: '^(when should i use workflow mode vs normal chat mode|summarize what giga ai can automate for content ops|how do workflow attachments work in giga chat)[?!. ]*$',
        response: 'Use normal Giga chat for quick answers and content guidance; use workflow mode when you want repeatable Giga automation for tree edits, cleanup, publishing, charts, attachments, or content operations.'
    },
    {
        intent: 'Explain Giga naming practices.',
        pattern: '^what are best practices for naming channels and categories[?!. ]*$',
        response: 'Use clear channel and category names that describe the branch purpose, keep wording consistent, and prefer stable names that make the Giga tree easy to scan.'
    },
    {
        intent: 'Explain Giga tree maintenance.',
        pattern: '^how do i keep my user tree clean over time[?!. ]*$',
        response: 'Keep your Giga tree clean by reviewing empty branches, confirming cleanup before deletes, linking reusable content instead of duplicating it, and naming channels consistently.'
    },
    {
        intent: 'Reply to a simple thanks.',
        pattern: '^(thanks|thank you|thx|appreciate it)[!. ]*$',
        response: "You're welcome. I'm here when you're ready for the next thing."
    },
    {
        intent: 'Explain unsupported post linking.',
        pattern: '\\b(link|links|linking|unlink|unlinks|unlinking|attach|attaches|attaching|detach|detaches|detaching)\\b[\\s\\S]*\\bposts?\\b|\\bposts?\\b[\\s\\S]*\\b(link|links|linking|unlink|unlinks|unlinking|attach|attaches|attaching|detach|detaches|detaching)\\b',
        response: 'Posts support create, read, update, and delete only. Link or unlink post operations are unsupported.'
    }
];

const wordCount = (message: string): number => message.trim().split(/\s+/).filter(Boolean).length;

export const quickReplyMatch = (message: string, rules: QuickReplyRule[], maxWords = 14): QuickReplyMatch | null => {
    const text = message.trim();
    if (!text || wordCount(text) > maxWords) return null;
    for (const rule of rules) {
        if (!rule.pattern || !rule.response) continue;
        try {
            if (!new RegExp(rule.pattern, 'i').test(text)) continue;
            return { intent: rule.intent || 'Direct reply.', response: rule.response };
        } catch (_error) {
            continue;
        }
    }
    return null;
};
