export type ContentActionName =
    | 'create_channel'
    | 'read_channel'
    | 'update_channel'
    | 'delete_channel'
    | 'link_channel'
    | 'unlink_channel'
    | 'create_category'
    | 'read_category'
    | 'update_category'
    | 'delete_category'
    | 'link_category'
    | 'unlink_category'
    | 'create_subject'
    | 'read_subject'
    | 'update_subject'
    | 'delete_subject'
    | 'link_subject'
    | 'unlink_subject'
    | 'create_post'
    | 'read_post'
    | 'update_post'
    | 'delete_post';

export type ContentAuthoringAction = {
    action: ContentActionName;
    depends_on: string[];
    id: string;
    parameters: Record<string, unknown>;
    reason: string;
};

export type ContentAuthoringPlan = {
    actions: ContentAuthoringAction[];
    intent: string;
};

export type ContentAuthoringTool = {
    allowedActions: string[];
    modelId?: string;
    name?: string;
    nodeId: string;
};

export type ContentAuthoringOptions = {
    cleanupPrefixPattern?: string;
    enabled?: boolean;
    structureRequestPattern?: string;
};

export const defaultContentCleanupPrefixPattern = '"([^"]*-\\*?)"|\\b([a-zA-Z0-9][a-zA-Z0-9_-]*-\\*)\\b';
export const defaultContentStructureRequestPattern = '\\b(tree|content)\\s+structure\\b[\\s\\S]*?\\b(?:organise|organize)\\b\\s+(.+?)(?:\\s+wise|[.!?]|$)';

const quoted = (message: string): string[] => Array.from(message.matchAll(/"([^"]+)"/g), (match) => String(match[1] || '').trim()).filter(Boolean);
const has = (message: string, pattern: RegExp): boolean => pattern.test(message);
const words = {
    category: /\bcategor(?:y|ies)\b/i,
    channel: /\bchannels?\b/i,
    create: /\b(create|add|make|build)\b/i,
    delete: /\b(delete|deletion|remove|removal)\b/i,
    link: /\blink\b/i,
    post: /\bposts?\b/i,
    read: /\b(read|get|show|fetch|list)\b/i,
    subject: /\bsubjects?\b/i,
    unlink: /\bunlink|detach\b/i,
    update: /\b(update|edit|rename|change|move)\b/i,
};

const toolFor = (tools: ContentAuthoringTool[], action: ContentActionName): ContentAuthoringTool | null =>
    tools.find((tool) => tool.allowedActions.includes(action)) || null;

const categorySubjectMatch = (message: string): { category: string; subject: string } | null => {
    const under = message.match(/subject\s+"([^"]+)"[\s\S]{0,80}\bunder\s+category\s+"([^"]+)"/i);
    if (under?.[1] && under?.[2]) return { subject: under[1].trim(), category: under[2].trim() };
    const createBoth = message.match(/category\s+"([^"]+)"[\s\S]{0,100}subject\s+"([^"]+)"/i);
    if (createBoth?.[1] && createBoth?.[2]) return { category: createBoth[1].trim(), subject: createBoth[2].trim() };
    return null;
};

const subjectPostMatch = (message: string): { category: string; subject: string; post: string } | null => {
    const explicit = message.match(/category\s+"([^"]+)"[\s\S]{0,120}subject\s+"([^"]+)"[\s\S]{0,120}post\s+"([^"]+)"/i);
    if (explicit?.[1] && explicit?.[2] && explicit?.[3]) return { category: explicit[1].trim(), subject: explicit[2].trim(), post: explicit[3].trim() };
    const subjectPost = message.match(/subject\s+"([^"]+)"[\s\S]{0,100}post\s+"([^"]+)"/i);
    if (subjectPost?.[1] && subjectPost?.[2]) return { category: `${subjectPost[1].trim()} Category`, subject: subjectPost[1].trim(), post: subjectPost[2].trim() };
    return null;
};

const postMoveMatch = (message: string): { category: string; sourceSubject: string; targetSubject: string; post: string } | null => {
    const category = message.match(/category\s+"([^"]+)"/i)?.[1]?.trim();
    const subjects = message.match(/subjects?\s+"([^"]+)"\s+and\s+"([^"]+)"/i);
    const post = message.match(/post\s+"([^"]+)"/i)?.[1]?.trim();
    const sourceSubject = message.match(/post\s+"[^"]+"[\s\S]{0,120}\bunder\s+subject\s+"([^"]+)"/i)?.[1]?.trim() || subjects?.[1]?.trim();
    const targetSubject = message.match(/\bmove\b[\s\S]{0,120}\bsubject\s+"([^"]+)"/i)?.[1]?.trim() || subjects?.[2]?.trim();
    if (!category || !post || !sourceSubject || !targetSubject || sourceSubject === targetSubject) return null;
    return { category, sourceSubject, targetSubject, post };
};

const fullContentMatch = (message: string): { category: string; channel: string; post: string; subject: string } | null => {
    const match = message.match(/channel\s+"([^"]+)"[\s\S]{0,160}category\s+"([^"]+)"[\s\S]{0,160}subject\s+"([^"]+)"[\s\S]{0,160}post\s+"([^"]+)"/i);
    if (!match?.[1] || !match[2] || !match[3] || !match[4]) return null;
    return { channel: match[1].trim(), category: match[2].trim(), subject: match[3].trim(), post: match[4].trim() };
};

const deletePrefixMatch = (message: string, pattern: string): string => {
    try {
        const match = message.match(new RegExp(pattern, 'i'));
        return String(match?.[1] || match?.[2] || '').replace(/\*+$/g, '').trim();
    } catch {
        return '';
    }
};

const titleLabel = (value: string): string =>
    value
        .replace(/\b(the|a|an)\b/gi, ' ')
        .replace(/[^a-z0-9]+/gi, ' ')
        .trim()
        .split(/\s+/)
        .filter(Boolean)
        .map((word) => `${word.slice(0, 1).toUpperCase()}${word.slice(1).toLowerCase()}`)
        .join(' ');

const pluralLabel = (value: string): string => {
    const label = titleLabel(value);
    if (!label || /s$/i.test(label)) return label;
    if (/y$/i.test(label)) return `${label.slice(0, -1)}ies`;
    return `${label}s`;
};

const structureParts = (value: string): string[] =>
    value
        .replace(/\band\b/gi, ',')
        .split(',')
        .map(titleLabel)
        .filter(Boolean);

const structureRequest = (message: string, pattern: string): { dimensions: string[]; kind: 'content' | 'tree'; topic: string } | null => {
    let match: RegExpMatchArray | null = null;
    try {
        match = message.match(new RegExp(pattern, 'i'));
    } catch {
        return null;
    }
    const kind = /content/i.test(String(match?.[1] || '')) ? 'content' : /tree/i.test(String(match?.[1] || '')) ? 'tree' : null;
    const parts = structureParts(String(match?.[2] || ''));
    if (!kind || parts.length < 2) return null;
    return { kind, topic: parts[0], dimensions: parts.slice(1) };
};

export const createContentAuthoringPlan = (message: string, options: ContentAuthoringOptions = {}): ContentAuthoringPlan | null => {
    if (options.enabled === false) return null;
    const cleanupPrefixPattern = options.cleanupPrefixPattern || defaultContentCleanupPrefixPattern;
    const structureRequestPattern = options.structureRequestPattern || defaultContentStructureRequestPattern;
    const deletePrefix = deletePrefixMatch(message, cleanupPrefixPattern);
    const prefixCleanup = Boolean(deletePrefix) && /\bdata nodes?\b/i.test(message);
    if (!has(message, words.create) && !has(message, words.link) && !has(message, words.unlink) && !has(message, words.delete)) return null;
    const structure = structureRequest(message, structureRequestPattern);
    if (!structure && !prefixCleanup && !has(message, words.channel) && !has(message, words.category) && !has(message, words.subject) && !has(message, words.post)) return null;
    const names = quoted(message);
    const actions: ContentAuthoringAction[] = [];
    const add = (action: ContentActionName, reason: string, parameters: Record<string, unknown>, depends_on: string[] = []) => {
        actions.push({ action, depends_on, id: `a${actions.length + 1}`, parameters, reason });
        return actions[actions.length - 1].id;
    };

    if (has(message, words.delete) && !has(message, words.create) && deletePrefix && (prefixCleanup || has(message, words.channel))) {
        add('delete_channel', `Delete channel branches starting with "${deletePrefix}".`, { name_prefix: deletePrefix });
        return { intent: 'Plan channel prefix cleanup operations.', actions };
    }

    if (structure) {
        const channel = add('create_channel', `Create the ${structure.topic} root channel.`, { name: structure.topic });
        let parentCategory = '';
        for (const dimension of structure.dimensions) {
            const category = add('create_category', `Create ${pluralLabel(dimension)} under ${parentCategory || structure.topic}.`, parentCategory ? { name: pluralLabel(dimension), parent_category_action_id: parentCategory } : { name: pluralLabel(dimension), parent_channel_action_id: channel }, parentCategory ? [parentCategory] : [channel]);
            if (structure.kind === 'content') add('create_subject', `Create ${structure.topic} by ${dimension} subject.`, { name: `${structure.topic} by ${dimension}`, category_action_id: category }, [category]);
            parentCategory = category;
        }
        return { intent: `Plan ${structure.kind} structure operations for ${structure.topic}.`, actions };
    }

    const fullContent = fullContentMatch(message);
    if (fullContent) {
        const channel = add('create_channel', `Create channel "${fullContent.channel}".`, { name: fullContent.channel });
        const category = add('create_category', `Create category "${fullContent.category}".`, { name: fullContent.category, parent_channel_action_id: channel }, [channel]);
        const subject = add('create_subject', `Create subject "${fullContent.subject}".`, { name: fullContent.subject, category_action_id: category }, [category]);
        const post = add('create_post', `Create post "${fullContent.post}".`, { title: fullContent.post, subject_action_id: subject }, [subject]);
        if (has(message, words.read)) {
            add('read_channel', 'Read the created channel.', { channel_action_id: channel }, [channel]);
            add('read_category', 'Read the created category.', { category_action_id: category }, [category]);
            add('read_subject', 'Read the created subject.', { subject_action_id: subject }, [subject]);
            add('read_post', 'Read the created post.', { post_action_id: post }, [post]);
        }
        return { intent: 'Plan full content branch operations.', actions };
    }

    if (has(message, words.channel) && !has(message, words.category) && !has(message, words.subject) && !has(message, words.post)) {
        if ((has(message, words.link) || has(message, words.unlink)) && names.length >= 2) {
            const parent = add('create_channel', `Create parent channel "${names[0]}".`, { name: names[0] });
            const child = add('create_channel', `Create child channel "${names[1]}".`, { name: names[1] });
            const link = add('link_channel', 'Link child channel to parent channel.', { parent_channel_action_id: parent, channel_action_id: child }, [parent, child]);
            if (has(message, words.unlink)) add('unlink_channel', 'Remove the channel link.', { parent_channel_action_id: parent, channel_action_id: child }, [link]);
            return { intent: 'Plan channel link operations.', actions };
        }
        if (!names[0]) return null;
        const first = add('create_channel', `Create channel "${names[0]}".`, { name: names[0] });
        if (has(message, words.read)) add('read_channel', 'Read the created channel.', { channel_action_id: first }, [first]);
        if (has(message, words.update) && names[1]) add('update_channel', `Rename channel to "${names[1]}".`, { channel_action_id: first, name: names[1] }, [first]);
        if (has(message, words.delete)) add('delete_channel', 'Delete the created channel.', { channel_action_id: first }, [first]);
        return { intent: 'Plan channel operations.', actions };
    }

    if (has(message, words.category) && has(message, words.channel) && !has(message, words.subject) && names.length >= 2) {
        const channel = add('create_channel', `Create channel "${names[0]}".`, { name: names[0] });
        const category = add('create_category', `Create category "${names[1]}".`, { name: names[1] });
        const link = add('link_category', 'Link category to channel.', { category_action_id: category, channel_action_id: channel }, [channel, category]);
        if (has(message, words.unlink)) add('unlink_category', 'Remove the category link.', { category_action_id: category, channel_action_id: channel }, [link]);
        return { intent: 'Plan category/channel operations.', actions };
    }

    if (has(message, words.category) && !has(message, words.subject) && names[0]) {
        const first = add('create_category', `Create category "${names[0]}".`, { name: names[0] });
        if (has(message, words.read)) add('read_category', 'Read the created category.', { category_action_id: first }, [first]);
        if (has(message, words.update) && names[1]) add('update_category', `Rename category to "${names[1]}".`, { category_action_id: first, name: names[1] }, [first]);
        if (has(message, words.delete)) add('delete_category', 'Delete the created category.', { category_action_id: first }, [first]);
        return { intent: 'Plan category operations.', actions };
    }

    if (has(message, words.subject) && has(message, words.channel) && names.length >= 2) {
        const channel = add('create_channel', `Create channel "${names[1]}".`, { name: names[1] });
        const category = add('create_category', `Create category "${names[1]} Subjects".`, { name: `${names[1]} Subjects`, parent_channel_action_id: channel }, [channel]);
        const subject = add('create_subject', `Create subject "${names[0]}".`, { name: names[0], category_action_id: category }, [category]);
        if (has(message, words.link)) add('link_subject', 'Link subject to the channel category.', { subject_action_id: subject, category_action_id: category }, [subject]);
        if (has(message, words.unlink)) add('unlink_subject', 'Remove the subject link from the channel category.', { subject_action_id: subject, category_action_id: category }, [subject]);
        return { intent: 'Plan subject/channel operations through a category.', actions };
    }

    const postMove = postMoveMatch(message);
    if (postMove) {
        const category = add('create_category', `Create category "${postMove.category}".`, { name: postMove.category });
        const sourceSubject = add('create_subject', `Create source subject "${postMove.sourceSubject}".`, { name: postMove.sourceSubject, category_action_id: category }, [category]);
        const targetSubject = add('create_subject', `Create target subject "${postMove.targetSubject}".`, { name: postMove.targetSubject, category_action_id: category }, [category]);
        const post = add('create_post', `Create post "${postMove.post}".`, { title: postMove.post, subject_action_id: sourceSubject }, [sourceSubject]);
        add('update_post', `Move post "${postMove.post}" to subject "${postMove.targetSubject}".`, { post_action_id: post, subject_action_id: targetSubject }, [post, targetSubject]);
        return { intent: 'Plan post move operations.', actions };
    }

    const subjectPost = subjectPostMatch(message);
    if (subjectPost) {
        const category = add('create_category', `Create category "${subjectPost.category}".`, { name: subjectPost.category });
        const subject = add('create_subject', `Create subject "${subjectPost.subject}".`, { name: subjectPost.subject, category_action_id: category }, [category]);
        const post = add('create_post', `Create post "${subjectPost.post}".`, { title: subjectPost.post, subject_action_id: subject }, [subject]);
        if (has(message, words.read)) add('read_post', 'Read the created post.', { post_action_id: post }, [post]);
        if (has(message, words.update) && names.length > 2) add('update_post', `Rename post to "${names[names.length - 1]}".`, { post_action_id: post, title: names[names.length - 1] }, [post]);
        if (has(message, words.delete)) add('delete_post', 'Delete the created post.', { post_action_id: post }, [post]);
        return { intent: 'Plan post operations.', actions };
    }

    const categorySubject = categorySubjectMatch(message);
    if (categorySubject) {
        const category = add('create_category', `Create category "${categorySubject.category}".`, { name: categorySubject.category });
        const subject = add('create_subject', `Create subject "${categorySubject.subject}".`, { name: categorySubject.subject, category_action_id: category }, [category]);
        if (has(message, words.read)) add('read_subject', 'Read the created subject.', { subject_action_id: subject }, [subject]);
        if (has(message, words.update) && names.length > 2) add('update_subject', `Rename subject to "${names[names.length - 1]}".`, { subject_action_id: subject, name: names[names.length - 1] }, [subject]);
        if (has(message, words.delete)) add('delete_subject', 'Delete the created subject.', { subject_action_id: subject }, [subject]);
        if (has(message, words.link)) add('link_subject', 'Link subject to category.', { subject_action_id: subject, category_action_id: category }, [subject]);
        if (has(message, words.unlink)) add('unlink_subject', 'Remove the subject link.', { subject_action_id: subject, category_action_id: category }, [subject]);
        return { intent: 'Plan subject/category operations.', actions };
    }

    return null;
};

export const createContentAuthoringNodePlan = (message: string, tools: ContentAuthoringTool[], options: ContentAuthoringOptions = {}) => {
    const plan = createContentAuthoringPlan(message, options);
    if (!plan) return null;
    const actions = plan.actions.map((action) => {
        const tool = toolFor(tools, action.action);
        return tool ? { id: action.id, kind: 'tool' as const, nodeId: tool.nodeId, name: action.action, reason: action.reason, input: { action: action.action, parameters: action.parameters }, depends_on: action.depends_on } : null;
    });
    if (actions.some((action) => !action)) return null;
    return { intent: plan.intent, actions: actions.filter(Boolean), final_action_id: plan.actions[plan.actions.length - 1]?.id || '' };
};
