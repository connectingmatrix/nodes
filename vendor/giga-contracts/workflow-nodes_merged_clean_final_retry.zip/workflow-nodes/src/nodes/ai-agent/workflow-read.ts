export type WorkflowReadTool = {
    modelId?: string;
    name?: string;
    nodeId: string;
};

export type WorkflowReadPlan = {
    actions: Array<{
        depends_on: string[];
        id: string;
        input: Record<string, unknown>;
        kind: 'tool';
        name: string;
        nodeId: string;
        reason: string;
    }>;
    final_action_id: string;
    intent: string;
};

const readVerbPattern = /\b(read|list|show|get|fetch)\b/i;
const workflowPattern = /\bworkflows?\b/i;
const genericListPattern = /\b(all|list|show|fetch|get)\s+(the\s+)?workflows?\b/i;
const quotedName = (message: string): string => message.match(/"([^"]+)"/)?.[1]?.trim() || '';

export const isWorkflowReadMessage = (message: string): boolean => workflowPattern.test(message) && readVerbPattern.test(message);

export const workflowReadName = (message: string): string =>
    quotedName(message) ||
    message
        .replace(/[?!.]+$/g, '')
        .replace(/\b(read|list|show|get|fetch|the|a|an)\b/gi, ' ')
        .replace(/\bworkflows?\b/gi, ' ')
        .replace(/\s+/g, ' ')
        .trim();

export const createWorkflowReadNodePlan = (message: string, tools: WorkflowReadTool[]): WorkflowReadPlan | null => {
    const workflowTool = tools.find((tool) => tool.modelId === 'workflow') || null;
    if (!workflowTool || !isWorkflowReadMessage(message)) return null;
    const name = workflowReadName(message);
    const input = name.length > 2 && !genericListPattern.test(message) ? { operation: 'get', workflowName: name } : { operation: 'list', limit: 10 };
    return {
        intent: name ? 'Read one workflow without mutating Giga.' : 'List workflows without mutating Giga.',
        actions: [{ id: 'a1', kind: 'tool', nodeId: workflowTool.nodeId, name: workflowTool.name || 'Workflow', reason: name ? 'The user asked to read a specific workflow.' : 'The user asked to list workflows.', input, depends_on: [] }],
        final_action_id: 'a1'
    };
};
