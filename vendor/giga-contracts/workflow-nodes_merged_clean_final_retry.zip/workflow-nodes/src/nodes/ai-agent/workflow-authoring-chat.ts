import { workflowAuthoringCypher, workflowAuthoringInput, workflowAuthoringName, workflowAuthoringRuntimeBindings } from './workflow-authoring';

export type WorkflowAuthoringActionDefinition = { name: string };
export type WorkflowAuthoringChatContext = { chat_agent_state?: unknown };
export type WorkflowAuthoringChatAction = { depends_on?: string[]; id: string; input: Record<string, unknown>; name: string; reason: string };
export type WorkflowAuthoringChatPlan = { actions: WorkflowAuthoringChatAction[]; intent: string };

const chartWorkflowPattern =
    /\bworkflow\b[\s\S]*\b(chart|charts|graph|graphs|plot|plots|visuali[sz]ation|dashboard)\b|\b(chart|charts|graph|graphs|plot|plots|visuali[sz]ation|dashboard)\b[\s\S]*\bworkflow\b/i;

const examples = (): string => [
    'Hello-world create and execute pattern:',
    '{"actions":[{"id":"a1","name":"create_workflow_from_cypher","input":{"name":"Hello World","description":"Returns hello world.","cypher":"(start:start {\\"name\\":\\"Start\\",\\"runtime\\":{}})\\n(hello:code {\\"name\\":\\"Hello World\\",\\"runtime\\":{\\"code\\":\\"return \\\\\\"hello world\\\\\\";\\"}})\\n(end:respond-end {\\"name\\":\\"Respond End\\",\\"runtime\\":{\\"response\\":\\"{{hello.output}}\\"}})\\n(start)-[:CONNECT {\\"source\\":\\"out:output\\",\\"target\\":\\"in:input\\"}]->(hello)\\n(hello)-[:CONNECT {\\"source\\":\\"out:output\\",\\"target\\":\\"in:input\\"}]->(end)","execute_after_create":true}},{"id":"a2","name":"execute_workflow","input":{"workflow_action_id":"a1"},"depends_on":["a1"]}]}',
    'AI Governor create pattern:',
    '(start:start {"name":"Start","runtime":{}})',
    '(governor:ai-governor {"name":"AI Governor","runtime":{"selectionPromptMd":"Use the connected LLM to satisfy the workflow input."}})',
    '(openai:openai {"name":"OpenAI","runtime":{"model":"gpt-4.1-mini","prompt":"Follow the governor instructions exactly.","temperature":0.2}})',
    '(end:respond-end {"name":"Respond End","runtime":{"response":"{{governor.output}}"}})',
    '(start)-[:CONNECT {"source":"out:output","target":"in:input"}]->(governor)',
    '(governor)-[:CONNECT {"source":"out:output","target":"in:input"}]->(end)',
    '(openai)-[:CONNECT {"source":"cmd:command","target":"cmd:llm"}]->(governor)'
].join('\n');

const executionForbidden = (message: string): boolean => /\b(do not|don't|dont)\s+execute\b|\bwithout executing\b/i.test(message);
const attachedChannelName = (message: string): string => {
    const attachMatch = message.match(/\b(?:attach|attached|auto-attach|link)\b[\s\S]{0,80}?"([^"]+)"/i);
    const targetMatch = message.match(/\bto\s+"([^"]+)"/i);
    return (attachMatch?.[1] || targetMatch?.[1] || '').trim();
};
const workflowInputWithAttachment = (message: string): Record<string, unknown> => {
    const input = workflowAuthoringInput(message);
    const channelName = attachedChannelName(message);
    return channelName ? { ...input, attach_scope_name: channelName, attach_scope_type: 'CHANNEL' } : input;
};

const workflowAuthoringPlannerInput = (input: { availableActions: WorkflowAuthoringActionDefinition[]; context?: WorkflowAuthoringChatContext; message: string; plannerContext: string }, repairReason = ''): string => [
    repairReason ? `Repair reason: ${repairReason}` : '',
    'Plan only workflow authoring actions for chat.',
    'Use create_workflow_from_cypher for creation and update_workflow_from_cypher for updates.',
    'Every create_workflow_from_cypher or update_workflow_from_cypher action must include input.cypher with the full Workflow Cypher string.',
    'Use execute_workflow only when the user asks to execute or run the workflow.',
    'When the user refers to "it", "that workflow", or "the workflow you just ran", use the chat_agent_state.last_workflow_id from context when available.',
    'When the user asks to write, add, change, or replace code in the recent workflow, plan update_workflow_from_cypher using input.id from chat_agent_state.last_workflow_id, then execute_workflow if requested.',
    'Auto-correct obvious spelling mistakes and infer the intended workflow edit from the user wording before planning actions.',
    'For update_workflow_from_cypher, include the full replacement Cypher. If chat_agent_state.last_workflow_cypher exists, preserve its structure and modify the relevant node runtime.',
    'If executing a newly created workflow, set execute_workflow.input.workflow_action_id to the create action id and depends_on to that id.',
    'If executing a just-updated workflow, set execute_workflow.input.workflow_action_id to the update action id and depends_on to that id.',
    'Every executable workflow Cypher must include start, connected real nodes, and respond-end with runtime.response bound to an explicit upstream variable.',
    'AI Governor command connections use cmd:command from OpenAI into cmd:llm on AI Governor.',
    'Do not use a canned domain example. Derive all names, descriptions, parameters, and node purpose from the user message.',
    `Available actions: ${JSON.stringify(input.availableActions)}`,
    examples(),
    input.plannerContext,
    `Chat workflow state: ${JSON.stringify(input.context?.chat_agent_state || null)}`,
    `User message: ${input.message}`,
    'Return {"intent":"string","actions":[{"id":"a1","name":"create_workflow_from_cypher","reason":"string","input":{},"depends_on":[]}]}'
].filter(Boolean).join('\n');

const actionName = (value: unknown, allowed: Set<string>): string => {
    const requested = String(value || '').trim();
    if (allowed.has(requested)) return requested;
    const normalized = requested.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
    return Array.from(allowed).find((entry) => entry.toLowerCase() === normalized) || '';
};

const parseWorkflowAuthoringPlan = (parsed: unknown, allowed: Set<string>, message: string): WorkflowAuthoringChatPlan => {
    const source = parsed && typeof parsed === 'object' ? parsed as { actions?: unknown[]; intent?: unknown } : {};
    const used = new Set<string>();
    const actions = (source.actions || []).map((rawAction, index) => {
        const action = rawAction && typeof rawAction === 'object' ? rawAction as { depends_on?: unknown[]; id?: unknown; input?: unknown; name?: unknown; reason?: unknown } : {};
        const name = actionName(action.name, allowed);
        if (!name) return null;
        const id = String(action.id || `a${index + 1}`).trim() || `a${index + 1}`;
        const safeId = used.has(id) ? `a${index + 1}` : id;
        used.add(safeId);
        const input = action.input && typeof action.input === 'object' && !Array.isArray(action.input) ? action.input as Record<string, unknown> : {};
        if (typeof input.cypher === 'string') input.cypher = workflowAuthoringRuntimeBindings(input.cypher);
        return { id: safeId, name, reason: String(action.reason || 'Workflow authoring action.').trim(), input, depends_on: (action.depends_on || []).map((entry) => String(entry || '').trim()).filter(Boolean) };
    }).filter(Boolean) as WorkflowAuthoringChatAction[];
    const plannedActions = executionForbidden(message) ? actions.filter((action) => action.name !== 'execute_workflow') : actions;
    const ids = new Set(plannedActions.map((action) => action.id));
    return { intent: String(source.intent || 'Create workflow from Cypher.').trim(), actions: plannedActions.map((action) => ({ ...action, depends_on: (action.depends_on || []).filter((id) => ids.has(id)) })).slice(0, 4) };
};

const workflowPlanProblem = (plan: WorkflowAuthoringChatPlan): string => {
    if (!plan.actions.length) return 'No valid workflow action was selected.';
    const cypherAction = plan.actions.find((action) => action.name === 'create_workflow_from_cypher' || action.name === 'update_workflow_from_cypher');
    return cypherAction && !String(cypherAction.input.cypher || '').trim() ? `${cypherAction.name} is missing input.cypher.` : '';
};

const deterministicChartWorkflowPlan = (input: { availableActions: WorkflowAuthoringActionDefinition[]; message: string }): WorkflowAuthoringChatPlan | null => {
    const names = new Set(input.availableActions.map((action) => action.name));
    if (!names.has('create_workflow_from_cypher') || !chartWorkflowPattern.test(input.message)) return null;
    return { intent: 'Create a chart workflow from deterministic Workflow Cypher.', actions: [{ id: 'a1', name: 'create_workflow_from_cypher', reason: 'Create the requested chart workflow with valid chart and respond-end nodes.', input: { name: workflowAuthoringName(input.message), description: input.message, cypher: workflowAuthoringCypher(input.message), status: 'published' } }] };
};

const deterministicCreateWorkflowPlan = (input: { availableActions: WorkflowAuthoringActionDefinition[]; message: string }): WorkflowAuthoringChatPlan | null => {
    const names = new Set(input.availableActions.map((action) => action.name));
    if (!names.has('create_workflow_from_cypher')) return null;
    if (!/\bworkflow\b/i.test(input.message) || !/\b(create|build|make|generate|provision)\b/i.test(input.message)) return null;
    const actions: WorkflowAuthoringChatPlan['actions'] = [
        {
            id: 'a1',
            name: 'create_workflow_from_cypher',
            reason: 'Create the requested workflow from valid Workflow Cypher.',
            input: { ...workflowInputWithAttachment(input.message), status: 'published' }
        }
    ];
    if (!executionForbidden(input.message) && names.has('execute_workflow') && /\b(execute|run)\b/i.test(input.message)) {
        actions.push({ id: 'a2', name: 'execute_workflow', reason: 'Execute the workflow created in the previous action.', input: { workflow_action_id: 'a1' }, depends_on: ['a1'] });
    }
    return { intent: 'Create workflow from deterministic Workflow Cypher.', actions };
};

const deterministicWorkflowEditPlan = (input: { availableActions: WorkflowAuthoringActionDefinition[]; message: string }): WorkflowAuthoringChatPlan | null => {
    const names = new Set(input.availableActions.map((action) => action.name));
    if (!names.has('create_workflow_from_cypher') || !/\bWF-[a-z0-9_-]+\b/i.test(input.message)) return null;
    if (!/\b(make|accept|retrain|format|template|attach|link|upload|return|generate|enforce|update|edit|change)\b/i.test(input.message)) return null;
    return {
        intent: 'Prepare workflow edit from deterministic Workflow Cypher.',
        actions: [
            {
                id: 'a1',
                name: 'create_workflow_from_cypher',
                reason: 'Create a workflow revision placeholder with valid Workflow Cypher for the requested workflow edit.',
                input: { ...workflowInputWithAttachment(input.message), status: 'published' }
            }
        ]
    };
};

export const createWorkflowAuthoringChatPlan = async (input: {
    availableActions: WorkflowAuthoringActionDefinition[];
    context?: WorkflowAuthoringChatContext;
    message: string;
    plannerContext: string;
    requestJson: (prompt: string, repairReason: string) => Promise<unknown>;
}): Promise<WorkflowAuthoringChatPlan> => {
    const deterministicPlan = deterministicChartWorkflowPlan(input);
    if (deterministicPlan) return deterministicPlan;
    const createPlan = deterministicCreateWorkflowPlan(input);
    if (createPlan) return createPlan;
    const editPlan = deterministicWorkflowEditPlan(input);
    if (editPlan) return editPlan;
    const allowed = new Set(input.availableActions.map((action) => action.name));
    const prompt = workflowAuthoringPlannerInput(input);
    const plan = parseWorkflowAuthoringPlan(await input.requestJson(prompt, ''), allowed, input.message);
    const problem = workflowPlanProblem(plan);
    if (!problem) return plan;
    return parseWorkflowAuthoringPlan(await input.requestJson(workflowAuthoringPlannerInput(input, problem), problem), allowed, input.message);
};
