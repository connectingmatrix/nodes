# AI Agent

Worker-owned AI orchestration node for planning, confirmation, tool execution, and final chat responses.

- Connect one LLM on `cmd:llm`.
- Connect grouped action tools on `cmd:tools`.
- Connect workflow authoring and execution tools on `cmd:workflow`.
- Bind `message`, intent flags, `context`, and `pendingPlan` through inspector variables.

The node emits the final public chat response envelope, including `text`, `markdown`, and structured `agent` metadata.
