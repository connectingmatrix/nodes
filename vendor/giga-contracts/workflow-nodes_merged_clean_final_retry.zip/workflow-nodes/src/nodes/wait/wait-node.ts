import rawSchema from '@workflow/nodes/nodes/wait/wait-schema.json';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';
import { WorkflowNodeKindEnum } from '@workflow/nodes/types';

const schema = parseNodeSchema(rawSchema, 'wait');

const renderWaitIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <circle cx="24" cy="24" r="16" stroke="currentColor" stroke-width="2.4"/>
  <path d="M24 15v10l7 4" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;

const waitNodeModule: WorkflowNodeModule = {
    id: 'wait',
    schema,
    library: {
        id: 'wait-node',
        label: 'Wait',
        description: 'Pause workflow execution for a bounded duration and then continue.',
        gigaId: 'WaitNode',
        modelId: 'wait',
        group: 'Flow Nodes',
        nodeType: 'workflowStep',
        defaultKind: WorkflowNodeKindEnum.Process,
        iconColor: '#92400e',
        iconBackground: '#fef3c7',
        order: 70
    },
    renderIcon: renderWaitIcon,
    buildInitialNode: (context) => buildInitialNodeFromSchema(context),
    ui: {
        localCapable: true,
        serverOnly: false
    },
    execute: createNodeModuleWorkerExecute('wait')
};

export default waitNodeModule;
