import type { WorkflowCommandToolSpec } from '@workflow/executor';
import type { WorkerExecuteResult, WorkerPayload, WorkerScope, WorkerUpdateResult, WorkerValidateResult } from '@workflow/executor';
import { toErrorResult, toNode } from '@workflow/executor';

const NODE_SCOPE: WorkerScope = {};
const MAX_WAIT_MS = 300_000;

const toRecordValue = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});

const parseUnit = (value: unknown): 'milliseconds' | 'seconds' | 'minutes' => {
    const normalized = String(value ?? 'seconds')
        .trim()
        .toLowerCase();
    if (normalized === 'milliseconds' || normalized === 'millisecond' || normalized === 'ms') return 'milliseconds';
    if (normalized === 'minutes' || normalized === 'minute' || normalized === 'min') return 'minutes';
    return 'seconds';
};

const resolveWaitMs = (time: number, unit: 'milliseconds' | 'seconds' | 'minutes'): number => {
    if (!Number.isFinite(time) || time < 0) return 0;
    if (unit === 'milliseconds') return time;
    if (unit === 'minutes') return time * 60_000;
    return time * 1_000;
};

const waitForDuration = async (durationMs: number): Promise<void> =>
    new Promise<void>((resolve) => {
        if (!Number.isFinite(durationMs) || durationMs <= 0) {
            resolve();
            return;
        }
        globalThis.setTimeout(() => resolve(), durationMs);
    });

const validateFailureMitigation = (runtime: Record<string, unknown>): WorkerValidateResult => {
    const errors: string[] = [];
    const warnings: string[] = [];
    const failureMitigation = String(runtime.failureMitigation ?? 'stop-workflow').trim();
    if (failureMitigation !== 'retry-node' && failureMitigation !== 'stop-workflow') {
        errors.push('Failure Mitigation must be either "retry-node" or "stop-workflow".');
    }
    if (failureMitigation === 'retry-node') {
        const retryCount = Number(runtime.retryCount);
        if (!Number.isFinite(retryCount) || retryCount < 1 || retryCount > 6) {
            errors.push('Retry Count must be between 1 and 6 when Failure Mitigation is "retry-node".');
        }
    }

    const rawTime = runtime.time;
    const timeAsNumber = Number(String(rawTime ?? '').trim());
    const hasVariableToken = typeof rawTime === 'string' && /\{\{\s*[^}]+\s*\}\}/.test(rawTime);
    if (!hasVariableToken) {
        if (!Number.isFinite(timeAsNumber)) {
            errors.push('Time must be a valid number or a resolved variable token.');
        } else if (timeAsNumber < 0) {
            errors.push('Time must be greater than or equal to 0.');
        }
    }

    const unit = parseUnit(runtime.unit);
    if (Number.isFinite(timeAsNumber) && timeAsNumber >= 0) {
        const waitMs = resolveWaitMs(timeAsNumber, unit);
        if (waitMs > MAX_WAIT_MS) {
            warnings.push('Configured wait exceeds 300 seconds and will be clamped to 300 seconds at runtime.');
        }
    }

    return {
        ok: errors.length === 0,
        errors,
        warnings,
        normalizedRuntime: {
            ...runtime,
            unit
        }
    };
};

export const validate = async (payload: WorkerPayload): Promise<WorkerValidateResult> => validateFailureMitigation(toRecordValue(toNode(payload).runtime));

export const init = async (payload: WorkerPayload): Promise<boolean> => {
    NODE_SCOPE.workflowId = String(payload.workflow?.metadata?.id ?? '');
    NODE_SCOPE.initialized = true;
    return true;
};

export const onUpdate = async (payload: WorkerPayload): Promise<WorkerUpdateResult> => {
    NODE_SCOPE.lastStatus = payload.self?.status ?? NODE_SCOPE.lastStatus;
    NODE_SCOPE.lastOutput = payload.self?.OUTPUT ?? NODE_SCOPE.lastOutput;
    return { ok: true, error: null };
};

const buildWaitOutput = (runtime: Record<string, unknown>, appliedMs: number, requestedMs: number, requestedTime: number, unit: 'milliseconds' | 'seconds' | 'minutes', elapsedMs: number) => {
    const inputPayload = toRecordValue(runtime.value);
    return {
        ...(Object.keys(inputPayload).length ? inputPayload : {}),
        wait: {
            requested: {
                time: requestedTime,
                unit,
                milliseconds: requestedMs
            },
            applied: {
                milliseconds: appliedMs,
                clamped: requestedMs > MAX_WAIT_MS,
                elapsedMilliseconds: elapsedMs
            }
        },
        __activeOutputs: ['output']
    };
};

export const executeLocal = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => {
    try {
        const node = toNode(payload);
        const runtime = toRecordValue(node.runtime);
        const unit = parseUnit(runtime.unit);
        const requestedTime = Number(runtime.time ?? 0);
        const requestedMs = resolveWaitMs(requestedTime, unit);
        const appliedMs = Math.max(0, Math.min(MAX_WAIT_MS, Math.trunc(requestedMs)));

        return {
            output: buildWaitOutput(runtime, appliedMs, requestedMs, requestedTime, unit, 0),
            status: 'passed',
            logs: [`Wait node resolved ${appliedMs}ms locally without pausing the browser runtime.`]
        };
    } catch (error) {
        return toErrorResult(error instanceof Error ? error.message : 'Wait node execution failed.');
    }
};

export const execute = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => {
    if (payload.ENVIRONMENT !== 'node') {
        return executeLocal(payload);
    }

    try {
        const node = toNode(payload);
        const runtime = toRecordValue(node.runtime);
        const unit = parseUnit(runtime.unit);
        const requestedTime = Number(runtime.time ?? 0);
        const requestedMs = resolveWaitMs(requestedTime, unit);
        const appliedMs = Math.max(0, Math.min(MAX_WAIT_MS, Math.trunc(requestedMs)));
        const start = Date.now();

        await waitForDuration(appliedMs);

        const elapsedMs = Date.now() - start;

        return {
            output: buildWaitOutput(runtime, appliedMs, requestedMs, requestedTime, unit, elapsedMs),
            status: 'passed',
            logs: [`Wait node paused for ${appliedMs}ms (${unit}).`]
        };
    } catch (error) {
        return toErrorResult(error instanceof Error ? error.message : 'Wait node execution failed.');
    }
};

// AI Agent command contract: keep this node usable as a declared tool without adding proxy wrappers.
type __GigaCommandRecord = Record<string, unknown>;
const __gigaCommandRecord = (value: unknown): __GigaCommandRecord =>
  value && typeof value === 'object' && !Array.isArray(value) ? (value as __GigaCommandRecord) : {};
const __gigaCommandText = (value: unknown): string => String(value ?? '').trim();
const __gigaCommandNode = (payload: WorkerPayload): __GigaCommandRecord =>
  __gigaCommandRecord((payload as { NODE?: unknown }).NODE || (payload as { self?: unknown }).self || payload);
const __gigaCommandRuntime = (payload: WorkerPayload): __GigaCommandRecord => {
  const node = __gigaCommandNode(payload);
  return { ...__gigaCommandRecord(node.runtime), ...__gigaCommandRecord(node.properties) };
};

export const commandToolSpec = async (payload: WorkerPayload): Promise<WorkflowCommandToolSpec> => {
  const node = __gigaCommandNode(payload);
  const runtime = __gigaCommandRuntime(payload);
  const modelId = __gigaCommandText(node.modelId || runtime.modelId || 'wait');
  const configuredName = __gigaCommandText(node.name || runtime.name || runtime.title);
  const operation = __gigaCommandText(runtime.operation || runtime.action || runtime.mode || modelId || 'wait');
  const haystack = `${configuredName} ${operation} ${modelId}`.toLowerCase();
  const mutating = runtime.mutating === true || /\b(create|update|delete|remove|link|unlink|attach|detach|publish|execute|run|write|save|train|install|ingest|fix|stop|wait)\b/.test(haystack);
  return {
    toolName: configuredName || 'Wait',
    toolDescription: __gigaCommandText(runtime.description || runtime.toolDescription) || 'Pause workflow execution or schedule a continuation according to node config.',
    inputContract: {
      required: [],
      optional: [

        { key: 'message', label: 'Message', description: 'Natural-language instruction or task for this node.' },
        { key: 'input', label: 'Input', description: 'Structured JSON input for the node.' },
        { key: 'operation', label: 'Operation', description: 'Operation/action name, when the node supports multiple operations.' },
        { key: 'prompt', label: 'Prompt', description: 'Prompt text for LLM or transformation nodes.' },
        { key: 'data', label: 'Data', description: 'Data payload for processing.' },
      ],
    },
    outputContract: [
      { key: 'output', label: 'Output', description: 'Node output payload.' },
      { key: 'status', label: 'Status', description: 'Execution status.' },
      { key: 'logs', label: 'Logs', description: 'Execution logs, when available.' },
    ],
    metadata: {
      modelId,
      nodeId: __gigaCommandText(node.id || node.nodeId),
      operation,
      toolDomain: 'control',
      mutating,
      reusableByAiAgent: true,
    },
    executionKind: 'tool',
  };
};

