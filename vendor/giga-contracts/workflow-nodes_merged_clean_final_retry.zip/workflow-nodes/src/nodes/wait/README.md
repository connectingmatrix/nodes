# Wait Node

## Runtime Ownership
Worker-first local node. No backend service is used.

## Usage
Delay downstream workflow execution for the configured time and unit directly in the worker runtime.

## Inputs
- `time`: Duration to wait.
- `unit`: Seconds, minutes, or hours depending on the schema configuration.

## Outputs
- `output`: Timing metadata and pass-through execution details after the delay completes.

## Backend Mapping
- No backend service is used.

## Failure Cases
- Fails when the configured duration is invalid.
