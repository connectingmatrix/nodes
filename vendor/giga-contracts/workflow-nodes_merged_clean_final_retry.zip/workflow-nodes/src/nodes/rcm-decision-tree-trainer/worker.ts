import { createBackendToolWorker } from '@workflow/nodes/nodes/server-only/backend-tool-worker';

const worker = createBackendToolWorker({
    functionName: 'executeRcmDecisionTreeTrainerNode',
    description: 'Trains compact RCM decision-tree rules.',
    toolName: 'RCM Decision Tree Trainer'
});

export const validate = worker.validate;
export const init = worker.init;
export const onUpdate = worker.onUpdate;
export const commandToolSpec = worker.commandToolSpec;
export const execute = worker.execute;
