import { createBackendToolNodeModule } from '@workflow/nodes/nodes/server-only/backend-tool-node.module';

export default createBackendToolNodeModule({
    id: 'rcm-decision-tree-trainer',
    label: 'RCM Decision Tree Trainer',
    description: 'Trains a compact PHI-safe decision-tree rule artifact from streamed RCM rows.',
    group: 'RCM Pipeline',
    order: 212,
    fields: {
        sourceFile: { type: 'string', editable: true, label: 'Source File', allowVariables: true },
        target: { type: 'string', editable: true, defaultValue: 'z_zero_pay', label: 'Target', allowVariables: true },
        maxDepth: { type: 'number', editable: true, defaultValue: 4, label: 'Max Depth' }
    }
});
