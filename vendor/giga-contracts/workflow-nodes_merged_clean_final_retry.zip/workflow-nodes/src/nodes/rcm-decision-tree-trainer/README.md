# RCM Decision Tree Trainer

Worker-owned backend tool node that trains compact decision-tree rules for RCM scoring.

- Uses `executeBackend` function `executeRcmDecisionTreeTrainerNode`.
- Configure `sourceFile` with the profiled or feature-built dataset reference.
- Configure `target` with the prediction column and `maxDepth` with the tree limit.
- Emits JSON model metadata and rule artifacts for scoring or publishing.

