# Workflow File Download

Worker-owned backend tool node that streams a URL or approved local file into workflow storage.

- Uses `executeBackend` function `executeWorkflowFileDownloadNode`.
- Configure required `url` through an inspector field or workflow variable.
- Configure `fileName`, destination fields, checksum, and `allowLocalFile` explicitly.
- Emits JSON file references for inspect, profile, feature, or artifact nodes.

