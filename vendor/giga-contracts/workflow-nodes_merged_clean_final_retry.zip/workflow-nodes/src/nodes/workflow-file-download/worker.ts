import { createBackendToolWorker } from '@workflow/nodes/nodes/server-only/backend-tool-worker';

const worker = createBackendToolWorker({
    functionName: 'executeWorkflowFileDownloadNode',
    description: 'Streams a file into a workflow-scoped VM folder.',
    required: ['url'],
    toolName: 'Workflow File Download'
});

export const validate = worker.validate;
export const init = worker.init;
export const onUpdate = worker.onUpdate;
export const commandToolSpec = worker.commandToolSpec;
export const execute = worker.execute;
