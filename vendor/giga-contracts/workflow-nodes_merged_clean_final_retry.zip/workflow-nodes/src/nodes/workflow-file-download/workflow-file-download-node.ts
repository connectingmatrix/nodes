import { createBackendToolNodeModule } from '@workflow/nodes/nodes/server-only/backend-tool-node.module';

export default createBackendToolNodeModule({
    id: 'workflow-file-download',
    label: 'Workflow File Download',
    description: 'Streams a URL or allowed local file into a workflow-scoped VM folder.',
    group: 'Workflow Files',
    order: 116,
    fields: {
        url: { type: 'string', editable: true, required: true, label: 'URL', allowVariables: true },
        destination: { type: 'select', editable: true, defaultValue: 'run_temp', label: 'Destination', options: ['run_temp', 'drive'] },
        fileName: { type: 'string', editable: true, label: 'File Name', allowVariables: true },
        drivePath: { type: 'string', editable: true, label: 'Drive Path', allowVariables: true },
        checksum: { type: 'string', editable: true, label: 'Checksum', allowVariables: true },
        allowLocalFile: { type: 'boolean', editable: true, defaultValue: false, label: 'Allow Local File' }
    }
});
