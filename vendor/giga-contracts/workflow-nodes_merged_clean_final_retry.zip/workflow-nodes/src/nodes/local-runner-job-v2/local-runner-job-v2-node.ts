export const local_runner_job_V2Node = {
  id: 'local-runner-job-v2',
  type: 'local-runner-job-v2',
  name: 'Local Runner Job V2',
  version: '20.0.0',
  tool: 'agent.local_runner.job.v2',
};
export default local_runner_job_V2Node;
