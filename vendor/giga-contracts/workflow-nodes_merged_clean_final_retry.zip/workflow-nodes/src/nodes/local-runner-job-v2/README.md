# Local Runner Job V2

Routes to `agent.local_runner.job.v2` through `executeBackend`. The node never opens Supabase, Neo4j, local files, or network resources directly.
