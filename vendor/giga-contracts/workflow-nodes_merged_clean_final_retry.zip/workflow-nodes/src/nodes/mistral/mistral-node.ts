import rawSchema from '@workflow/nodes/nodes/mistral/mistral-schema.json';
import { createServerOnlyNodeModule } from '@workflow/nodes/nodes/server-only/server-node.module.factory';

const renderIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <path d="M12 34V14h6l6 8l6-8h6v20" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;

const nodeModule = createServerOnlyNodeModule({
    id: 'mistral',
    rawSchema,
    library: {
        id: 'mistral-node',
        label: 'Mistral',
        description: 'Execute Mistral model on server.',
        gigaId: 'MistralNode',
        modelId: 'mistral',
        group: 'AI Models',
        order: 130,
        iconColor: '#7c2d12',
        iconBackground: '#ffedd5'
    },
    iconSvg: renderIcon
});

export default nodeModule;
