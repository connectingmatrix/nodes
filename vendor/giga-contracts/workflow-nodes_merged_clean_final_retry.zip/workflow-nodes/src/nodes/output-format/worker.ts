import type { WorkflowCommandToolSpec } from '@workflow/executor';
import type { WorkerControlNodeFacade, WorkerExecuteResult, WorkerPayload, WorkerScope, WorkerUpdateResult, WorkerValidateResult } from '@workflow/executor';
import { toErrorResult, toNode } from '@workflow/executor';

const NODE_SCOPE: WorkerScope = {};
const JSON_FORMAT = 'json';
const MARKDOWN_FORMAT = 'markdown';
const RAW_FORMAT = 'raw';
const TABLE_FORMAT = 'table';
const VALID_FORMATS = new Set<string>([JSON_FORMAT, MARKDOWN_FORMAT, RAW_FORMAT, TABLE_FORMAT]);
type ModelPeer = { facade: WorkerControlNodeFacade; key: string; nodeId: string };

const toRecordValue = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});

const toStringValue = (value: unknown): string => String(value ?? '').trim();

const resolveFormat = (value: unknown): string => {
    const normalized = toStringValue(value || JSON_FORMAT).toLowerCase();
    return VALID_FORMATS.has(normalized) ? normalized : JSON_FORMAT;
};

const normalizeWorkerStatus = (value: unknown): WorkerExecuteResult['status'] => {
    const normalized = toStringValue(value).toLowerCase();
    if (normalized === 'failed') return 'failed';
    if (normalized === 'warning') return 'warning';
    if (normalized === 'running') return 'running';
    if (normalized === 'stopped') return 'stopped';
    return 'passed';
};

const stringifyRaw = (value: unknown): string => {
    if (typeof value === 'string') return value;
    if (typeof value === 'number' || typeof value === 'boolean') return String(value);
    if (value === null) return 'null';
    if (typeof value === 'undefined') return '';
    try {
        return JSON.stringify(value, null, 2);
    } catch {
        return String(value);
    }
};

const toMarkdown = (value: unknown): string => {
    if (typeof value === 'string') return value;
    if (Array.isArray(value)) {
        return value.map((entry) => `- ${stringifyRaw(entry)}`).join('\n');
    }
    if (value && typeof value === 'object') {
        return Object.entries(value as Record<string, unknown>)
            .map(([key, entry]) => `- **${key}:** ${stringifyRaw(entry)}`)
            .join('\n');
    }
    return stringifyRaw(value);
};

const toTableOutput = (value: unknown): { columns: string[]; rows: Record<string, unknown>[] } => {
    if (Array.isArray(value)) {
        const rows = value.map((entry) => (entry && typeof entry === 'object' && !Array.isArray(entry) ? (entry as Record<string, unknown>) : { value: entry })).filter((entry) => Object.keys(entry).length > 0);
        const columns = Array.from(new Set(rows.flatMap((row) => Object.keys(row))));
        return { columns, rows };
    }
    if (value && typeof value === 'object' && !Array.isArray(value)) {
        return {
            columns: ['key', 'value'],
            rows: Object.entries(value as Record<string, unknown>).map(([key, entry]) => ({
                key,
                value: entry
            }))
        };
    }
    return {
        columns: ['value'],
        rows: [{ value }]
    };
};

const formatOutputValue = (value: unknown, format: string): unknown => {
    if (format === MARKDOWN_FORMAT) return toMarkdown(value);
    if (format === RAW_FORMAT) return stringifyRaw(value);
    if (format === TABLE_FORMAT) return toTableOutput(value);
    return value;
};

const hasExplicitValue = (value: unknown): boolean => {
    if (typeof value === 'undefined' || value === null) return false;
    if (typeof value === 'string') return value.trim().length > 0;
    if (Array.isArray(value)) return value.length > 0;
    if (value && typeof value === 'object') return Object.keys(value as Record<string, unknown>).length > 0;
    return true;
};

const parseAiBoolean = (value: unknown): boolean => value === true || toStringValue(value).toLowerCase() === 'true';

const validateRuntime = (runtime: Record<string, unknown>): WorkerValidateResult => {
    const errors: string[] = [];
    const warnings: string[] = [];
    const failureMitigation = toStringValue(runtime.failureMitigation || 'stop-workflow');
    if (failureMitigation !== 'retry-node' && failureMitigation !== 'stop-workflow') {
        errors.push('Failure Mitigation must be either "retry-node" or "stop-workflow".');
    }
    if (failureMitigation === 'retry-node') {
        const retryCount = Number(runtime.retryCount);
        if (!Number.isFinite(retryCount) || retryCount < 1 || retryCount > 6) {
            errors.push('Retry Count must be between 1 and 6 when Failure Mitigation is "retry-node".');
        }
    }

    const format = resolveFormat(runtime.format ?? runtime.outputFormat);

    return {
        ok: errors.length === 0,
        errors,
        warnings,
        normalizedRuntime: {
            ...runtime,
            format
        }
    };
};

const extractAssistantText = (payload: unknown): string => {
    if (typeof payload === 'string') return payload;
    const record = toRecordValue(payload);
    if (typeof record.text === 'string' && record.text.trim()) return record.text;
    const answer = toRecordValue(record.answer);
    if (typeof answer.text === 'string' && answer.text.trim()) return answer.text;
    const messages = toRecordValue(record.messages);
    const assistant = toRecordValue(messages.assistant);
    if (typeof assistant.content === 'string' && assistant.content.trim()) return assistant.content;
    const content = toRecordValue(record.content);
    if (typeof content.text === 'string' && content.text.trim()) return content.text;
    return '';
};

const normalizeAiOutput = (format: string, providerOutput: unknown): unknown => {
    const assistantText = extractAssistantText(providerOutput);
    if (!assistantText) return providerOutput;
    if (format === JSON_FORMAT || format === TABLE_FORMAT) {
        try {
            return JSON.parse(assistantText);
        } catch {
            return assistantText;
        }
    }
    return assistantText;
};

const buildAiPrompt = (runtime: Record<string, unknown>, format: string, originalOutput: unknown, deterministicOutput: unknown): string => {
    const basePrompt = toStringValue(runtime.aiPrompt) || 'Reformat and expand the provided value into the target format while preserving intent and key facts.';
    return [basePrompt, '', 'Target format:', format, '', 'Original output:', stringifyRaw(originalOutput), '', 'Deterministic preformatted output:', stringifyRaw(deterministicOutput)].join('\n');
};

const getControlModelPeers = async (payload: WorkerPayload): Promise<ModelPeer[]> => {
    const controlNodes = toRecordValue((payload.NODE as unknown as { CONTROL_NODES?: unknown }).CONTROL_NODES);
    const llmGroup = toRecordValue(controlNodes.llm);
    const peers: ModelPeer[] = [];
    for (const [key, value] of Object.entries(llmGroup)) {
        const facade = value as WorkerControlNodeFacade;
        if (typeof facade?.get !== 'function' || typeof facade?.execute !== 'function') continue;
        const snapshot = await facade.get();
        peers.push({ facade, key, nodeId: snapshot.nodeId });
    }
    return peers;
};

const resolveAiModelPeer = async (payload: WorkerPayload, runtime: Record<string, unknown>): Promise<ModelPeer | null> => {
    const selectedModelId = toStringValue(runtime.modelId);
    const peers = await getControlModelPeers(payload);
    if (selectedModelId) {
        for (const peer of peers) {
            if (peer.nodeId === selectedModelId || peer.key === selectedModelId) return peer;
        }
    }
    return peers.length === 1 ? peers[0] : null;
};

const invokeAiFormatter = async (
    payload: WorkerPayload,
    peer: ModelPeer,
    prompt: string,
    inputValue: unknown,
    deterministicOutput: unknown,
    format: string
): Promise<{ output: unknown; logs: string[]; status: WorkerExecuteResult['status'] }> => {
    const node = toNode(payload);
    const patch = { runtime: { prompt }, properties: { prompt } };
    const prepared = await peer.facade.executeInputs();
    const input = {
        ...prepared.input,
        input: {
            ...toRecordValue(prepared.input?.input),
            [node.id]: {
                originalOutput: inputValue,
                requestedFormat: format,
                deterministicOutput,
                prompt
            }
        }
    };
    const validation = await peer.facade.validate({ input, patch });
    if (!validation.ok) {
        return {
            output: { error: validation.errors[0] || 'Connected LLM validation failed.' },
            logs: validation.errors,
            status: 'failed'
        };
    }
    const invoked = await peer.facade.execute({ input, patch });

    const invokedRecord = toRecordValue(invoked);
    const result = toRecordValue(invokedRecord.result);
    const logs = Array.isArray(result.logs) ? result.logs.map((entry) => toStringValue(entry)).filter(Boolean) : [];
    const status = normalizeWorkerStatus(result.status || toRecordValue(invokedRecord.node).status || 'passed');
    return {
        output: normalizeAiOutput(format, result.output),
        logs,
        status
    };
};

export const validate = async (payload: WorkerPayload): Promise<WorkerValidateResult> => validateRuntime(toRecordValue(toNode(payload).runtime));

export const init = async (payload: WorkerPayload): Promise<boolean> => {
    NODE_SCOPE.workflowId = String(payload.workflow?.metadata?.id ?? '');
    NODE_SCOPE.initialized = true;
    return true;
};

export const onUpdate = async (payload: WorkerPayload): Promise<WorkerUpdateResult> => {
    NODE_SCOPE.lastStatus = payload.self?.status ?? NODE_SCOPE.lastStatus;
    NODE_SCOPE.lastOutput = payload.self?.OUTPUT ?? NODE_SCOPE.lastOutput;
    return { ok: true, error: null };
};

export const executeLocal = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => {
    try {
        const node = toNode(payload);
        const runtime = toRecordValue(node.runtime);
        const format = resolveFormat(runtime.format ?? runtime.outputFormat);
        const inputValue = runtime.value;
        const useAiFormatting = parseAiBoolean(runtime.useAiFormatting);
        const deterministicOutput = formatOutputValue(inputValue, format);

        if (!useAiFormatting) {
            return {
                output: deterministicOutput,
                status: 'passed',
                logs: [`Output formatted as ${format}.`]
            };
        }

        const modelPeer = await resolveAiModelPeer(payload, runtime);
        if (!modelPeer) {
            return {
                output: deterministicOutput,
                status: 'failed',
                logs: ['AI formatting requires exactly one connected LLM control node or a selected connected model.']
            };
        }

        const prompt = buildAiPrompt(runtime, format, inputValue, deterministicOutput);
        const aiResult = await invokeAiFormatter(payload, modelPeer, prompt, inputValue, deterministicOutput, format);
        if (aiResult.status === 'failed') {
            return {
                output: aiResult.output,
                status: 'failed',
                logs: aiResult.logs
            };
        }

        return {
            output: aiResult.output,
            status: aiResult.status,
            logs: [`AI formatting executed through connected model ${modelPeer.nodeId}.`, ...aiResult.logs]
        };
    } catch (error) {
        return toErrorResult(error instanceof Error ? error.message : 'Output Format node execution failed.');
    }
};

export const execute = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => executeLocal(payload);

// AI Agent command contract: keep this node usable as a declared tool without adding proxy wrappers.
type __GigaCommandRecord = Record<string, unknown>;
const __gigaCommandRecord = (value: unknown): __GigaCommandRecord =>
  value && typeof value === 'object' && !Array.isArray(value) ? (value as __GigaCommandRecord) : {};
const __gigaCommandText = (value: unknown): string => String(value ?? '').trim();
const __gigaCommandNode = (payload: WorkerPayload): __GigaCommandRecord =>
  __gigaCommandRecord((payload as { NODE?: unknown }).NODE || (payload as { self?: unknown }).self || payload);
const __gigaCommandRuntime = (payload: WorkerPayload): __GigaCommandRecord => {
  const node = __gigaCommandNode(payload);
  return { ...__gigaCommandRecord(node.runtime), ...__gigaCommandRecord(node.properties) };
};

export const commandToolSpec = async (payload: WorkerPayload): Promise<WorkflowCommandToolSpec> => {
  const node = __gigaCommandNode(payload);
  const runtime = __gigaCommandRuntime(payload);
  const modelId = __gigaCommandText(node.modelId || runtime.modelId || 'output-format');
  const configuredName = __gigaCommandText(node.name || runtime.name || runtime.title);
  const operation = __gigaCommandText(runtime.operation || runtime.action || runtime.mode || modelId || 'output-format');
  const haystack = `${configuredName} ${operation} ${modelId}`.toLowerCase();
  const mutating = runtime.mutating === true || /\b(create|update|delete|remove|link|unlink|attach|detach|publish|execute|run|write|save|train|install|ingest|fix|stop|wait)\b/.test(haystack);
  return {
    toolName: configuredName || 'Output Format',
    toolDescription: __gigaCommandText(runtime.description || runtime.toolDescription) || 'Format workflow output as JSON, markdown, table, raw text, or response-ready content.',
    inputContract: {
      required: [],
      optional: [

        { key: 'message', label: 'Message', description: 'Natural-language instruction or task for this node.' },
        { key: 'input', label: 'Input', description: 'Structured JSON input for the node.' },
        { key: 'operation', label: 'Operation', description: 'Operation/action name, when the node supports multiple operations.' },
        { key: 'prompt', label: 'Prompt', description: 'Prompt text for LLM or transformation nodes.' },
        { key: 'data', label: 'Data', description: 'Data payload for processing.' },
      ],
    },
    outputContract: [
      { key: 'output', label: 'Output', description: 'Node output payload.' },
      { key: 'status', label: 'Status', description: 'Execution status.' },
      { key: 'logs', label: 'Logs', description: 'Execution logs, when available.' },
    ],
    metadata: {
      modelId,
      nodeId: __gigaCommandText(node.id || node.nodeId),
      operation,
      toolDomain: 'output',
      mutating,
      reusableByAiAgent: true,
    },
    executionKind: 'tool',
  };
};

