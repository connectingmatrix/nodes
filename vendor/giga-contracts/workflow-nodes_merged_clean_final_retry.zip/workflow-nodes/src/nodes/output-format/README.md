# Output Format Node

## Runtime Ownership
Worker-first local node. No backend service is used.

## Usage
Format inbound data as JSON, Markdown, raw text, or table output. When `Use AI Formatting` is enabled, the worker still computes the requested format, then sends the original value, requested format, deterministic pre-format, and `aiPrompt` to the selected connected LLM node for expansion.

## Inputs
- `input`: Source payload to format.
- `llm`: Optional connected LLM command port used for model selection in the inspector.
- `format`: Target format (`json`, `markdown`, `raw`, or `table`).
- `value`: Optional override value; falls back to inbound `input` when omitted.
- `useAiFormatting`: Enables AI prompt/model context.
- `modelId`: Selected connected LLM node id.
- `aiPrompt`: Rich Markdown prompt template sent to the connected LLM together with the original value and requested format.

## Outputs
- `output`: Deterministic formatted payload when AI is off, or the AI-processed formatted payload when AI is on.

## Backend Mapping
- No backend service is used.

## Failure Cases
- Validation fails when `format` is outside the supported set.
