import rawSchema from '@workflow/nodes/nodes/output-format/output-format-schema.json';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';
import { parseBooleanValue, parseRecordValue, parseStringValue } from '@workflow/nodes/node-utils/node-runtime.utils';
import { WorkflowNodeFieldMap, WorkflowNodeFieldTypeEnum, WorkflowNodeKindEnum } from '@workflow/nodes/types';

const schema = parseNodeSchema(rawSchema, 'output-format');
const JSON_FORMAT = 'json';
const MARKDOWN_FORMAT = 'markdown';
const RAW_FORMAT = 'raw';
const TABLE_FORMAT = 'table';
const OUTPUT_FORMATS = new Set([JSON_FORMAT, MARKDOWN_FORMAT, RAW_FORMAT, TABLE_FORMAT]);

const renderIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <rect x="9" y="8" width="30" height="20" rx="4" stroke="currentColor" stroke-width="2.4"/>
  <path d="M15 32h18M20 38h8" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>
</svg>`;

const resolveFormat = (value: unknown): string => {
    const normalized = parseStringValue(value || JSON_FORMAT)
        .trim()
        .toLowerCase();
    return OUTPUT_FORMATS.has(normalized) ? normalized : JSON_FORMAT;
};

const getConnectedModelOptions = (workflow: Parameters<NonNullable<WorkflowNodeModule['resolveInspectorFields']>>[0]['workflow'], nodeId: string): Array<{ label: string; value: string }> => {
    const nodeById = new Map(workflow.nodes.map((node) => [node.id, node]));
    return workflow.connections
        .filter((connection) => connection.to === nodeId && connection.targetHandle === 'cmd:llm')
        .map((connection) => nodeById.get(connection.from))
        .filter((node): node is NonNullable<typeof node> => Boolean(node))
        .reduce<Array<{ label: string; value: string }>>((acc, node) => {
            if (acc.some((entry) => entry.value === node.id)) return acc;
            acc.push({
                label: `${node.name} (${node.modelId})`,
                value: node.id
            });
            return acc;
        }, []);
};

const resolveValueFieldType = (format: string): WorkflowNodeFieldTypeEnum => {
    if (format === MARKDOWN_FORMAT) return WorkflowNodeFieldTypeEnum.Markdown;
    if (format === RAW_FORMAT) return WorkflowNodeFieldTypeEnum.Textarea;
    return WorkflowNodeFieldTypeEnum.Json;
};

const outputFormatNodeModule: WorkflowNodeModule = {
    id: 'output-format',
    schema,
    library: {
        id: 'output-format-node',
        label: 'Output Format',
        description: 'Format outputs as JSON, Markdown, Raw, or Table with optional AI refinement.',
        gigaId: 'OutputFormatNode',
        modelId: 'output-format',
        group: 'Output Nodes',
        nodeType: 'workflowStep',
        defaultKind: WorkflowNodeKindEnum.Process,
        iconColor: '#7c2d12',
        iconBackground: '#ffedd5',
        order: 123
    },
    renderIcon,
    buildInitialNode: (context) => buildInitialNodeFromSchema(context),
    ui: {
        localCapable: true,
        serverOnly: false
    },
    resolveInspectorFields: ({ workflow, node, fields }) => {
        const nextFields: WorkflowNodeFieldMap = { ...fields };
        const format = resolveFormat(node.runtime?.format ?? fields.format?.defaultValue);
        const connectedModels = getConnectedModelOptions(workflow, node.id);
        const useAiFormatting = parseBooleanValue(node.runtime?.useAiFormatting ?? false);

        if (nextFields.value) {
            nextFields.value = {
                ...nextFields.value,
                type: resolveValueFieldType(format),
                label: format === TABLE_FORMAT ? 'Rows / Data' : 'Value',
                styles: {
                    ...(nextFields.value.styles ?? {}),
                    layoutPreset: 'full'
                }
            };
        }

        if (nextFields.modelId) {
            nextFields.modelId = {
                ...nextFields.modelId,
                hidden: connectedModels.length === 0,
                options: connectedModels
            };
        }

        if (nextFields.aiPrompt) {
            nextFields.aiPrompt = {
                ...nextFields.aiPrompt,
                hidden: !useAiFormatting
            };
        }

        return nextFields;
    },
    execute: createNodeModuleWorkerExecute('output-format')
};

export default outputFormatNodeModule;
