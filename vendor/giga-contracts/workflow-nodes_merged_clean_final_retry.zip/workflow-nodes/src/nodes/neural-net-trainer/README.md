# Neural Net Trainer

Create/train/evaluate neural-net trainer nodes under sandbox rules.

This node is command-capable and routes backend operations through `executeBackend`. It does not access Supabase or Neo4j directly.
