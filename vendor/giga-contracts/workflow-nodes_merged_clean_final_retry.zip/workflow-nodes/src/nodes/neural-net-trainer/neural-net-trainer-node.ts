import rawSchema from './neural-net-trainer-schema.json';
import { createAgentBackendNodeModule } from '@workflow/nodes/nodes/_agent-backend-node-module';

export default createAgentBackendNodeModule({ id: 'neural-net-trainer', rawSchema, label: 'Neural Net Trainer', description: 'Create/train/evaluate neural-net trainer nodes under sandbox rules.', kind: 'database', order: 520 });
