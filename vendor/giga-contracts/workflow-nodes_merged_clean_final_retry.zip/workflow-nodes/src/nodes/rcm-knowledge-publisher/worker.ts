import { createBackendToolWorker } from '@workflow/nodes/nodes/server-only/backend-tool-worker';

const worker = createBackendToolWorker({
    functionName: 'executeRcmKnowledgePublisherNode',
    description: 'Publishes the full RCM copilot knowledge and workflow package.',
    required: ['organizationId'],
    toolName: 'RCM Knowledge Publisher'
});

export const validate = worker.validate;
export const init = worker.init;
export const onUpdate = worker.onUpdate;
export const commandToolSpec = worker.commandToolSpec;
export const execute = worker.execute;
