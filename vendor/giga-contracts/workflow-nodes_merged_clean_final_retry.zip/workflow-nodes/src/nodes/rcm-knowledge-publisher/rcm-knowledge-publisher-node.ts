import { createBackendToolNodeModule } from '@workflow/nodes/nodes/server-only/backend-tool-node.module';

export default createBackendToolNodeModule({
    id: 'rcm-knowledge-publisher',
    label: 'RCM Knowledge Publisher',
    description: 'Creates or updates the RCM channel, posts, artifacts, copilot workflow, and assignment.',
    group: 'RCM Pipeline',
    order: 215,
    fields: {
        organizationId: { type: 'string', editable: true, required: true, label: 'Organization ID', allowVariables: true },
        ownerUserId: { type: 'string', editable: true, label: 'Owner User ID', allowVariables: true },
        channelName: { type: 'string', editable: true, defaultValue: 'RCM Medical Billing', label: 'Channel Name', allowVariables: true },
        linkParentChannelId: { type: 'string', editable: true, label: 'Parent Channel ID', allowVariables: true }
    }
});
