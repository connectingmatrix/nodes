# RCM Knowledge Publisher

Worker-owned backend tool node that publishes the RCM copilot knowledge package.

- Uses `executeBackend` function `executeRcmKnowledgePublisherNode`.
- Configure required `organizationId` through an inspector variable.
- Optionally configure `ownerUserId`, `channelName`, and `linkParentChannelId` for the target knowledge tree.
- Emits JSON publish results and created knowledge references.

