import rawSchema from '@workflow/nodes/nodes/if-else/if-else-schema.json';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';
import { WorkflowNodeKindEnum } from '@workflow/nodes/types';

const schema = parseNodeSchema(rawSchema, 'if-else');

const IF_ELSE_DEFAULT_CODE = `const data = input;
const condition = Boolean(data?.input?.flag);

if (condition) {
    return { true: data };
}

return { false: data };`;

const renderIfElseIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <path d="M11 10v8c0 6.8 5.5 12.3 12.3 12.3H37" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>
  <path d="M11 38v-8c0-6.8 5.5-12.3 12.3-12.3H37" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>
  <path d="M31 6l8 4l-8 4M31 34l8 4l-8 4" fill="currentColor"/>
</svg>`;

const ifElseNodeModule: WorkflowNodeModule = {
    id: 'if-else',
    schema,
    library: {
        id: 'if-else-node',
        label: 'If/Else',
        description: 'Route workflow execution to exactly one branch using code.',
        gigaId: 'IfElseNode',
        modelId: 'if-else',
        group: 'Flow Nodes',
        nodeType: 'workflowStep',
        defaultKind: WorkflowNodeKindEnum.Process,
        iconColor: '#4338ca',
        iconBackground: '#eef2ff',
        order: 25
    },
    renderIcon: renderIfElseIcon,
    buildInitialNode: (context) => buildInitialNodeFromSchema(context, { code: IF_ELSE_DEFAULT_CODE }),
    ui: {
        localCapable: true,
        serverOnly: false,
        inspector: {
            instructionOnly: true
        }
    },
    execute: createNodeModuleWorkerExecute('if-else')
};

export default ifElseNodeModule;
