# If Else Node

## Runtime Ownership
Worker-first local node. No backend service is used.

## Usage
Bind one `value`, choose a `leftPath`, select an `operator`, and optionally provide `compareValue`. The node evaluates that condition and activates only the matching output branch.

## Inputs
- `value`: Variable-bound source object.
- `leftPath`: Property path resolved from `value`.
- `operator`: Comparison mode.
- `compareValue`: Optional right-side comparison value.

## Outputs
- `true`: Branch payload when the condition passes.
- `false`: Branch payload when the condition fails.

## Backend Mapping
- No backend service is used.

## Failure Cases
- Fails when `leftPath` is empty.
- Fails when worker execution itself is unavailable.
