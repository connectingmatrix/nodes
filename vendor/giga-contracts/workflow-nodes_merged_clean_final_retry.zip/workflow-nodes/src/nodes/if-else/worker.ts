import type { WorkflowCommandToolSpec } from '@workflow/executor';
import type { WorkerExecuteResult, WorkerPayload, WorkerScope, WorkerUpdateResult, WorkerValidateResult } from '@workflow/executor';
import { toErrorResult, toNode } from '@workflow/executor';

const NODE_SCOPE: WorkerScope = {};

const toRecordValue = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});
const normalizePath = (value: string): string => value.replace(/\[(\d+)\]/g, '.$1').trim();
const resolvePath = (source: unknown, path: string): unknown => {
    if (!path || path === 'input') return source;
    let current: unknown = source;
    for (const segment of normalizePath(path).split('.').filter(Boolean)) {
        if (!current || typeof current !== 'object') return undefined;
        current = (current as Record<string, unknown>)[segment];
    }
    return current;
};
const parseCompareValue = (value: unknown): unknown => {
    if (typeof value !== 'string') return value;
    const normalized = value.trim();
    if (!normalized) return '';
    try {
        return JSON.parse(normalized);
    } catch {
        return normalized;
    }
};
const hasConfiguredValue = (value: unknown): boolean => !(value === undefined || value === null || value === '' || Array.isArray(value) && value.length === 0 || value && typeof value === 'object' && !Array.isArray(value) && Object.keys(value as Record<string, unknown>).length === 0);
const isEmptyValue = (value: unknown): boolean => {
    if (value === null || typeof value === 'undefined') return true;
    if (typeof value === 'string') return value.trim().length === 0;
    if (Array.isArray(value)) return value.length === 0;
    if (value && typeof value === 'object') return Object.keys(value as Record<string, unknown>).length === 0;
    return false;
};
const finiteNumber = (value: unknown): number | null => {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
};
const evaluateCondition = (operator: string, leftValue: unknown, compareValue: unknown): boolean => {
    const leftNumber = finiteNumber(leftValue);
    const rightNumber = finiteNumber(compareValue);
    switch (operator) {
        case 'falsy':
            return !leftValue;
        case 'eq':
            return leftValue === compareValue;
        case 'ne':
            return leftValue !== compareValue;
        case 'gt':
            return leftNumber !== null && rightNumber !== null ? leftNumber > rightNumber : String(leftValue || '') > String(compareValue || '');
        case 'gte':
            return leftNumber !== null && rightNumber !== null ? leftNumber >= rightNumber : String(leftValue || '') >= String(compareValue || '');
        case 'lt':
            return leftNumber !== null && rightNumber !== null ? leftNumber < rightNumber : String(leftValue || '') < String(compareValue || '');
        case 'lte':
            return leftNumber !== null && rightNumber !== null ? leftNumber <= rightNumber : String(leftValue || '') <= String(compareValue || '');
        case 'contains':
            if (Array.isArray(leftValue)) return leftValue.includes(compareValue);
            if (typeof leftValue === 'string') return leftValue.includes(String(compareValue || ''));
            if (leftValue && typeof leftValue === 'object' && typeof compareValue === 'string') return Object.prototype.hasOwnProperty.call(leftValue, compareValue);
            return false;
        case 'is-empty':
            return isEmptyValue(leftValue);
        case 'not-empty':
            return !isEmptyValue(leftValue);
        case 'truthy':
        default:
            return Boolean(leftValue);
    }
};

const validateFailureMitigation = (runtime: Record<string, unknown>): WorkerValidateResult => {
    const errors: string[] = [];
    const failureMitigation = String(runtime.failureMitigation ?? 'stop-workflow').trim();
    if (failureMitigation !== 'retry-node' && failureMitigation !== 'stop-workflow') {
        errors.push('Failure Mitigation must be either "retry-node" or "stop-workflow".');
    }
    if (failureMitigation === 'retry-node') {
        const retryCount = Number(runtime.retryCount);
        if (!Number.isFinite(retryCount) || retryCount < 1 || retryCount > 6) {
            errors.push('Retry Count must be between 1 and 6 when Failure Mitigation is "retry-node".');
        }
    }
    return { ok: errors.length === 0, errors, warnings: [], normalizedRuntime: runtime };
};

export const validate = async (payload: WorkerPayload): Promise<WorkerValidateResult> => {
    const runtime = toRecordValue(toNode(payload).runtime);
    const result = validateFailureMitigation(runtime);
    if (!String(runtime.leftPath ?? '').trim()) {
        return {
            ...result,
            ok: false,
            errors: [...result.errors, 'leftPath is required.']
        };
    }
    if (!hasConfiguredValue(runtime.value)) {
        return {
            ...result,
            ok: false,
            errors: [...result.errors, 'Value is required and must be bound through inspector properties.']
        };
    }
    return result;
};

export const init = async (payload: WorkerPayload): Promise<boolean> => {
    NODE_SCOPE.workflowId = String(payload.workflow?.metadata?.id ?? '');
    NODE_SCOPE.initialized = true;
    return true;
};

export const onUpdate = async (payload: WorkerPayload): Promise<WorkerUpdateResult> => {
    NODE_SCOPE.lastStatus = payload.self?.status ?? NODE_SCOPE.lastStatus;
    NODE_SCOPE.lastOutput = payload.self?.OUTPUT ?? NODE_SCOPE.lastOutput;
    return { ok: true, error: null };
};

export const execute = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => {
    try {
        const runtime = toRecordValue(toNode(payload).runtime);
        const value = runtime.value;
        const sourceRecord = toRecordValue(value);
        const { __activeOutputs: _activeOutputs, __workflow: _workflow, ...flattenedValue } = sourceRecord;
        const compareValue = parseCompareValue(runtime.compareValue);
        const leftPath = String(runtime.leftPath || 'input').trim();
        const operator = String(runtime.operator || 'truthy').trim();
        const leftValue = resolvePath(value, leftPath);
        const passed = evaluateCondition(operator, leftValue, compareValue);
        const selectedBranch = passed ? 'true' : 'false';
        return {
            output: {
                ...flattenedValue,
                input: value,
                leftPath,
                leftValue,
                operator,
                compareValue,
                passed,
                selectedBranch,
                trueBranch: {
                    active: passed,
                    outputPort: 'true',
                    value: passed ? value : null
                },
                falseBranch: {
                    active: !passed,
                    outputPort: 'false',
                    value: passed ? null : value
                },
                __activeOutputs: [selectedBranch]
            },
            status: 'passed',
            logs: []
        };
    } catch (error) {
        return toErrorResult(error instanceof Error ? error.message : 'If/Else node execution failed.');
    }
};

// AI Agent command contract: keep this node usable as a declared tool without adding proxy wrappers.
type __GigaCommandRecord = Record<string, unknown>;
const __gigaCommandRecord = (value: unknown): __GigaCommandRecord =>
  value && typeof value === 'object' && !Array.isArray(value) ? (value as __GigaCommandRecord) : {};
const __gigaCommandText = (value: unknown): string => String(value ?? '').trim();
const __gigaCommandNode = (payload: WorkerPayload): __GigaCommandRecord =>
  __gigaCommandRecord((payload as { NODE?: unknown }).NODE || (payload as { self?: unknown }).self || payload);
const __gigaCommandRuntime = (payload: WorkerPayload): __GigaCommandRecord => {
  const node = __gigaCommandNode(payload);
  return { ...__gigaCommandRecord(node.runtime), ...__gigaCommandRecord(node.properties) };
};

export const commandToolSpec = async (payload: WorkerPayload): Promise<WorkflowCommandToolSpec> => {
  const node = __gigaCommandNode(payload);
  const runtime = __gigaCommandRuntime(payload);
  const modelId = __gigaCommandText(node.modelId || runtime.modelId || 'if-else');
  const configuredName = __gigaCommandText(node.name || runtime.name || runtime.title);
  const operation = __gigaCommandText(runtime.operation || runtime.action || runtime.mode || modelId || 'if-else');
  const haystack = `${configuredName} ${operation} ${modelId}`.toLowerCase();
  const mutating = runtime.mutating === true || /\b(create|update|delete|remove|link|unlink|attach|detach|publish|execute|run|write|save|train|install|ingest|fix|stop|wait)\b/.test(haystack);
  return {
    toolName: configuredName || 'If Else',
    toolDescription: __gigaCommandText(runtime.description || runtime.toolDescription) || 'Evaluate conditions and route workflow execution based on true/false logic.',
    inputContract: {
      required: [],
      optional: [

        { key: 'message', label: 'Message', description: 'Natural-language instruction or task for this node.' },
        { key: 'input', label: 'Input', description: 'Structured JSON input for the node.' },
        { key: 'operation', label: 'Operation', description: 'Operation/action name, when the node supports multiple operations.' },
        { key: 'prompt', label: 'Prompt', description: 'Prompt text for LLM or transformation nodes.' },
        { key: 'data', label: 'Data', description: 'Data payload for processing.' },
      ],
    },
    outputContract: [
      { key: 'output', label: 'Output', description: 'Node output payload.' },
      { key: 'status', label: 'Status', description: 'Execution status.' },
      { key: 'logs', label: 'Logs', description: 'Execution logs, when available.' },
    ],
    metadata: {
      modelId,
      nodeId: __gigaCommandText(node.id || node.nodeId),
      operation,
      toolDomain: 'control',
      mutating,
      reusableByAiAgent: true,
    },
    executionKind: 'tool',
  };
};

