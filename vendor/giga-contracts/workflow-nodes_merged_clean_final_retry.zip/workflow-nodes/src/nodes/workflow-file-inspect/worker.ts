import { createBackendToolWorker } from '@workflow/nodes/nodes/server-only/backend-tool-worker';

const worker = createBackendToolWorker({
    functionName: 'executeWorkflowFileInspectNode',
    description: 'Validates a workflow-scoped file reference.',
    toolName: 'Workflow File Inspect'
});

export const validate = worker.validate;
export const init = worker.init;
export const onUpdate = worker.onUpdate;
export const commandToolSpec = worker.commandToolSpec;
export const execute = worker.execute;
