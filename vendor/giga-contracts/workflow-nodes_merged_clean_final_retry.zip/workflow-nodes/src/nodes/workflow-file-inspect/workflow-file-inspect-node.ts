import { createBackendToolNodeModule } from '@workflow/nodes/nodes/server-only/backend-tool-node.module';

export default createBackendToolNodeModule({
    id: 'workflow-file-inspect',
    label: 'Workflow File Inspect',
    description: 'Validates workflow-scoped file existence, checksum, size, extension, and PHI policy.',
    group: 'Workflow Files',
    order: 117,
    fields: {
        checksum: { type: 'string', editable: true, label: 'Checksum', allowVariables: true },
        maxBytes: { type: 'number', editable: true, label: 'Max Bytes', allowVariables: true },
        phiSafe: { type: 'boolean', editable: true, defaultValue: true, label: 'PHI Safe' }
    }
});
