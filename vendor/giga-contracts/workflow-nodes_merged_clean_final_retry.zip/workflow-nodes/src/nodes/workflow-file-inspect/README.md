# Workflow File Inspect

Worker-owned backend tool node that validates workflow-scoped file references.

- Uses `executeBackend` function `executeWorkflowFileInspectNode`.
- Configure `checksum`, `maxBytes`, and `phiSafe` through inspector fields.
- Use variables from download or artifact nodes for the file reference.
- Emits JSON validation metadata for safe downstream execution.

