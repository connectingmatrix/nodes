import { createBackendToolNodeModule } from '@workflow/nodes/nodes/server-only/backend-tool-node.module';

export default createBackendToolNodeModule({
    id: 'rcm-model-scorer',
    label: 'RCM Model Scorer',
    description: 'Loads a compact RCM model artifact and scores redacted claim scenarios.',
    group: 'RCM Pipeline',
    order: 214,
    fields: {
        modelPath: { type: 'string', editable: true, label: 'Model Path', allowVariables: true },
        bucket: { type: 'string', editable: true, defaultValue: 'storage', label: 'Bucket', allowVariables: true },
        scenario: { type: 'json', editable: true, label: 'Scenario', allowVariables: true }
    }
});
