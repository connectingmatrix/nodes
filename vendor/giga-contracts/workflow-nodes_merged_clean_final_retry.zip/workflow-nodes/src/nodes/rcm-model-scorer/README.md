# RCM Model Scorer

Worker-owned backend tool node that scores redacted RCM scenarios with saved model artifacts.

- Uses `executeBackend` function `executeRcmModelScorerNode`.
- Configure `modelPath` with the trainer output reference.
- Configure `bucket` and `scenario` through inspector fields or variables.
- Emits JSON score results for downstream branching or response nodes.

