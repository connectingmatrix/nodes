# Sentiment Analysis

Analyze sentiment for text/chat/file datasets.

This node is command-capable and routes backend operations through `executeBackend`. It does not access Supabase or Neo4j directly.
