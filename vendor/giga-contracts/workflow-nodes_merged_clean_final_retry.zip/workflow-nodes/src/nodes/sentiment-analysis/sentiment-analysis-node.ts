import rawSchema from './sentiment-analysis-schema.json';
import { createAgentBackendNodeModule } from '@workflow/nodes/nodes/_agent-backend-node-module';

export default createAgentBackendNodeModule({ id: 'sentiment-analysis', rawSchema, label: 'Sentiment Analysis', description: 'Analyze sentiment for text/chat/file datasets.', kind: 'database', order: 523 });
