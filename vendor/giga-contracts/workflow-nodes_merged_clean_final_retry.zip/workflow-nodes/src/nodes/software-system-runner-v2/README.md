# Software System Runner V2

Routes to `agent.software.run.v2` through `executeBackend`. The node never opens Supabase, Neo4j, local files, or network resources directly.
