export const software_system_runner_V2Node = {
  id: 'software-system-runner-v2',
  type: 'software-system-runner-v2',
  name: 'Software System Runner V2',
  version: '20.0.0',
  tool: 'agent.software.run.v2',
};
export default software_system_runner_V2Node;
