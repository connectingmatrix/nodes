import type { WorkflowCommandToolSpec } from '@workflow/executor';
import type { WorkerExecuteResult, WorkerPayload, WorkerScope, WorkerUpdateResult, WorkerValidateResult } from '@workflow/executor';
import { toErrorResult, toNode } from '@workflow/executor';

const NODE_SCOPE: WorkerScope = {};

const toRecordValue = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});

const validateFailureMitigation = (runtime: Record<string, unknown>): WorkerValidateResult => {
    const errors: string[] = [];
    const warnings: string[] = [];
    const failureMitigation = String(runtime.failureMitigation ?? 'stop-workflow').trim();
    if (failureMitigation !== 'retry-node' && failureMitigation !== 'stop-workflow') {
        errors.push('Failure Mitigation must be either "retry-node" or "stop-workflow".');
    }
    if (failureMitigation === 'retry-node') {
        const retryCount = Number(runtime.retryCount);
        if (!Number.isFinite(retryCount) || retryCount < 1 || retryCount > 6) {
            errors.push('Retry Count must be between 1 and 6 when Failure Mitigation is "retry-node".');
        }
    }

    const files = Array.isArray(runtime.files) ? runtime.files : Array.isArray(runtime.file) ? runtime.file : [];
    if (files.length === 0) {
        warnings.push('No files are attached.');
    }

    return {
        ok: errors.length === 0,
        errors,
        warnings,
        normalizedRuntime: runtime
    };
};

export const validate = async (payload: WorkerPayload): Promise<WorkerValidateResult> => validateFailureMitigation(toRecordValue(toNode(payload).runtime));

export const init = async (payload: WorkerPayload): Promise<boolean> => {
    NODE_SCOPE.workflowId = String(payload.workflow?.metadata?.id ?? '');
    NODE_SCOPE.initialized = true;
    return true;
};

export const onUpdate = async (payload: WorkerPayload): Promise<WorkerUpdateResult> => {
    NODE_SCOPE.lastStatus = payload.self?.status ?? NODE_SCOPE.lastStatus;
    NODE_SCOPE.lastOutput = payload.self?.OUTPUT ?? NODE_SCOPE.lastOutput;
    return { ok: true, error: null };
};

export const execute = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => {
    try {
        const runtime = toRecordValue(toNode(payload).runtime);
        const files = Array.isArray(runtime.files) ? runtime.files : Array.isArray(runtime.file) ? runtime.file : [];
        return {
            output: {
                files,
                __activeOutputs: ['output']
            },
            status: 'passed',
            logs: files.length ? ['File node emitted attached files.'] : ['File node has no attached files.']
        };
    } catch (error) {
        return toErrorResult(error instanceof Error ? error.message : 'File node execution failed.');
    }
};

// AI Agent command contract: keep this node usable as a declared tool without adding proxy wrappers.
type __GigaCommandRecord = Record<string, unknown>;
const __gigaCommandRecord = (value: unknown): __GigaCommandRecord =>
  value && typeof value === 'object' && !Array.isArray(value) ? (value as __GigaCommandRecord) : {};
const __gigaCommandText = (value: unknown): string => String(value ?? '').trim();
const __gigaCommandNode = (payload: WorkerPayload): __GigaCommandRecord =>
  __gigaCommandRecord((payload as { NODE?: unknown }).NODE || (payload as { self?: unknown }).self || payload);
const __gigaCommandRuntime = (payload: WorkerPayload): __GigaCommandRecord => {
  const node = __gigaCommandNode(payload);
  return { ...__gigaCommandRecord(node.runtime), ...__gigaCommandRecord(node.properties) };
};

export const commandToolSpec = async (payload: WorkerPayload): Promise<WorkflowCommandToolSpec> => {
  const node = __gigaCommandNode(payload);
  const runtime = __gigaCommandRuntime(payload);
  const modelId = __gigaCommandText(node.modelId || runtime.modelId || 'file');
  const configuredName = __gigaCommandText(node.name || runtime.name || runtime.title);
  const operation = __gigaCommandText(runtime.operation || runtime.action || runtime.mode || modelId || 'file');
  const haystack = `${configuredName} ${operation} ${modelId}`.toLowerCase();
  const mutating = runtime.mutating === true || /\b(create|update|delete|remove|link|unlink|attach|detach|publish|execute|run|write|save|train|install|ingest|fix|stop|wait)\b/.test(haystack);
  return {
    toolName: configuredName || 'File',
    toolDescription: __gigaCommandText(runtime.description || runtime.toolDescription) || 'Read, prepare, inspect, or transform file inputs and file metadata.',
    inputContract: {
      required: [],
      optional: [

        { key: 'message', label: 'Message', description: 'Natural-language instruction or task for this node.' },
        { key: 'input', label: 'Input', description: 'Structured JSON input for the node.' },
        { key: 'operation', label: 'Operation', description: 'Operation/action name, when the node supports multiple operations.' },
        { key: 'prompt', label: 'Prompt', description: 'Prompt text for LLM or transformation nodes.' },
        { key: 'data', label: 'Data', description: 'Data payload for processing.' },
      ],
    },
    outputContract: [
      { key: 'output', label: 'Output', description: 'Node output payload.' },
      { key: 'status', label: 'Status', description: 'Execution status.' },
      { key: 'logs', label: 'Logs', description: 'Execution logs, when available.' },
    ],
    metadata: {
      modelId,
      nodeId: __gigaCommandText(node.id || node.nodeId),
      operation,
      toolDomain: 'file',
      mutating,
      reusableByAiAgent: true,
    },
    executionKind: 'tool',
  };
};

