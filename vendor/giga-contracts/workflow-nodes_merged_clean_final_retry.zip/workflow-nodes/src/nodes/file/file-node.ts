import rawSchema from '@workflow/nodes/nodes/file/file-schema.json';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { WorkflowNodeKindEnum } from '@workflow/nodes/types';
import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';

const schema = parseNodeSchema(rawSchema, 'file');

const renderFileIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <path d="M13 6h16l8 8v28H13z" stroke="currentColor" stroke-width="2.4"/>
  <path d="M29 6v9h8M18 22h14M18 29h14M18 36h10" stroke="currentColor" stroke-width="2"/>
</svg>`;

const fileNodeModule: WorkflowNodeModule = {
    id: 'file',
    schema,
    library: {
        id: 'file-node',
        label: 'File',
        description: 'File ingestion and pass-through node.',
        gigaId: 'FileNode',
        modelId: 'file',
        group: 'Data',
        nodeType: 'workflowStep',
        defaultKind: WorkflowNodeKindEnum.Process,
        iconColor: '#475569',
        iconBackground: '#f1f5f9',
        order: 80
    },
    renderIcon: renderFileIcon,
    buildInitialNode: (context) => buildInitialNodeFromSchema(context),
    ui: {
        localCapable: true,
        serverOnly: false
    },
    execute: createNodeModuleWorkerExecute('file')
};

export default fileNodeModule;
