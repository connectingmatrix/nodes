# File Node

## Runtime Ownership
Worker-first local node. No backend service is used.

## Usage
Use File to surface attached file envelopes for downstream parsing or upload nodes without invoking a backend helper.

## Inputs
- `files`: Attached workflow file envelopes.

## Outputs
- `output`: Object containing the attached `files` array.

## Backend Mapping
- No backend service is used.

## Failure Cases
- This node is deterministic and only fails if worker execution itself is unavailable.
