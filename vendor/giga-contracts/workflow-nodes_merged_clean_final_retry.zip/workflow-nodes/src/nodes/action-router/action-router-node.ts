import rawSchema from '@workflow/nodes/nodes/action-router/action-router-schema.json';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';
import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { resolveActionRouterInspectorFields, withActionRouterSchemaOptions } from '@workflow/nodes/nodes/giga-ai/grouped-action-schema';
import { WorkflowNodeKindEnum } from '@workflow/nodes/types';

const schema = parseNodeSchema(withActionRouterSchemaOptions(rawSchema), 'action-router');
const icon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <path d="M9 15h14c8 0 9 9 16 9" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/>
  <path d="M9 33h14c8 0 9-9 16-9" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/>
  <path d="M35 18l5 6-5 6" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;

const actionRouterNodeModule: WorkflowNodeModule = {
    id: 'action-router',
    schema,
    library: {
        id: 'giga-chat-action-router',
        label: 'Action Router',
        description: 'Expose grouped Action nodes as reusable governor tools.',
        gigaId: 'GigaChatActionRouterNode',
        modelId: 'action-router',
        group: 'Giga AI Nodes',
        nodeType: 'workflowStep',
        defaultKind: WorkflowNodeKindEnum.Process,
        iconColor: '#155e75',
        iconBackground: '#ecfeff',
        order: 222
    },
    renderIcon: icon,
    buildInitialNode: (context) => buildInitialNodeFromSchema(context),
    resolveInspectorFields: ({ fields, node }) => resolveActionRouterInspectorFields(fields, node),
    ui: { localCapable: true, serverOnly: false },
    execute: createNodeModuleWorkerExecute('action-router')
};

export default actionRouterNodeModule;
