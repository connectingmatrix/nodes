# Action Router

Worker-owned router for grouped backend action nodes.

No backend service is used.

- Connect `cmd:command` to AI Governor or AI Agent.
- Connect `cmd:actions` to one grouped Action node.
- Choose the target group with `broadcastModelId`.
- Restrict the exposed backend actions with `allowedActions`.
- Use `action` plus `parameters` rows for the requested backend action input.
- Keep shared runtime context explicit with `chatId`, `message`, `subjectIds`, `postIds`, `tagSlugs`, and `topK`.
- The router does not infer or rewrite IDs from message text, scope, or quoted values.

Supported groups:

- Channel
- Category
- Subject
- Post
- User Tree
- Chat
