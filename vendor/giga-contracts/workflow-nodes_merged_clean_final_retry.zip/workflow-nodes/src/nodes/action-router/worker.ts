import type { WorkflowCommandToolSpec, WorkerExecuteResult, WorkerPayload, WorkerScope, WorkerUpdateResult, WorkerValidateResult, WorkflowNodeStatus } from '@workflow/executor';
import { normalizeResult } from '@workflow/executor';
import {
    groupedActionGroupIds,
    groupedActionNames,
} from '@workflow/nodes/nodes/giga-ai/grouped-action-catalog.js';
import { actionRouterToolSpec } from './tool-spec';

const NODE_SCOPE: WorkerScope = {};

type Facade = {
    get: () => Promise<{ nodeId: string; name: string; modelId: string; status: WorkflowNodeStatus; runtime: Record<string, unknown>; properties: Record<string, unknown>; input: Record<string, Record<string, unknown>> }>;
    set: (patch: Record<string, unknown>) => Promise<unknown>;
    validate: (args?: { input?: Record<string, Record<string, unknown>>; patch?: Record<string, unknown> }) => Promise<WorkerValidateResult>;
    executeInputs: (args?: { patch?: Record<string, unknown> }) => Promise<{ input: Record<string, Record<string, unknown>> }>;
    execute: (args?: { input?: Record<string, Record<string, unknown>>; patch?: Record<string, unknown> }) => Promise<{ result: WorkerExecuteResult }>;
};

type Peer = { facade: Facade; snapshot: Awaited<ReturnType<Facade['get']>> };
type RoutedAction = { id: string; action: string; parameters: Record<string, unknown>; reason: string; dependencyResults: Record<string, unknown> };
const ROUTER_PASS_THROUGH_KEYS = ['chatId', 'message', 'topK', 'subjectIds', 'postIds', 'tagSlugs'] as const;

const recordValue = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});
const textValue = (value: unknown): string => String(value || '').trim();
const listValue = (value: unknown): string[] => (Array.isArray(value) ? value.map((entry) => textValue(entry)).filter(Boolean) : []);
const nodeValue = (payload: WorkerPayload): Record<string, unknown> => recordValue((payload as { NODE?: unknown }).NODE || payload.self);
const assignPath = (target: Record<string, unknown>, key: string, value: unknown) => {
    const parts = key.split('.').map((entry) => textValue(entry)).filter(Boolean);
    if (!parts.length) return;
    if (parts.length === 1) {
        target[parts[0]] = value;
        return;
    }
    let cursor: Record<string, unknown> = target;
    for (let index = 0; index < parts.length - 1; index += 1) {
        const part = parts[index];
        const current = recordValue(cursor[part]);
        cursor[part] = current;
        cursor = current;
    }
    cursor[parts[parts.length - 1]] = value;
};
const parameterValue = (value: unknown): Record<string, unknown> => {
    const record = recordValue(value);
    if (Object.keys(record).length) {
        const next: Record<string, unknown> = {};
        for (const [key, entry] of Object.entries(record)) assignPath(next, textValue(key), entry);
        return next;
    }
    const entries = Array.isArray(value) ? value : [];
    const next: Record<string, unknown> = {};
    for (const entry of entries) {
        const item = recordValue(entry);
        const key = textValue(item.key || item.name || item.label || (item.value !== undefined ? item.id : 'id'));
        if (!key) continue;
        assignPath(next, key, item.value !== undefined ? item.value : item.id);
    }
    return next;
};

const inspectorRuntimeParameters = (runtime: Record<string, unknown>): Record<string, unknown> => {
    const mapped: Record<string, unknown> = {};
    for (const key of ROUTER_PASS_THROUGH_KEYS) {
        const value = runtime[key];
        if (value === undefined || value === null) continue;
        if (textValue(value) === '') continue;
        mapped[key] = value;
    }
    return mapped;
};

const routedAction = (runtime: Record<string, unknown>): RoutedAction => {
    const action = textValue(runtime.action);
    if (!action) throw new Error('Action Router requires one selected Action.');
    const explicitParameters = parameterValue(runtime.parameters);
    return {
        id: textValue(runtime.actionId || 'router_action'),
        action,
        parameters: { ...explicitParameters, ...inspectorRuntimeParameters(runtime) },
        reason: textValue(runtime.reason || 'Routed workflow tool action.'),
        dependencyResults: recordValue(runtime.dependencyResults)
    };
};

const peersByModel = async (payload: WorkerPayload): Promise<Record<string, Peer>> => {
    const actions = recordValue(recordValue((payload.NODE as unknown as { CONTROL_NODES?: unknown }).CONTROL_NODES).actions);
    const peers: Record<string, Peer> = {};
    for (const facade of Object.values(actions) as Facade[]) {
        const snapshot = await facade.get();
        peers[snapshot.modelId] = { facade, snapshot };
    }
    return peers;
};

const restorePeer = async (peer: Peer, runtime: Record<string, unknown>): Promise<void> => {
    const currentRuntime: Record<string, unknown> = {};
    const currentProperties: Record<string, unknown> = {};
    for (const key of Object.keys(runtime)) {
        currentRuntime[key] = Object.prototype.hasOwnProperty.call(peer.snapshot.runtime, key) ? peer.snapshot.runtime[key] : undefined;
        currentProperties[key] = Object.prototype.hasOwnProperty.call(peer.snapshot.properties, key) ? peer.snapshot.properties[key] : undefined;
    }
    await peer.facade.set({ runtime: currentRuntime, properties: currentProperties });
};

const runtimePatch = (action: RoutedAction, runtime: Record<string, unknown>): Record<string, unknown> => {
    const runtimeParameters = inspectorRuntimeParameters(runtime);
    return { ...runtimeParameters, action: action.action, parameters: action.parameters, reason: action.reason, resultsById: action.dependencyResults };
};

const compactResult = (action: RoutedAction, value: unknown): Record<string, unknown> => {
    const record = recordValue(value);
    const error = textValue(record.error);
    const status = textValue(record.status || (error ? 'failed' : 'completed'));
    return {
        id: textValue(record.id || action.id),
        name: textValue(record.name || action.action),
        status,
        reason: textValue(record.reason || action.reason),
        summary: textValue(record.summary || `${action.action}: ${status}`),
        error: error || null,
        duration_ms: Number(record.duration_ms || 0),
        data: recordValue(record.data),
        sources: record.sources ?? []
    };
};

const runGroupedAction = async (peer: Peer, runtime: Record<string, unknown>) => {
    const patch = { runtime, properties: runtime };
    try {
        const prepared = await peer.facade.executeInputs({ patch });
        const validation = await peer.facade.validate({ input: prepared.input, patch });
        if (!validation.ok) throw new Error(validation.errors[0] || 'Action Router validation failed.');
        const executed = await peer.facade.execute({ input: prepared.input, patch });
        return normalizeResult(executed.result).output;
    } finally {
        await restorePeer(peer, runtime);
    }
};

export const validate = async (payload: WorkerPayload): Promise<WorkerValidateResult> => {
    const runtime = recordValue(nodeValue(payload).runtime);
    const broadcastModelId = textValue(runtime.broadcastModelId);
    const allowedActions = listValue(runtime.allowedActions);
    const strictConnectionCheck = runtime.strictConnectionCheck !== false;
    const errors: string[] = [];
    if (!groupedActionGroupIds.includes(broadcastModelId as (typeof groupedActionGroupIds)[number])) errors.push('Broadcast Model ID must select one grouped action node.');
    for (const action of allowedActions) if (!groupedActionNames(broadcastModelId).includes(action)) errors.push(`${action} does not belong to ${broadcastModelId}.`);
    const connectedGroups = Object.keys(await peersByModel(payload));
    if (strictConnectionCheck && connectedGroups.length && !connectedGroups.includes(broadcastModelId)) errors.push(`${broadcastModelId} must be connected on Actions.`);
    return { ok: errors.length === 0, errors, warnings: [], normalizedRuntime: runtime };
};

export const commandToolSpec = async (payload: WorkerPayload): Promise<WorkflowCommandToolSpec | null> => {
    const runtime = recordValue(nodeValue(payload).runtime);
    const broadcastModelId = textValue(runtime.broadcastModelId);
    return actionRouterToolSpec({
        allowedActions: listValue(runtime.allowedActions),
        broadcastModelId,
        description: textValue(runtime.description),
        nodeName: textValue(nodeValue(payload).name),
        toolDescription: textValue(runtime.toolDescription),
        toolName: textValue(runtime.toolName)
    });
};

export const init = async (payload: WorkerPayload): Promise<boolean> => {
    NODE_SCOPE.workflowId = textValue(recordValue(payload.workflow?.metadata).id);
    NODE_SCOPE.initialized = true;
    return true;
};

export const onUpdate = async (payload: WorkerPayload): Promise<WorkerUpdateResult> => {
    NODE_SCOPE.lastStatus = payload.self?.status || NODE_SCOPE.lastStatus;
    NODE_SCOPE.lastOutput = payload.self?.OUTPUT || NODE_SCOPE.lastOutput;
    return { ok: true, error: null };
};

export const execute = async (payload: WorkerPayload): Promise<WorkerExecuteResult> => {
    try {
        const runtime = recordValue(nodeValue(payload).runtime);
        const broadcastModelId = textValue(runtime.broadcastModelId);
        const strictConnectionCheck = runtime.strictConnectionCheck !== false;
        const action = routedAction(runtime);
        const allowedActions = listValue(runtime.allowedActions).length ? listValue(runtime.allowedActions) : groupedActionNames(broadcastModelId);
        if (!groupedActionNames(broadcastModelId).includes(action.action)) throw new Error(`${action.action} does not belong to ${broadcastModelId}.`);
        if (allowedActions.length && !allowedActions.includes(action.action)) throw new Error(`${action.action} is not allowed by this router.`);
        const peer = (await peersByModel(payload))[broadcastModelId];
        if (!peer) {
            const message = `${broadcastModelId} is not connected on Actions.`;
            if (strictConnectionCheck) throw new Error(message);
            return { output: { error: message, __activeOutputs: ['output'] }, status: 'failed', logs: [message], skipCommandPeerAutoRun: true };
        }
        const executed = await runGroupedAction(peer, runtimePatch(action, runtime));
        const rawActionResult = recordValue(executed).action || executed;
        const action_result = compactResult(action, rawActionResult);
        return { output: { action_result, action_results: [action_result], resultsById: { [action.id]: rawActionResult }, __activeOutputs: ['output'] }, status: 'passed', skipCommandPeerAutoRun: true };
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return { output: { error: message, __activeOutputs: ['output'] }, status: 'failed', logs: [message], skipCommandPeerAutoRun: true };
    }
};
