import type { WorkflowCommandToolSpec } from '@workflow/executor';
import {
    groupedActionGroupIds,
    groupedActionGroupLabel,
    groupedActionMutatingActions,
    groupedActionNames,
    groupedActionOptions,
    groupedActionParameterOptionsByAction
} from '@workflow/nodes/nodes/giga-ai/grouped-action-catalog.js';

export type ActionRouterToolSpecInput = {
    allowedActions: string[];
    broadcastModelId: string;
    description?: string;
    nodeName?: string;
    toolDescription?: string;
    toolName?: string;
};

export const actionRouterToolSpec = (input: ActionRouterToolSpecInput): WorkflowCommandToolSpec | null => {
    if (!groupedActionGroupIds.includes(input.broadcastModelId as (typeof groupedActionGroupIds)[number])) return null;
    const actions = input.allowedActions.length ? input.allowedActions : groupedActionNames(input.broadcastModelId);
    return {
        toolName: input.toolName || input.nodeName || groupedActionGroupLabel(input.broadcastModelId) || 'Action',
        toolDescription: input.toolDescription || input.description || `Execute one ${groupedActionGroupLabel(input.broadcastModelId) || 'grouped'} action through ${input.broadcastModelId}.`,
        inputContract: {
            required: [{ key: 'action', label: 'Action', description: 'Backend action name to execute through this router.', required: true, options: groupedActionOptions(input.broadcastModelId).filter((entry) => !actions.length || actions.includes(entry.value)) }],
            optional: [
                { key: 'parameters', label: 'Parameters', description: 'Add parameter rows with the allowed keys listed in metadata.parameterOptionsByAction.' },
                { key: 'chatId', label: 'Chat ID', description: 'Chat scope used by the grouped action runtime.' },
                { key: 'message', label: 'Message', description: 'User message used by the grouped action runtime.' },
                { key: 'subjectIds', label: 'Subjects', description: 'Optional scoped subjects. Leave empty to use all subjects in the current tree path.' },
                { key: 'postIds', label: 'Posts', description: 'Optional scoped posts. Leave empty to use all posts in the current tree path.' },
                { key: 'tagSlugs', label: 'Tags', description: 'Optional scoped tags. Leave empty to use all tags in the current tree path.' },
                { key: 'topK', label: 'Top K', description: 'Optional retrieval limit.' },
                { key: 'reason', label: 'Reason', description: 'Short explanation for why the planner selected this action.' }
            ]
        },
        outputContract: [{ key: 'action_result', label: 'Action Result', description: 'AgentActionResult payload returned by the grouped action node.' }],
        metadata: {
            broadcastModelId: input.broadcastModelId,
            allowedActions: actions,
            groupLabel: groupedActionGroupLabel(input.broadcastModelId),
            toolDomain: 'grouped-action',
            mutating: false,
            mutatingActions: groupedActionMutatingActions(input.broadcastModelId).filter((entry) => actions.includes(entry)),
            workflowOutput: false,
            parameterOptionsByAction: groupedActionParameterOptionsByAction(input.broadcastModelId)
        },
        executionKind: 'tool'
    };
};
