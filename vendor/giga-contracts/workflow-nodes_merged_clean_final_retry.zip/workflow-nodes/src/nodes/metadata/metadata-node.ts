import rawSchema from '@workflow/nodes/nodes/metadata/metadata-schema.json';
import { createNodeModuleWorkerExecute } from '@workflow/nodes/executor/module-worker-execute';
import { WorkflowNodeKindEnum } from '@workflow/nodes/types';
import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { buildInitialNodeFromSchema } from '@workflow/nodes/node-utils/node-module.factory';

const schema = parseNodeSchema(rawSchema, 'metadata');

const renderMetadataIcon = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <rect x="8" y="8" width="32" height="32" rx="6" stroke="currentColor" stroke-width="2.4"/>
  <circle cx="17" cy="18" r="3.5" fill="currentColor"/>
  <path d="M24 16h12M24 22h10M12 31h24M12 36h16" stroke="currentColor" stroke-width="2"/>
</svg>`;

const metadataNodeModule: WorkflowNodeModule = {
    id: 'metadata',
    schema,
    library: {
        id: 'metadata-node',
        label: 'Metadata',
        description: 'Metadata mapping and enrichment node.',
        gigaId: 'MetadataNode',
        modelId: 'metadata',
        group: 'Data',
        nodeType: 'workflowStep',
        defaultKind: WorkflowNodeKindEnum.Process,
        iconColor: '#7c3aed',
        iconBackground: '#f5f3ff',
        order: 30
    },
    renderIcon: renderMetadataIcon,
    buildInitialNode: (context) => buildInitialNodeFromSchema(context),
    ui: {
        localCapable: true,
        serverOnly: false
    },
    execute: createNodeModuleWorkerExecute('metadata')
};

export default metadataNodeModule;
