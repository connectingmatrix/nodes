# Metadata Node

## Runtime Ownership
Worker-first local node. No backend service is used.

## Usage
Expose the current input payload, node runtime properties, and node identity so downstream nodes can inspect workflow state without leaving the worker runtime.

## Inputs
- `input`: Incoming payload for this node.

## Outputs
- `output`: Object containing `input`, `properties`, and lightweight node metadata.

## Backend Mapping
- No backend service is used.

## Failure Cases
- This node is deterministic and only fails if the worker runtime itself cannot execute.
