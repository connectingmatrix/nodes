export type WorkflowNodeRuntimeScopeType =
  | "NODE"
  | "WORKFLOW"
  | "AI_AGENT"
  | "CHAT_DEFAULT";

export interface WorkflowNodeRuntimeScope {
  processId: string;
  parentScopeId?: string | null;
  scopeType: WorkflowNodeRuntimeScopeType | string;
  userId?: string | null;
  cpuPercent?: number | null;
  ramMb?: number | null;
  iteration?: number | null;
}

export const createWorkflowNodeRuntimeScope = (
  scope: Partial<WorkflowNodeRuntimeScope> & { processId: string },
): WorkflowNodeRuntimeScope => ({
  processId: scope.processId,
  parentScopeId: scope.parentScopeId || null,
  scopeType: scope.scopeType || "NODE",
  userId: scope.userId || null,
  cpuPercent: typeof scope.cpuPercent === "number" ? scope.cpuPercent : null,
  ramMb: typeof scope.ramMb === "number" ? scope.ramMb : null,
  iteration: typeof scope.iteration === "number" ? scope.iteration : null,
});
