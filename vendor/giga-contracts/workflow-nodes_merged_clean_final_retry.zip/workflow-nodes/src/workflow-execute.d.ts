declare module '@workflow/execute' {
    export * from '@workflow/executor';

    export const executeGigaService: (...args: unknown[]) => Promise<unknown>;
    export const executeBackend: (...args: unknown[]) => Promise<unknown>;
    export const invokeConnectedNode: (...args: unknown[]) => Promise<unknown>;
}
