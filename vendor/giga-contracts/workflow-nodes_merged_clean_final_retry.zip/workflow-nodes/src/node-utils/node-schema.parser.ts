import {
    WorkflowNodeDocumentation,
    WorkflowNodeDocumentationExample,
    WorkflowNodeDocumentationField,
    WorkflowFieldAiWriteMode,
    WorkflowNodeFieldDependsOn,
    WorkflowNodeFieldVariableCondition,
    WorkflowNodeFieldVisibleWhen,
    WorkflowNodeFieldDefinition,
    WorkflowNodeObjectArraySubFieldDefinition,
    WorkflowNodeObjectArrayValueMode,
    WorkflowInspectorFieldLayoutPreset,
    WorkflowNodeFieldMap,
    WorkflowNodeFieldType,
    WorkflowNodeFieldTypeEnum,
    WorkflowNodePortSide,
    WorkflowNodePortSideEnum,
    WorkflowNodePortProperty,
    WorkflowNodeSchema,
    WorkflowViewerType,
    WorkflowViewerTypeEnum
} from '../types';
import { isObjectRecord, parseFiniteNumber, parsePositiveInteger, parseUnknownArray } from './value-utils';

type UnknownRecord = Record<string, unknown>;
const isNonEmptyString = (value: unknown): value is string => typeof value === 'string' && value.trim().length > 0;
const isBoolean = (value: unknown): value is boolean => typeof value === 'boolean';
const isWorkflowScope = (value: unknown): value is 'user' | 'organization' => value === 'user' || value === 'organization';

const parseFieldType = (value: unknown): WorkflowNodeFieldType => {
    switch (value) {
        case WorkflowNodeFieldTypeEnum.String:
        case WorkflowNodeFieldTypeEnum.Textarea:
        case WorkflowNodeFieldTypeEnum.Markdown:
        case WorkflowNodeFieldTypeEnum.Number:
        case WorkflowNodeFieldTypeEnum.Boolean:
        case WorkflowNodeFieldTypeEnum.Json:
        case WorkflowNodeFieldTypeEnum.File:
        case WorkflowNodeFieldTypeEnum.Timestamp:
        case WorkflowNodeFieldTypeEnum.Select:
        case WorkflowNodeFieldTypeEnum.Method:
        case WorkflowNodeFieldTypeEnum.Headers:
        case WorkflowNodeFieldTypeEnum.FileList:
        case WorkflowNodeFieldTypeEnum.ObjectArray:
            return value;
        default:
            return WorkflowNodeFieldTypeEnum.String;
    }
};

const parsePortSide = (value: unknown, fallback: WorkflowNodePortSide): WorkflowNodePortSide => {
    switch (value) {
        case WorkflowNodePortSideEnum.Left:
        case WorkflowNodePortSideEnum.Right:
        case WorkflowNodePortSideEnum.Top:
        case WorkflowNodePortSideEnum.Bottom:
            return value;
        default:
            return fallback;
    }
};

const parseViewerType = (value: unknown): WorkflowViewerType => {
    switch (value) {
        case WorkflowViewerTypeEnum.Json:
        case WorkflowViewerTypeEnum.Markdown:
        case WorkflowViewerTypeEnum.Raw:
        case WorkflowViewerTypeEnum.Table:
            return value;
        default:
            return WorkflowViewerTypeEnum.Json;
    }
};

const parseFieldLayoutPreset = (value: unknown): WorkflowInspectorFieldLayoutPreset | undefined => {
    switch (value) {
        case 'half':
        case 'full':
        case 'mitigation':
        case 'switch':
        case 'inline':
            return value;
        default:
            return undefined;
    }
};

const parseAiWriteMode = (value: unknown): WorkflowFieldAiWriteMode | undefined => {
    switch (value) {
        case 'allow':
        case 'connected-options-only':
        case 'deny':
            return value;
        default:
            return undefined;
    }
};

const parseObjectArrayValueMode = (value: unknown): WorkflowNodeObjectArrayValueMode | undefined => {
    switch (value) {
        case 'object-array':
        case 'record':
        case 'string-array':
            return value;
        default:
            return undefined;
    }
};

const parseObjectArraySubFieldDefinition = (value: unknown): WorkflowNodeObjectArraySubFieldDefinition | undefined => {
    if (!isObjectRecord(value)) return undefined;
    const parsedType = parseFieldType(value.type);
    return {
        label: isNonEmptyString(value.label) ? value.label.trim() : undefined,
        type:
            parsedType === WorkflowNodeFieldTypeEnum.ObjectArray || parsedType === WorkflowNodeFieldTypeEnum.File || parsedType === WorkflowNodeFieldTypeEnum.FileList || parsedType === WorkflowNodeFieldTypeEnum.Headers
                ? WorkflowNodeFieldTypeEnum.String
                : parsedType,
        placeholder: isNonEmptyString(value.placeholder) ? value.placeholder.trim() : undefined,
        required: isBoolean(value.required) ? value.required : undefined,
        defaultValue: value.defaultValue,
        allowVariables: isBoolean(value.allowVariables) ? value.allowVariables : undefined,
        options: parseUnknownArray(value.options)
            .filter(isObjectRecord)
            .map((option) => ({
                label: isNonEmptyString(option.label) ? option.label : '',
                value: isNonEmptyString(option.value) ? option.value : ''
            }))
            .filter((option) => option.label.length > 0 && option.value.length > 0),
        optionsSource: isNonEmptyString(value.optionsSource) ? value.optionsSource.trim() : undefined,
        styleCol: parsePositiveInteger(value.styleCol ?? value.style_col),
        min: parseFiniteNumber(value.min),
        max: parseFiniteNumber(value.max),
        step: parseFiniteNumber(value.step)
    };
};

const parseObjectArraySubFields = (value: unknown): Record<string, WorkflowNodeObjectArraySubFieldDefinition> | undefined => {
    if (!isObjectRecord(value)) return undefined;
    const parsed = Object.entries(value).reduce<Record<string, WorkflowNodeObjectArraySubFieldDefinition>>((acc, [fieldName, fieldValue]) => {
        const next = parseObjectArraySubFieldDefinition(fieldValue);
        if (!next) return acc;
        acc[fieldName] = next;
        return acc;
    }, {});
    return Object.keys(parsed).length > 0 ? parsed : undefined;
};

const parseDependsOn = (value: unknown): WorkflowNodeFieldDependsOn | undefined => {
    if (!isObjectRecord(value) || !isNonEmptyString(value.field)) return undefined;
    const fallback = isObjectRecord(value.fallback)
        ? {
              min: parseFiniteNumber(value.fallback.min),
              max: parseFiniteNumber(value.fallback.max),
              step: parseFiniteNumber(value.fallback.step)
          }
        : undefined;
    const map = isObjectRecord(value.map)
        ? Object.entries(value.map).reduce<Record<string, NonNullable<WorkflowNodeFieldDependsOn['fallback']>>>((acc, [entryKey, entryValue]) => {
              if (!isObjectRecord(entryValue)) return acc;
              acc[String(entryKey).trim().toLowerCase()] = {
                  min: parseFiniteNumber(entryValue.min),
                  max: parseFiniteNumber(entryValue.max),
                  step: parseFiniteNumber(entryValue.step)
              };
              return acc;
          }, {})
        : undefined;

    return {
        field: value.field.trim(),
        map: map && Object.keys(map).length > 0 ? map : undefined,
        fallback,
        entityField: isBoolean(value.entityField) ? value.entityField : undefined
    };
};

const parseVariableCondition = (value: unknown): WorkflowNodeFieldVariableCondition | undefined => {
    if (!isObjectRecord(value) || !isNonEmptyString(value.field)) return undefined;
    return {
        field: value.field.trim(),
        value: value.value
    };
};

const parseVisibleCondition = (value: unknown): WorkflowNodeFieldVisibleWhen | undefined => {
    if (!isObjectRecord(value) || !isNonEmptyString(value.field)) return undefined;
    const includes = parseUnknownArray(value.includes)
        .filter(isNonEmptyString)
        .map((entry) => entry.trim().toLowerCase());
    return {
        field: value.field.trim(),
        equals: isNonEmptyString(value.equals) ? value.equals.trim().toLowerCase() : undefined,
        notEquals: isNonEmptyString(value.notEquals) ? value.notEquals.trim().toLowerCase() : undefined,
        includes: includes.length ? includes : undefined
    };
};

const SYSTEM_FIELD_KEYS = new Set(['status', 'source', 'timestamp', 'nodelibraryid']);

const resolveDefaultAllowVariables = (fieldName: string, field: UnknownRecord, parsedType: WorkflowNodeFieldType): boolean => {
    if (SYSTEM_FIELD_KEYS.has(fieldName.trim().toLowerCase())) return false;
    if (isBoolean(field.hidden) && field.hidden) return false;
    if (isBoolean(field.auto) && field.auto) return false;
    if (
        parsedType === WorkflowNodeFieldTypeEnum.Boolean ||
        parsedType === WorkflowNodeFieldTypeEnum.Number ||
        parsedType === WorkflowNodeFieldTypeEnum.Timestamp ||
        parsedType === WorkflowNodeFieldTypeEnum.File ||
        parsedType === WorkflowNodeFieldTypeEnum.FileList
    ) {
        return false;
    }
    return isBoolean(field.editable) ? field.editable : true;
};

const parseFieldDefinition = (source: unknown, fieldName: string): WorkflowNodeFieldDefinition => {
    const field = isObjectRecord(source) ? source : {};
    const styles = isObjectRecord(field.styles) ? field.styles : {};
    const parsedType = parseFieldType(field.type);
    const parsedLayoutPreset = parseFieldLayoutPreset(styles.layoutPreset);
    const parsedColumns = parsePositiveInteger(styles.columns);
    const parsedLabelCols = parsePositiveInteger(styles.labelCols);
    const parsedControlCols = parsePositiveInteger(styles.controlCols);
    const parsedCompanionCols = parsePositiveInteger(styles.companionCols);
    const parsedShowSlider = isBoolean(styles.showSlider) ? styles.showSlider : undefined;
    const parsedFloatingLabel = isBoolean(styles.floatingLabel) ? styles.floatingLabel : undefined;
    const parsedAiWriteMode = parseAiWriteMode(field.aiWriteMode);
    const parsedAiSourcePort = isNonEmptyString(field.aiSourcePort) ? field.aiSourcePort.trim() : undefined;
    const parsedObjectArraySubFields = parseObjectArraySubFields(field.subFields);
    const parsedMinimum = parsePositiveInteger(field.minimum);
    const parsedValueMode = parseObjectArrayValueMode(field.valueMode);
    const parsedKeyField = isNonEmptyString(field.keyField) ? field.keyField.trim() : undefined;
    const parsedValueField = isNonEmptyString(field.valueField) ? field.valueField.trim() : undefined;
    const parsedDependsOn = parseDependsOn(field.dependsOn);
    const parsedVisibleCondition = parseVisibleCondition(field.visibleWhen);
    const parsedVariableCondition = parseVariableCondition(field.resolveVariablesWhen);
    const parsedStyles =
        parsedLayoutPreset !== undefined ||
        isBoolean(styles.showBooleanState) ||
        parsedShowSlider !== undefined ||
        parsedFloatingLabel !== undefined ||
        parsedColumns !== undefined ||
        parsedLabelCols !== undefined ||
        parsedControlCols !== undefined ||
        parsedCompanionCols !== undefined ||
        isBoolean(styles.compact)
            ? {
                  layoutPreset: parsedLayoutPreset,
                  showBooleanState: isBoolean(styles.showBooleanState) ? styles.showBooleanState : undefined,
                  showSlider: parsedShowSlider,
                  floatingLabel: parsedFloatingLabel,
                  columns: parsedColumns,
                  labelCols: parsedLabelCols,
                  controlCols: parsedControlCols,
                  companionCols: parsedCompanionCols,
                  compact: isBoolean(styles.compact) ? styles.compact : undefined
              }
            : undefined;
    return {
        order: parsePositiveInteger(field.order),
        type: parsedType,
        hidden: isBoolean(field.hidden) ? field.hidden : false,
        auto: isBoolean(field.auto) ? field.auto : false,
        required: isBoolean(field.required) ? field.required : false,
        editable: isBoolean(field.editable) ? field.editable : true,
        allowVariables: isBoolean(field.allowVariables) ? field.allowVariables : resolveDefaultAllowVariables(fieldName, field, parsedType),
        defaultValue: field.defaultValue,
        label: isNonEmptyString(field.label) ? field.label : undefined,
        options: parseUnknownArray(field.options)
            .filter(isObjectRecord)
            .map((option) => ({
                label: isNonEmptyString(option.label) ? option.label : '',
                value: isNonEmptyString(option.value) ? option.value : ''
            }))
            .filter((option) => option.label.length > 0 && option.value.length > 0),
        optionsSource: isNonEmptyString(field.optionsSource) ? field.optionsSource.trim() : undefined,
        placeholder: isNonEmptyString(field.placeholder) ? field.placeholder : undefined,
        accept: isNonEmptyString(field.accept) ? field.accept : undefined,
        multi: isBoolean(field.multi) ? field.multi : undefined,
        min: parseFiniteNumber(field.min),
        max: parseFiniteNumber(field.max),
        step: parseFiniteNumber(field.step),
        subFields: parsedObjectArraySubFields,
        minimum: parsedMinimum,
        addButtonLabel: isNonEmptyString(field.addButtonLabel) ? field.addButtonLabel.trim() : undefined,
        valueMode: parsedValueMode,
        keyField: parsedKeyField,
        valueField: parsedValueField,
        dependsOn: parsedDependsOn,
        visibleWhen: parsedVisibleCondition,
        resolveVariablesWhen: parsedVariableCondition,
        aiWriteMode: parsedAiWriteMode,
        aiSourcePort: parsedAiSourcePort,
        styles: parsedStyles
    };
};

const parseDocumentationField = (source: unknown, fallbackKey: string, fallbackLabel: string): WorkflowNodeDocumentationField => {
    const field = isObjectRecord(source) ? source : {};
    return {
        key: isNonEmptyString(field.key) ? field.key : fallbackKey,
        label: isNonEmptyString(field.label) ? field.label : fallbackLabel,
        description: isNonEmptyString(field.description) ? field.description : `${fallbackLabel} value.`,
        required: isBoolean(field.required) ? field.required : undefined
    };
};

const parseDocumentationFields = (source: unknown): WorkflowNodeDocumentationField[] => {
    const entries = parseUnknownArray(source);
    if (!entries.length) return [];
    return entries.map((entry, index) => parseDocumentationField(entry, `field_${index + 1}`, `Field ${index + 1}`));
};

const parseDocumentationExample = (source: unknown, fallbackIndex: number): WorkflowNodeDocumentationExample => {
    const example = isObjectRecord(source) ? source : {};
    return {
        title: isNonEmptyString(example.title) ? example.title : `Example ${fallbackIndex}`,
        description: isNonEmptyString(example.description) ? example.description : undefined,
        setup: isNonEmptyString(example.setup) ? example.setup : undefined,
        output: isNonEmptyString(example.output) ? example.output : undefined
    };
};

const parseDocumentationExamples = (source: unknown): WorkflowNodeDocumentationExample[] => {
    const entries = parseUnknownArray(source);
    if (!entries.length) return [];
    return entries.map((entry, index) => parseDocumentationExample(entry, index + 1));
};

const parseNodeDocumentation = (source: unknown): WorkflowNodeDocumentation | undefined => {
    if (!isObjectRecord(source)) return undefined;
    return {
        nodeTypeLabel: isNonEmptyString(source.nodeTypeLabel) ? source.nodeTypeLabel : undefined,
        summary: isNonEmptyString(source.summary) ? source.summary : 'No summary provided.',
        usage: isNonEmptyString(source.usage) ? source.usage : 'No usage notes provided.',
        inputs: parseDocumentationFields(source.inputs),
        outputs: parseDocumentationFields(source.outputs),
        examples: parseDocumentationExamples(source.examples),
        failureCases: parseUnknownArray(source.failureCases).filter(isNonEmptyString),
        backend: isObjectRecord(source.backend)
            ? {
                  key: isNonEmptyString(source.backend.key) ? source.backend.key : undefined,
                  handler: isNonEmptyString(source.backend.handler) ? source.backend.handler : undefined,
                  action: isNonEmptyString(source.backend.action) ? source.backend.action : undefined,
                  service: isNonEmptyString(source.backend.service) ? source.backend.service : undefined,
                  notes: parseUnknownArray(source.backend.notes).filter(isNonEmptyString)
              }
            : undefined
    };
};

const parseNodeSandbox = (source: unknown): WorkflowNodeSchema['sandbox'] | undefined => {
    if (!isObjectRecord(source)) return undefined;
    const transport = isNonEmptyString(source.transport) ? source.transport.trim().toLowerCase() : '';
    return {
        transport:
            transport === 'openai-unix-sandbox'
                ? 'openai-unix-sandbox'
                : transport === 'worker-sandbox'
                  ? 'worker-sandbox'
                  : undefined,
        allowProcessApis: isBoolean(source.allowProcessApis) ? source.allowProcessApis : undefined
    };
};

export const parseFields = (source: unknown): WorkflowNodeFieldMap => {
    if (!isObjectRecord(source)) return {};
    return Object.entries(source).reduce<WorkflowNodeFieldMap>((acc, [fieldName, fieldValue]) => {
        acc[fieldName] = parseFieldDefinition(fieldValue, fieldName);
        return acc;
    }, {});
};

const parsePortMap = (source: unknown, fallbackPort: string, defaultAllowMultiple: boolean, defaultSide: WorkflowNodePortSide): Record<string, WorkflowNodePortProperty> => {
    if (source === undefined || source === null) {
        return { [fallbackPort]: { allowMultipleArrows: defaultAllowMultiple, side: defaultSide, order: 1 } };
    }

    if (!isObjectRecord(source)) {
        return { [fallbackPort]: { allowMultipleArrows: defaultAllowMultiple, side: defaultSide, order: 1 } };
    }

    if (Object.keys(source).length === 0) {
        return {};
    }

    return Object.entries(source).reduce<Record<string, WorkflowNodePortProperty>>((acc, [portName, portRule]) => {
        const ruleRecord = isObjectRecord(portRule) ? portRule : {};
        const parsedOrder = Number(ruleRecord.order);
        const acceptedSourceGroups = parseUnknownArray(ruleRecord.acceptedSourceGroups).filter(isNonEmptyString);
        const acceptedSourceModelIds = parseUnknownArray(ruleRecord.acceptedSourceModelIds).filter(isNonEmptyString);
        acc[portName] = {
            allowMultipleArrows: isBoolean(ruleRecord.allowMultipleArrows) ? ruleRecord.allowMultipleArrows : defaultAllowMultiple,
            side: parsePortSide(ruleRecord.side, defaultSide),
            order: Number.isFinite(parsedOrder) ? parsedOrder : undefined,
            label: isNonEmptyString(ruleRecord.label) ? ruleRecord.label : undefined,
            portType: isNonEmptyString(ruleRecord.portType) ? ruleRecord.portType.trim() : undefined,
            acceptedSourceGroups: acceptedSourceGroups.length ? acceptedSourceGroups : undefined,
            acceptedSourceModelIds: acceptedSourceModelIds.length ? acceptedSourceModelIds : undefined,
            showQuickAdd: isBoolean(ruleRecord.showQuickAdd) ? ruleRecord.showQuickAdd : undefined
        };
        return acc;
    }, {});
};

const BI_DIRECTIONAL_PORT_TYPE = 'bi-directional';

const deriveCommandPortMap = (
    sourceCommands: unknown,
    sourceInputs: unknown,
    sourceOutputs: unknown
): Record<string, WorkflowNodePortProperty> => {
    const explicitCommands = isObjectRecord(sourceCommands)
        ? parsePortMap(sourceCommands, '', true, WorkflowNodePortSideEnum.Bottom)
        : {};
    const mergeLegacyPort = (portId: string, rules: WorkflowNodePortProperty | undefined, legacySide: WorkflowNodePortSide) => {
        if (!rules || rules.portType !== BI_DIRECTIONAL_PORT_TYPE) return;
        const existing = explicitCommands[portId] ?? {};
        explicitCommands[portId] = {
            ...rules,
            ...existing,
            side: existing.side ?? rules.side ?? legacySide,
            portType: BI_DIRECTIONAL_PORT_TYPE
        };
    };

    Object.entries(parsePortMap(sourceInputs, '', true, WorkflowNodePortSideEnum.Left)).forEach(([portId, rules]) => {
        mergeLegacyPort(portId, rules, WorkflowNodePortSideEnum.Left);
    });
    Object.entries(parsePortMap(sourceOutputs, '', true, WorkflowNodePortSideEnum.Right)).forEach(([portId, rules]) => {
        mergeLegacyPort(portId, rules, WorkflowNodePortSideEnum.Right);
    });

    return explicitCommands;
};

const parseOutputViewers = (source: unknown): WorkflowNodeSchema['outputViewers'] => {
    const viewers = parseUnknownArray(source).filter(isObjectRecord);
    if (viewers.length === 0) {
        return [{ id: 'json', label: 'JSON', type: WorkflowViewerTypeEnum.Json }];
    }
    return viewers.map((viewer, index) => ({
        id: isNonEmptyString(viewer.id) ? viewer.id : `viewer_${index}`,
        label: isNonEmptyString(viewer.label) ? viewer.label : 'JSON',
        type: parseViewerType(viewer.type)
    }));
};

export const parseNodeSchema = (raw: unknown, fallbackId: string): WorkflowNodeSchema => {
    const source = isObjectRecord(raw) ? raw : {};
    const name = isObjectRecord(source.name) ? source.name : {};
    const instruction = isObjectRecord(source.instruction) ? source.instruction : {};
    const schemaStyles = isObjectRecord(source.styles) ? source.styles : {};
    const inspectorColumns = parsePositiveInteger(schemaStyles.inspectorColumns);

    return {
        id: isNonEmptyString(source.id) ? source.id : fallbackId,
        group: isNonEmptyString(source.group) ? source.group.trim() : undefined,
        useCredentials: isNonEmptyString(source.useCredentials) ? source.useCredentials.trim() : undefined,
        useWorkflows: parseUnknownArray(source.useWorkflows).filter(isWorkflowScope),
        iconClass: isNonEmptyString(source.iconClass) ? source.iconClass : 'pi pi-box',
        iconColor: isNonEmptyString(source.iconColor) ? source.iconColor : undefined,
        iconMode: source.iconMode === 'svg' || source.iconMode === 'prime' ? source.iconMode : undefined,
        iconSvg: isNonEmptyString(source.iconSvg) ? source.iconSvg : undefined,
        render: isObjectRecord(source.render) ? (source.render as WorkflowNodeSchema['render']) : undefined,
        executorKey: isNonEmptyString(source.executorKey) ? source.executorKey : fallbackId,
        instruction: {
            code: isBoolean(instruction.code) ? instruction.code : false,
            markdown: isBoolean(instruction.markdown) ? instruction.markdown : false
        },
        outputViewers: parseOutputViewers(source.outputViewers),
        name: {
            type: WorkflowNodeFieldTypeEnum.String,
            editable: isBoolean(name.editable) ? name.editable : true,
            autoGenerate: isBoolean(name.autoGenerate) ? name.autoGenerate : true
        },
        fields: parseFields(source.fields),
        inputs: parsePortMap(source.inputs, 'input', false, WorkflowNodePortSideEnum.Left),
        outputs: parsePortMap(source.outputs, 'output', true, WorkflowNodePortSideEnum.Right),
        commands: deriveCommandPortMap(source.commands, source.inputs, source.outputs),
        documentation: parseNodeDocumentation(source.documentation),
        sandbox: parseNodeSandbox(source.sandbox),
        styles: inspectorColumns ? { inspectorColumns } : undefined
    };
};
