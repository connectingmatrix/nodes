import { WorkflowNodeBuildContext } from './node-module.types';
import { WorkflowNodeKindEnum, WorkflowNodeModel, WorkflowNodeStatusEnum, WorkflowViewerTypeEnum } from '../types';
import { parseNodeProperties } from '../utils/workflow-field-parser.utils';

interface NodeInitOverrides {
    properties?: Record<string, unknown>;
    output?: unknown;
    code?: string;
    markdown?: string;
}

export const buildNodeViewers = (node: Pick<WorkflowNodeBuildContext, 'schema'>): NonNullable<WorkflowNodeModel['inspector']>['viewers'] => {
    const viewers = node.schema.outputViewers ?? [{ id: 'json', label: 'JSON', type: WorkflowViewerTypeEnum.Json as const }];
    return viewers.map((viewer) => ({
        ...viewer,
        value: viewer.type === WorkflowViewerTypeEnum.Table ? [] : {}
    }));
};

export const buildInitialNodeFromSchema = (context: WorkflowNodeBuildContext, overrides: NodeInitOverrides = {}): WorkflowNodeModel => {
    const instruction = context.schema.instruction ?? { code: false, markdown: false };
    const runtime = parseNodeProperties(context.schema.fields, {
        description: context.libraryItem.description,
        status: WorkflowNodeStatusEnum.Stopped,
        source: '',
        nodeLibraryId: context.libraryItem.id,
        forwardSessionLogs: false,
        ...(overrides.properties ?? {})
    });
    if (instruction.code) runtime.code = overrides.code ?? 'return input;';
    if (instruction.markdown) runtime.markdown = overrides.markdown ?? '';
    const output = overrides.output ?? {};

    return {
        id: context.nodeId,
        gigaId: context.libraryItem.gigaId,
        modelId: context.libraryItem.modelId,
        type: context.libraryItem.nodeType,
        name: context.nodeName,
        description: context.libraryItem.description,
        kind: context.libraryItem.defaultKind ?? WorkflowNodeKindEnum.Process,
        status: WorkflowNodeStatusEnum.Stopped,
        position: context.position,
        runtime,
        ports: {
            in: {},
            out: {
                output: output as Record<string, unknown>
            }
        },
        render: context.schema.render,
        // Legacy UI compatibility fields (derived from runtime/ports).
        input: {},
        output,
        properties: runtime,
        inspector: {
            title: context.nodeName,
            input: {},
            properties: runtime,
            code: instruction.code ? String(runtime.code ?? '') : '',
            markdown: instruction.markdown ? String(runtime.markdown ?? '') : '',
            viewers: buildNodeViewers(context)
        }
    };
};
