import { WorkflowNodeFileValue } from '../types';
import {
    isObjectRecord,
    parseBooleanValue,
    parseHeaderRecord,
    parseNumberValue,
    parseRecordValue,
    parseStringList,
    parseStringValue
} from './value-utils';
import * as XLSX from 'xlsx';

export { isObjectRecord, parseRecordValue, parseStringValue, parseNumberValue, parseBooleanValue, parseStringList, parseHeaderRecord };

export const createBodyFileFromEnvelope = (file: WorkflowNodeFileValue): File => {
    const binary = atob(file.contentBase64 ?? '');
    const bytes = Uint8Array.from(binary, (item) => item.charCodeAt(0));
    return new File([bytes], file.name ?? 'attachment.bin', { type: file.mimeType ?? 'application/octet-stream' });
};

export const createWorkbookFromFileEnvelope = (file: WorkflowNodeFileValue): XLSX.WorkBook => {
    const fileName = (file.name ?? '').toLowerCase();
    const isCsvLike = fileName.endsWith('.csv') || file.mimeType === 'text/csv';
    if (isCsvLike && file.extractedText) {
        return XLSX.read(file.extractedText, { type: 'string' });
    }
    return XLSX.read(file.contentBase64 ?? '', { type: 'base64' });
};
