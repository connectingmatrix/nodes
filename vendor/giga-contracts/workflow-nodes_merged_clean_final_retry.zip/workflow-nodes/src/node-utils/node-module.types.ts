import type { WorkflowNodeHandler, WorkflowNodeHandlerContext } from '@workflow/executor';
import { WorkflowDefinition, WorkflowNodeFieldMap, WorkflowNodeLibraryItem, WorkflowNodeModel, WorkflowNodeSchema } from '../types';

export interface WorkflowNodeBuildContext {
    nodeId: string;
    nodeName: string;
    schema: WorkflowNodeSchema;
    libraryItem: WorkflowNodeLibraryItem;
    position: {
        x: number;
        y: number;
    };
}

export interface WorkflowNodeInspectorUiConfig {
    hiddenFieldKeys?: string[];
    instructionOnly?: boolean;
    showGraphqlQuerySection?: boolean;
    codeAllowVariables?: boolean;
}

export interface WorkflowNodeUiConfig {
    localCapable?: boolean;
    serverOnly?: boolean;
    inspector?: WorkflowNodeInspectorUiConfig;
}

export interface WorkflowNodeInspectorFieldContext {
    workflow: WorkflowDefinition;
    node: WorkflowNodeModel;
    fields: WorkflowNodeFieldMap;
}

export interface WorkflowNodeModule {
    id: string;
    schema: WorkflowNodeSchema;
    library: WorkflowNodeLibraryItem & { order?: number };
    renderIcon: (size: number) => string;
    buildInitialNode: (context: WorkflowNodeBuildContext) => WorkflowNodeModel;
    ui?: WorkflowNodeUiConfig;
    resolveInspectorFields?: (context: WorkflowNodeInspectorFieldContext) => WorkflowNodeFieldMap;
    execute: WorkflowNodeHandler;
}
