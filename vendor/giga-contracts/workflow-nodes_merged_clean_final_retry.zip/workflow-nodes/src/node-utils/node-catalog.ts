import codeNode from '@workflow/nodes/nodes/code/code-node';
import startNode from '@workflow/nodes/nodes/start/start-node';
import ifElseNode from '@workflow/nodes/nodes/if-else/if-else-node';
import metadataNode from '@workflow/nodes/nodes/metadata/metadata-node';
import graphqlNode from '@workflow/nodes/nodes/graphql/graphql-node';
import currentChatNode from '@workflow/nodes/nodes/current-chat/current-chat-node';
import textAnalysisNode from '@workflow/nodes/nodes/text-analysis/text-analysis-node';
import currentSubjectsNode from '@workflow/nodes/nodes/current-subjects/current-subjects-node';
import httpRequestNode from '@workflow/nodes/nodes/http-request/http-request-node';
import fileNode from '@workflow/nodes/nodes/file/file-node';
import excelNode from '@workflow/nodes/nodes/excel/excel-node';
import stopErrorNode from '@workflow/nodes/nodes/stop-error/stop-error-node';
import respondEndNode from '@workflow/nodes/nodes/respond-end/respond-end-node';
import executeWorkflowNode from '@workflow/nodes/nodes/execute-workflow/execute-workflow-node';
import waitNode from '@workflow/nodes/nodes/wait/wait-node';
import serpSearchNode from '@workflow/nodes/nodes/serp-search/serp-search-node';
import analyzeTextWithModelNode from '@workflow/nodes/nodes/analyze-text-with-model/analyze-text-with-model-node';
import runChannelActionNode from '@workflow/nodes/nodes/run-channel-action/run-channel-action-node';
import runCategoryActionNode from '@workflow/nodes/nodes/run-category-action/run-category-action-node';
import runSubjectActionNode from '@workflow/nodes/nodes/run-subject-action/run-subject-action-node';
import runPostActionNode from '@workflow/nodes/nodes/run-post-action/run-post-action-node';
import runUserTreeActionNode from '@workflow/nodes/nodes/run-user-tree-action/run-user-tree-action-node';
import runChatActionNode from '@workflow/nodes/nodes/run-chat-action/run-chat-action-node';
import actionRouterNode from '@workflow/nodes/nodes/action-router/action-router-node';
import validateWorkflowCypherNode from '@workflow/nodes/nodes/validate-workflow-cypher/validate-workflow-cypher-node';
import outputFormatNode from '@workflow/nodes/nodes/output-format/output-format-node';
import aiAgentNode from '@workflow/nodes/nodes/ai-agent/ai-agent-node';
import workflowNode from '@workflow/nodes/nodes/workflow/workflow-node';
import chartNode from '@workflow/nodes/nodes/chart/chart-node';
import mergeNode from '@workflow/nodes/nodes/merge/merge-node';
import loopOverItemsNode from '@workflow/nodes/nodes/loop-over-items/loop-over-items-node';
import replaceMeNode from '@workflow/nodes/nodes/replace-me/replace-me-node';
import openAiNode from '@workflow/nodes/nodes/openai/openai-node';
import claudeNode from '@workflow/nodes/nodes/claude/claude-node';
import geminiNode from '@workflow/nodes/nodes/gemini/gemini-node';
import groqNode from '@workflow/nodes/nodes/groq/groq-node';
import deepseekNode from '@workflow/nodes/nodes/deepseek/deepseek-node';
import perplexityNode from '@workflow/nodes/nodes/perplexity/perplexity-node';
import mistralNode from '@workflow/nodes/nodes/mistral/mistral-node';
import mcpRuntimeNode from '@workflow/nodes/nodes/mcp-runtime/mcp-runtime-node';
import mcpCapabilitiesNode from '@workflow/nodes/nodes/mcp-capabilities/mcp-capabilities-node';
import workflowFileDownloadNode from '@workflow/nodes/nodes/workflow-file-download/workflow-file-download-node';
import workflowFileInspectNode from '@workflow/nodes/nodes/workflow-file-inspect/workflow-file-inspect-node';
import workflowArtifactPublishNode from '@workflow/nodes/nodes/workflow-artifact-publish/workflow-artifact-publish-node';
import sharedSpaceNode from '@workflow/nodes/nodes/shared-space/shared-space-node';
import databaseDriverNode from '@workflow/nodes/nodes/database-driver/database-driver-node';
import gmailNode from '@workflow/nodes/nodes/gmail/gmail-node';
import emailNode from '@workflow/nodes/nodes/email/email-node';
import airtableNode from '@workflow/nodes/nodes/airtable/airtable-node';
import googleSheetsNode from '@workflow/nodes/nodes/google-sheets/google-sheets-node';
import googleDriveNode from '@workflow/nodes/nodes/google-drive/google-drive-node';
import slackNode from '@workflow/nodes/nodes/slack/slack-node';
import agentFileIngestNode from '@workflow/nodes/nodes/agent-file-ingest/agent-file-ingest-node';
import artifactPublishNode from '@workflow/nodes/nodes/artifact-publish/artifact-publish-node';
import neuralNetTrainerNode from '@workflow/nodes/nodes/neural-net-trainer/neural-net-trainer-node';
import loaderNode from '@workflow/nodes/nodes/loader/loader-node';
import evaluatorNode from '@workflow/nodes/nodes/evaluator/evaluator-node';
import sentimentAnalysisNode from '@workflow/nodes/nodes/sentiment-analysis/sentiment-analysis-node';
import churnAnalysisNode from '@workflow/nodes/nodes/churn-analysis/churn-analysis-node';
import featureAnalysisNode from '@workflow/nodes/nodes/feature-analysis/feature-analysis-node';

import { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import { parseNodeSchema } from '@workflow/nodes/node-utils/node-schema.parser';
import { WorkflowNodeFieldTypeEnum, WorkflowNodeLibraryItem, WorkflowNodePortSideEnum, WorkflowNodeSchema, WorkflowViewerTypeEnum } from '@workflow/nodes/types';
const parseSchemaWithDefaults = (raw: unknown, fallbackId: string): WorkflowNodeSchema => parseNodeSchema(raw, fallbackId);

export const NODE_MODULES: WorkflowNodeModule[] = [
  startNode,
  codeNode,
  ifElseNode,
  metadataNode,
  graphqlNode,
  currentChatNode,
  textAnalysisNode,
  currentSubjectsNode,
  httpRequestNode,
  fileNode,
  excelNode,
  waitNode,
  serpSearchNode,
  analyzeTextWithModelNode,
  runChannelActionNode,
  runCategoryActionNode,
  runSubjectActionNode,
  runPostActionNode,
  runUserTreeActionNode,
  runChatActionNode,
  actionRouterNode,
  validateWorkflowCypherNode,
  outputFormatNode,
  aiAgentNode,
  workflowNode,
  chartNode,
  mergeNode,
  loopOverItemsNode,
  replaceMeNode,
  openAiNode,
  claudeNode,
  geminiNode,
  groqNode,
  deepseekNode,
  perplexityNode,
  mistralNode,
  mcpRuntimeNode,
  mcpCapabilitiesNode,
  workflowFileDownloadNode,
  sharedSpaceNode,
  workflowFileInspectNode,
  workflowArtifactPublishNode,
  databaseDriverNode,
  gmailNode,
  emailNode,
  airtableNode,
  googleSheetsNode,
  googleDriveNode,
  slackNode,
  agentFileIngestNode,
  artifactPublishNode,
  neuralNetTrainerNode,
  loaderNode,
  evaluatorNode,
  sentimentAnalysisNode,
  churnAnalysisNode,
  featureAnalysisNode,
  stopErrorNode,
  respondEndNode,
  executeWorkflowNode,
];

export const NODE_MODULES_BY_ID: Record<string, WorkflowNodeModule> = NODE_MODULES.reduce<Record<string, WorkflowNodeModule>>((acc, item) => {
  acc[item.id] = item;
  return acc;
}, {});

const resolveNodeGroup = (schema: WorkflowNodeSchema, moduleGroup: string | undefined): string => {
  const normalizedModuleGroup = moduleGroup?.trim();
  if (normalizedModuleGroup) return normalizedModuleGroup;
  const schemaGroup = schema.group?.trim();
  if (schemaGroup) return schemaGroup;
  return 'Other';
};

const FALLBACK_NODE_MODULE = NODE_MODULES_BY_ID.code ?? NODE_MODULES[0];

const mergeBuiltInNodeSchema = (workflowSchema: WorkflowNodeSchema, localSchema: WorkflowNodeSchema): WorkflowNodeSchema => ({
  ...workflowSchema,
  ...localSchema,
  render: localSchema.render ?? workflowSchema.render,
  instruction: localSchema.instruction ?? workflowSchema.instruction,
  outputViewers: localSchema.outputViewers ?? workflowSchema.outputViewers,
  name: localSchema.name ?? workflowSchema.name,
  fields: localSchema.fields ?? workflowSchema.fields,
  inputs: localSchema.inputs ?? workflowSchema.inputs,
  outputs: localSchema.outputs ?? workflowSchema.outputs,
  commands: localSchema.commands ?? workflowSchema.commands,
  documentation: localSchema.documentation ?? workflowSchema.documentation,
  styles: localSchema.styles ?? workflowSchema.styles,
});

const buildUnknownNodeSchema = (modelId: string): WorkflowNodeSchema => {
  return parseSchemaWithDefaults(
    {
      id: modelId,
      iconClass: 'pi pi-box',
      executorKey: modelId,
      render: { iconClass: 'pi pi-box', iconKey: modelId },
      outputViewers: [{ id: 'json', label: 'JSON', type: WorkflowViewerTypeEnum.Json }],
      name: { type: WorkflowNodeFieldTypeEnum.String, editable: true, autoGenerate: true },
      instruction: { code: false, markdown: false },
      fields: {},
      inputs: { input: { allowMultipleArrows: true, side: WorkflowNodePortSideEnum.Left, order: 1 } },
      outputs: { output: { allowMultipleArrows: true, side: WorkflowNodePortSideEnum.Right, order: 1 } },
    },
    modelId,
  );
};

export const getNodeModuleById = (modelId: string | undefined): WorkflowNodeModule | null => {
  if (!modelId) return null;
  return NODE_MODULES_BY_ID[modelId] ?? null;
};

export const getNodeModule = (modelId: string | undefined): WorkflowNodeModule => getNodeModuleById(modelId) ?? FALLBACK_NODE_MODULE;

export const getAllNodeSchemas = (): Record<string, WorkflowNodeSchema> => {
  return NODE_MODULES.reduce<Record<string, WorkflowNodeSchema>>((acc, module) => {
    acc[module.id] = parseSchemaWithDefaults(module.schema, module.id);
    return acc;
  }, {});
};

export const resolveNodeSchema = (modelId: string | undefined, nodeModels: Record<string, WorkflowNodeSchema>): WorkflowNodeSchema => {
  const module = getNodeModuleById(modelId);
  if (module) {
    const localSchema = parseSchemaWithDefaults(module.schema, module.id);
    const workflowSchema = modelId ? nodeModels[modelId] : undefined;
    if (!workflowSchema) return localSchema;
    return parseSchemaWithDefaults(mergeBuiltInNodeSchema(workflowSchema, localSchema), modelId ?? module.id);
  }
  const fromWorkflow = modelId ? nodeModels[modelId] : undefined;
  if (fromWorkflow) return parseSchemaWithDefaults(fromWorkflow, modelId ?? 'code');
  const unknownId = modelId?.trim() || 'unknown-node';
  return buildUnknownNodeSchema(unknownId);
};

export const getNodeLibraryItems = (): WorkflowNodeLibraryItem[] => {
  const schemas = getAllNodeSchemas();
  return [...NODE_MODULES]
    .sort((a, b) => Number(a.library.order ?? 0) - Number(b.library.order ?? 0))
    .map((module) => {
      const schema = resolveNodeSchema(module.id, schemas);
      return {
        ...module.library,
        group: resolveNodeGroup(schema, module.library.group),
        iconClass: schema.render?.iconClass ?? schema.iconClass ?? module.library.iconClass ?? 'pi pi-box',
        iconColor: module.library.iconColor ?? schema.render?.iconColor ?? schema.iconColor,
        iconBackground: module.library.iconBackground ?? schema.render?.iconBackground,
        renderIcon: module.renderIcon,
      };
    });
};
