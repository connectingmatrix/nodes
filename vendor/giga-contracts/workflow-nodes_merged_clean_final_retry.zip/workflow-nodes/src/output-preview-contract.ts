export type NodeOutputPreviewKind = 'charts' | 'excel';
export type NodeOutputPreview = { kind: NodeOutputPreviewKind; raw: string; parsed: unknown | null };

const safeParse = (raw: string): unknown | null => {
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
};

export function readNodeOutputPreviews(markdown: string): NodeOutputPreview[] {
  const previews: NodeOutputPreview[] = [];
  for (const match of markdown.matchAll(/\[(charts?|chart)\]([\s\S]*?)\[\/\1\]/gi)) previews.push({ kind: 'charts', raw: String(match[2] || ''), parsed: safeParse(String(match[2] || '')) });
  for (const match of markdown.matchAll(/\[excel\]([\s\S]*?)\[\/excel\]/gi)) previews.push({ kind: 'excel', raw: String(match[1] || ''), parsed: safeParse(String(match[1] || '')) });
  return previews;
}
