# workflow-nodes

## Giga product/runtime documentation

See [docs/giga-nodes/README.md](docs/giga-nodes/README.md) for the current Giga feature rules, role boundaries, AI Agent decision chains, ingestion chains, and process-monitor interconnects.
